"""
YMERA Enterprise Database Core - Fully Integrated System v5.0
Production-ready, optimized, and fully integrated database management
All components unified for maximum reliability and performance
"""

import logging
import os
import uuid
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

# Third-party imports
import structlog
from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Table,
    Text,
    delete,
    func,
    select,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.pool import StaticPool

# ===============================================================================
# LOGGING CONFIGURATION
# ===============================================================================

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = structlog.get_logger("ymera.database.core")

# ===============================================================================
# BASE CONFIGURATION
# ===============================================================================


class DatabaseConfig:
    """Centralized database configuration"""

    def __init__(self):
        # Database connection
        self.database_url = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./ymera_enterprise.db")

        # Connection pooling
        self.pool_size = int(os.getenv("DB_POOL_SIZE", "20"))
        self.max_overflow = int(os.getenv("DB_MAX_OVERFLOW", "40"))
        self.pool_timeout = int(os.getenv("DB_POOL_TIMEOUT", "30"))
        self.pool_recycle = int(os.getenv("DB_POOL_RECYCLE", "3600"))

        # Performance
        self.echo = os.getenv("DB_ECHO", "false").lower() == "true"
        self.echo_pool = os.getenv("DB_ECHO_POOL", "false").lower() == "true"

        # Migrations
        self.migrations_dir = Path(os.getenv("DB_MIGRATIONS_DIR", "./database/migrations"))
        self.migration_table = "schema_migrations"

        # Determine database type
        self.db_type = self._determine_db_type()

    def _determine_db_type(self) -> str:
        """Determine database type from URL"""
        if "postgresql" in self.database_url:
            return "postgresql"
        elif "mysql" in self.database_url:
            return "mysql"
        elif "sqlite" in self.database_url:
            return "sqlite"
        else:
            return "sqlite"  # Default fallback

    @property
    def is_postgres(self) -> bool:
        return self.db_type == "postgresql"

    @property
    def is_sqlite(self) -> bool:
        return self.db_type == "sqlite"


# ===============================================================================
# DATABASE MODELS - ENHANCED BASE
# ===============================================================================


class EnhancedBase:
    """Enhanced base class with utility methods"""

    def to_dict(self, include_relations: bool = False) -> Dict[str, Any]:
        """Convert model instance to dictionary"""
        result = {}
        for column in self.__table__.columns:
            value = getattr(self, column.name)
            if isinstance(value, datetime):
                result[column.name] = value.isoformat()
            elif isinstance(value, uuid.UUID):
                result[column.name] = str(value)
            else:
                result[column.name] = value

        if include_relations:
            for rel in self.__mapper__.relationships:
                value = getattr(self, rel.key)
                if value is not None:
                    if rel.collection_class is None:
                        result[rel.key] = (
                            value.to_dict() if hasattr(value, "to_dict") else str(value)
                        )
                    else:
                        result[rel.key] = [
                            item.to_dict() if hasattr(item, "to_dict") else str(item)
                            for item in value
                        ]

        return result

    def update_from_dict(self, data: Dict[str, Any], exclude: List[str] = None):
        """Update model instance from dictionary"""
        exclude = exclude or ["id", "created_at"]
        for key, value in data.items():
            if key not in exclude and hasattr(self, key):
                setattr(self, key, value)

    @classmethod
    def create_from_dict(cls, data: Dict[str, Any]):
        """Create model instance from dictionary"""
        return cls(**{k: v for k, v in data.items() if hasattr(cls, k)})


Base = declarative_base(cls=EnhancedBase)

# ===============================================================================
# CORE MODELS
# ===============================================================================


class TimestampMixin:
    """Mixin for automatic timestamp management"""

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class SoftDeleteMixin:
    """Mixin for soft deletion support"""

    is_deleted = Column(Boolean, default=False, nullable=False, index=True)
    deleted_at = Column(DateTime, nullable=True)


# Helper function for JSON/JSONB columns
def get_json_column():
    """Return appropriate JSON column type based on database"""
    config = DatabaseConfig()
    return JSONB if config.is_postgres else JSON


# Association Tables
project_agents_table = Table(
    "project_agents",
    Base.metadata,
    Column("project_id", String, ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True),
    Column("agent_id", String, ForeignKey("agents.id", ondelete="CASCADE"), primary_key=True),
    Column("role", String(50), default="member"),
    Column("assigned_at", DateTime, default=datetime.utcnow),
)


class User(Base, TimestampMixin, SoftDeleteMixin):
    """Enhanced User model"""

    __tablename__ = "users"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(255), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100))
    last_name = Column(String(100))

    # Profile
    avatar_url = Column(String(500))
    bio = Column(Text)
    location = Column(String(100))
    timezone = Column(String(50), default="UTC")
    language = Column(String(10), default="en")

    # Authentication & Security
    email_verified = Column(Boolean, default=False)
    two_factor_enabled = Column(Boolean, default=False)
    two_factor_secret = Column(String(32))

    # Access Control
    role = Column(String(50), default="user", index=True)
    permissions = Column(get_json_column(), default=list)
    is_active = Column(Boolean, default=True, index=True)
    last_login = Column(DateTime)
    login_count = Column(Integer, default=0)

    # Preferences
    preferences = Column(get_json_column(), default=dict)
    api_key = Column(String(64), unique=True, index=True)
    api_key_expires = Column(DateTime)

    # Relationships
    projects = relationship("Project", back_populates="owner", foreign_keys="Project.owner_id")
    tasks = relationship("Task", back_populates="user", foreign_keys="Task.user_id")
    files = relationship("File", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")

    __table_args__ = (
        CheckConstraint("length(username) >= 3", name="username_min_length"),
        Index("idx_user_email_active", "email", "is_active"),
    )


class Project(Base, TimestampMixin, SoftDeleteMixin):
    """Enhanced Project model"""

    __tablename__ = "projects"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    owner_id = Column(
        String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )

    # Project details
    github_url = Column(String(500))
    project_type = Column(String(50), default="general", index=True)
    programming_language = Column(String(50))
    framework = Column(String(100))

    # Status & Progress
    status = Column(String(50), default="active", index=True)
    priority = Column(String(20), default="medium", index=True)
    progress = Column(Float, default=0.0)
    estimated_completion = Column(DateTime)

    # Configuration
    settings = Column(get_json_column(), default=dict)
    environment_variables = Column(get_json_column(), default=dict)
    dependencies = Column(get_json_column(), default=list)

    # Metrics
    total_tasks = Column(Integer, default=0)
    completed_tasks = Column(Integer, default=0)
    success_rate = Column(Float, default=0.0)
    total_lines_of_code = Column(Integer, default=0)
    test_coverage = Column(Float, default=0.0)

    # Metadata
    tags = Column(get_json_column(), default=list)
    metadata_info = Column(get_json_column(), default=dict)

    # Relationships
    owner = relationship("User", back_populates="projects", foreign_keys=[owner_id])
    tasks = relationship("Task", back_populates="project", cascade="all, delete-orphan")
    files = relationship("File", back_populates="project")
    agents = relationship("Agent", secondary=project_agents_table, back_populates="projects")

    __table_args__ = (
        CheckConstraint("progress >= 0 AND progress <= 100", name="progress_range"),
        CheckConstraint("success_rate >= 0 AND success_rate <= 100", name="success_rate_range"),
        Index("idx_project_owner_status", "owner_id", "status"),
    )


class Agent(Base, TimestampMixin, SoftDeleteMixin):
    """Enhanced Agent model"""

    __tablename__ = "agents"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False, index=True)
    agent_type = Column(String(100), nullable=False, index=True)
    description = Column(Text)

    # Configuration
    capabilities = Column(get_json_column(), default=list)
    configuration = Column(get_json_column(), default=dict)
    api_endpoints = Column(get_json_column(), default=dict)

    # Status & Performance
    status = Column(String(50), default="active", index=True)
    health_status = Column(String(50), default="healthy", index=True)
    load_factor = Column(Float, default=0.0)
    response_time_avg = Column(Float, default=0.0)
    success_rate = Column(Float, default=100.0)

    # Learning & Intelligence
    learning_model_version = Column(String(50), default="1.0")
    knowledge_base = Column(get_json_column(), default=dict)
    learning_history = Column(get_json_column(), default=list)
    performance_metrics = Column(get_json_column(), default=dict)

    # Statistics
    tasks_completed = Column(Integer, default=0)
    tasks_failed = Column(Integer, default=0)
    total_execution_time = Column(Float, default=0.0)
    last_active = Column(DateTime, default=datetime.utcnow)

    # Relationships
    tasks = relationship("Task", back_populates="agent")
    projects = relationship("Project", secondary=project_agents_table, back_populates="agents")

    __table_args__ = (
        CheckConstraint("load_factor >= 0 AND load_factor <= 100", name="load_factor_range"),
        CheckConstraint(
            "success_rate >= 0 AND success_rate <= 100", name="agent_success_rate_range"
        ),
        Index("idx_agent_type_status", "agent_type", "status"),
    )


class Task(Base, TimestampMixin, SoftDeleteMixin):
    """Enhanced Task model"""

    __tablename__ = "tasks"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(500), nullable=False, index=True)
    description = Column(Text)
    task_type = Column(String(100), nullable=False, index=True)

    # Relationships
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(
        String, ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    agent_id = Column(
        String, ForeignKey("agents.id", ondelete="SET NULL"), nullable=True, index=True
    )
    parent_task_id = Column(String, ForeignKey("tasks.id", ondelete="SET NULL"), nullable=True)

    # Status & Priority
    status = Column(String(50), default="pending", index=True)
    priority = Column(String(20), default="medium", index=True)
    urgency = Column(Integer, default=5)

    # Execution Details
    input_data = Column(get_json_column(), default=dict)
    output_data = Column(get_json_column(), default=dict)
    execution_config = Column(get_json_column(), default=dict)
    error_details = Column(get_json_column(), default=dict)

    # Timing
    scheduled_at = Column(DateTime, nullable=True, index=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    execution_time = Column(Float, default=0.0)
    timeout = Column(Integer, default=3600)

    # Progress & Results
    progress = Column(Float, default=0.0)
    result_summary = Column(Text)
    quality_score = Column(Float, default=0.0)
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)

    # Dependencies & Context
    dependencies = Column(get_json_column(), default=list)
    context_data = Column(get_json_column(), default=dict)
    tags = Column(get_json_column(), default=list)

    # Relationships
    user = relationship("User", back_populates="tasks", foreign_keys=[user_id])
    project = relationship("Project", back_populates="tasks")
    agent = relationship("Agent", back_populates="tasks")
    parent_task = relationship("Task", remote_side=[id], foreign_keys=[parent_task_id])

    __table_args__ = (
        CheckConstraint("progress >= 0 AND progress <= 100", name="task_progress_range"),
        CheckConstraint("urgency >= 1 AND urgency <= 10", name="urgency_range"),
        Index("idx_task_status_priority", "status", "priority"),
        Index("idx_task_agent_status", "agent_id", "status"),
    )


class File(Base, TimestampMixin, SoftDeleteMixin):
    """Enhanced File model"""

    __tablename__ = "files"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    filename = Column(String(500), nullable=False, index=True)
    original_filename = Column(String(500), nullable=False)
    file_path = Column(String(1000), nullable=False)

    # File Properties
    file_size = Column(Integer, nullable=False)
    mime_type = Column(String(200), index=True)
    file_extension = Column(String(20), index=True)
    encoding = Column(String(50))

    # Security
    checksum_md5 = Column(String(32), index=True)
    checksum_sha256 = Column(String(64), index=True)
    virus_scan_status = Column(String(50), default="pending")

    # Access Control
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(
        String, ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True
    )
    access_level = Column(String(50), default="private", index=True)

    # Metadata
    file_category = Column(String(50), index=True)
    tags = Column(get_json_column(), default=list)
    metadata_extracted = Column(get_json_column(), default=dict)
    content_summary = Column(Text)

    # Usage Statistics
    download_count = Column(Integer, default=0)
    last_accessed = Column(DateTime)

    # Relationships
    user = relationship("User", back_populates="files")
    project = relationship("Project", back_populates="files")

    __table_args__ = (
        CheckConstraint("file_size > 0", name="positive_file_size"),
        Index("idx_file_user_project", "user_id", "project_id"),
    )


class AuditLog(Base, TimestampMixin):
    """Comprehensive audit logging"""

    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)

    # Action Details
    action = Column(String(200), nullable=False, index=True)
    resource_type = Column(String(100), nullable=False, index=True)
    resource_id = Column(String, index=True)

    # Context
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    session_id = Column(String(100), index=True)
    request_id = Column(String(100), index=True)

    # Details
    action_details = Column(get_json_column(), default=dict)
    before_state = Column(get_json_column(), default=dict)
    after_state = Column(get_json_column(), default=dict)

    # Result
    success = Column(Boolean, nullable=False, index=True)
    error_message = Column(Text)
    execution_time = Column(Float)

    # Relationships
    user = relationship("User", back_populates="audit_logs")

    __table_args__ = (
        Index("idx_audit_action_time", "action", "created_at"),
        Index("idx_audit_resource", "resource_type", "resource_id"),
    )


# ===============================================================================
# MIGRATION SYSTEM
# ===============================================================================


@dataclass
class MigrationInfo:
    """Information about a migration"""

    version: int
    name: str
    filename: str
    filepath: Path
    checksum: str
    description: Optional[str] = None
    dependencies: List[int] = field(default_factory=list)


class BaseMigration(ABC):
    """Abstract base class for migrations"""

    def __init__(self):
        self.version: int = 0
        self.name: str = ""
        self.description: str = ""
        self.dependencies: List[int] = []

    @abstractmethod
    async def up(self, session: AsyncSession) -> None:
        """Execute the migration"""

    @abstractmethod
    async def down(self, session: AsyncSession) -> None:
        """Rollback the migration"""

    async def validate_preconditions(self, session: AsyncSession) -> bool:
        """Validate migration preconditions"""
        return True

    async def validate_postconditions(self, session: AsyncSession) -> bool:
        """Validate migration postconditions"""
        return True


# ===============================================================================
# DATABASE MANAGER - INTEGRATED
# ===============================================================================


class IntegratedDatabaseManager:
    """Fully integrated production-ready database manager"""

    def __init__(self, config: Optional[DatabaseConfig] = None):
        self.config = config or DatabaseConfig()
        self.engine: Optional[AsyncEngine] = None
        self.session_factory: Optional[async_sessionmaker] = None
        self._initialized = False
        self.logger = logger.bind(component="database_manager")

    async def initialize(self) -> None:
        """Initialize database with all components"""
        if self._initialized:
            self.logger.warning("Database already initialized")
            return

        try:
            self.logger.info("Initializing integrated database manager")

            # Create async engine
            await self._create_engine()

            # Create session factory
            self._create_session_factory()

            # Initialize database schema
            await self._initialize_schema()

            # Setup migration system
            await self._setup_migrations()

            # Verify connectivity
            await self._verify_connection()

            self._initialized = True
            self.logger.info(
                "Database initialized successfully",
                db_type=self.config.db_type,
                pool_size=self.config.pool_size,
            )

        except Exception as e:
            self.logger.error("Failed to initialize database", error=str(e))
            raise RuntimeError(f"Database initialization failed: {e}") from e

    async def _create_engine(self) -> None:
        """Create async database engine"""
        database_url = self.config.database_url

        # Ensure async driver
        if "postgresql://" in database_url and "asyncpg" not in database_url:
            database_url = database_url.replace("postgresql://", "postgresql+asyncpg://")
        elif "sqlite://" in database_url and "aiosqlite" not in database_url:
            database_url = database_url.replace("sqlite://", "sqlite+aiosqlite://")

        # Configure pooling based on database type
        if self.config.is_sqlite:
            self.engine = create_async_engine(
                database_url,
                echo=self.config.echo,
                poolclass=StaticPool,
                connect_args={"check_same_thread": False},
                future=True,
            )
        else:
            self.engine = create_async_engine(
                database_url,
                echo=self.config.echo,
                echo_pool=self.config.echo_pool,
                pool_size=self.config.pool_size,
                max_overflow=self.config.max_overflow,
                pool_timeout=self.config.pool_timeout,
                pool_recycle=self.config.pool_recycle,
                pool_pre_ping=True,
                future=True,
            )

        self.logger.debug("Database engine created", db_type=self.config.db_type)

    def _create_session_factory(self) -> None:
        """Create session factory"""
        self.session_factory = async_sessionmaker(
            bind=self.engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autocommit=False,
            autoflush=False,
        )
        self.logger.debug("Session factory created")

    async def _initialize_schema(self) -> None:
        """Initialize database schema"""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        self.logger.info("Database schema initialized")

    async def _setup_migrations(self) -> None:
        """Setup migration tracking table"""
        async with self.get_session() as session:
            # Create migration tracking table
            migration_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {self.config.migration_table} (
                id VARCHAR(36) PRIMARY KEY,
                version INTEGER UNIQUE NOT NULL,
                name VARCHAR(255) NOT NULL,
                filename VARCHAR(255) NOT NULL,
                checksum VARCHAR(64) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'completed',
                started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                execution_time_ms INTEGER,
                error_message TEXT,
                rollback_executed BOOLEAN NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """
            await session.execute(text(migration_table_sql))
            await session.commit()

        self.logger.debug("Migration system initialized")

    async def _verify_connection(self) -> None:
        """Verify database connection"""
        async with self.get_session() as session:
            await session.execute(text("SELECT 1"))
        self.logger.debug("Database connection verified")

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get database session with automatic cleanup"""
        if not self._initialized:
            await self.initialize()

        if not self.session_factory:
            raise RuntimeError("Database session factory not initialized")

        session = self.session_factory()
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            self.logger.error("Session error, rolled back", error=str(e))
            raise
        finally:
            await session.close()

    async def health_check(self) -> Dict[str, Any]:
        """Comprehensive health check"""
        try:
            async with self.get_session() as session:
                result = await session.execute(text("SELECT 1 as healthcheck"))
                result.scalar()

                # Get pool statistics if available
                pool_stats = {}
                if hasattr(self.engine.pool, "size"):
                    pool_stats = {
                        "pool_size": self.engine.pool.size(),
                        "checked_in": self.engine.pool.checkedin(),
                        "checked_out": self.engine.pool.checkedout(),
                        "overflow": self.engine.pool.overflow(),
                    }

                return {
                    "status": "healthy",
                    "healthy": True,
                    "database_type": self.config.db_type,
                    "pool_stats": pool_stats,
                    "timestamp": datetime.utcnow().isoformat(),
                }
        except Exception as e:
            self.logger.error("Health check failed", error=str(e))
            return {
                "status": "unhealthy",
                "healthy": False,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat(),
            }

    async def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive database statistics"""
        async with self.get_session() as session:
            stats = {}

            # Count records in each table
            for table_name, model_class in {
                "users": User,
                "projects": Project,
                "agents": Agent,
                "tasks": Task,
                "files": File,
                "audit_logs": AuditLog,
            }.items():
                try:
                    result = await session.execute(select(func.count(model_class.id)))
                    stats[f"{table_name}_count"] = result.scalar() or 0
                except Exception as e:
                    stats[f"{table_name}_count"] = 0
                    self.logger.warning(f"Could not count {table_name}", error=str(e))

            # Get recent activity (last 24 hours)
            try:
                cutoff = datetime.utcnow() - timedelta(hours=24)
                result = await session.execute(
                    select(func.count(AuditLog.id)).where(AuditLog.created_at > cutoff)
                )
                stats["recent_activity_24h"] = result.scalar() or 0
            except:
                stats["recent_activity_24h"] = 0

            stats["timestamp"] = datetime.utcnow().isoformat()
            return stats

    async def optimize_database(self) -> Dict[str, Any]:
        """Run database optimization tasks"""
        results = {"optimizations": [], "errors": []}

        async with self.get_session() as session:
            try:
                # Update project statistics
                update_projects_sql = """
                UPDATE projects SET
                    total_tasks = (SELECT COUNT(*) FROM tasks WHERE project_id = projects.id),
                    completed_tasks = (SELECT COUNT(*) FROM tasks WHERE project_id = projects.id AND status = 'completed'),
                    success_rate = CASE
                        WHEN (SELECT COUNT(*) FROM tasks WHERE project_id = projects.id) = 0 THEN 0
                        ELSE (SELECT COUNT(*) FROM tasks WHERE project_id = projects.id AND status = 'completed') * 100.0 /
                             (SELECT COUNT(*) FROM tasks WHERE project_id = projects.id)
                    END,
                    updated_at = CURRENT_TIMESTAMP
                """
                await session.execute(text(update_projects_sql))
                results["optimizations"].append("Updated project statistics")

                # Update agent statistics
                update_agents_sql = """
                UPDATE agents SET
                    tasks_completed = (SELECT COUNT(*) FROM tasks WHERE agent_id = agents.id AND status = 'completed'),
                    tasks_failed = (SELECT COUNT(*) FROM tasks WHERE agent_id = agents.id AND status = 'failed'),
                    success_rate = CASE
                        WHEN (SELECT COUNT(*) FROM tasks WHERE agent_id = agents.id) = 0 THEN 100
                        ELSE (SELECT COUNT(*) FROM tasks WHERE agent_id = agents.id AND status = 'completed') * 100.0 /
                             (SELECT COUNT(*) FROM tasks WHERE agent_id = agents.id)
                    END,
                    total_execution_time = COALESCE((SELECT SUM(execution_time) FROM tasks WHERE agent_id = agents.id AND status = 'completed'), 0),
                    updated_at = CURRENT_TIMESTAMP
                """
                await session.execute(text(update_agents_sql))
                results["optimizations"].append("Updated agent statistics")

                await session.commit()

            except Exception as e:
                results["errors"].append(str(e))
                self.logger.error("Optimization failed", error=str(e))
                await session.rollback()

        results["timestamp"] = datetime.utcnow().isoformat()
        results["success"] = len(results["errors"]) == 0
        return results

    async def cleanup_old_data(self, days_to_keep: int = 90) -> Dict[str, Any]:
        """Clean up old data"""
        results = {"cleaned": {}, "errors": []}

        async with self.get_session() as session:
            try:
                cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)

                # Clean old audit logs
                result = await session.execute(
                    delete(AuditLog).where(AuditLog.created_at < cutoff_date)
                )
                results["cleaned"]["audit_logs"] = result.rowcount

                # Clean old soft-deleted records
                for model_name, model_class in [
                    ("users", User),
                    ("projects", Project),
                    ("agents", Agent),
                    ("tasks", Task),
                    ("files", File),
                ]:
                    if hasattr(model_class, "is_deleted"):
                        result = await session.execute(
                            delete(model_class).where(
                                model_class.is_deleted == True, model_class.deleted_at < cutoff_date
                            )
                        )
                        results["cleaned"][model_name] = result.rowcount

                await session.commit()

            except Exception as e:
                results["errors"].append(str(e))
                self.logger.error("Cleanup failed", error=str(e))
                await session.rollback()

        results["timestamp"] = datetime.utcnow().isoformat()
        results["success"] = len(results["errors"]) == 0
        return results

    async def close(self) -> None:
        """Close database connections"""
        if self.engine:
            await self.engine.dispose()
            self._initialized = False
            self.logger.info("Database connections closed")


# ===============================================================================
# GLOBAL INSTANCE AND UTILITIES
# ===============================================================================

_global_db_manager: Optional[IntegratedDatabaseManager] = None


async def get_database_manager() -> IntegratedDatabaseManager:
    """Get or create global database manager instance"""
    global _global_db_manager

    if _global_db_manager is None:
        _global_db_manager = IntegratedDatabaseManager()
        await _global_db_manager.initialize()

    return _global_db_manager


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency for database sessions"""
    db_manager = await get_database_manager()
    async with db_manager.get_session() as session:
        yield session


async def init_database(config: Optional[DatabaseConfig] = None) -> IntegratedDatabaseManager:
    """Initialize database for application startup"""
    global _global_db_manager

    if _global_db_manager is None:
        _global_db_manager = IntegratedDatabaseManager(config)
        await _global_db_manager.initialize()

    return _global_db_manager


async def close_database() -> None:
    """Close database for application shutdown"""
    global _global_db_manager

    if _global_db_manager is not None:
        await _global_db_manager.close()
        _global_db_manager = None


# ===============================================================================
# REPOSITORY PATTERN
# ===============================================================================


class BaseRepository:
    """Base repository with common CRUD operations"""

    def __init__(self, session: AsyncSession, model_class):
        self.session = session
        self.model_class = model_class

    async def create(self, **kwargs) -> Any:
        """Create new record"""
        instance = self.model_class(**kwargs)
        self.session.add(instance)
        await self.session.flush()
        await self.session.refresh(instance)
        return instance

    async def get_by_id(self, id: str) -> Optional[Any]:
        """Get record by ID"""
        result = await self.session.execute(
            select(self.model_class).where(self.model_class.id == id)
        )
        return result.scalar_one_or_none()

    async def get_all(self, limit: int = 100, offset: int = 0, filters: Dict = None) -> List[Any]:
        """Get all records with pagination and filters"""
        query = select(self.model_class)

        if filters:
            for key, value in filters.items():
                if hasattr(self.model_class, key):
                    query = query.where(getattr(self.model_class, key) == value)

        query = query.limit(limit).offset(offset)
        result = await self.session.execute(query)
        return result.scalars().all()

    async def update(self, id: str, **kwargs) -> Optional[Any]:
        """Update record"""
        instance = await self.get_by_id(id)
        if instance:
            for key, value in kwargs.items():
                if hasattr(instance, key):
                    setattr(instance, key, value)
            await self.session.flush()
            await self.session.refresh(instance)
        return instance

    async def delete(self, id: str) -> bool:
        """Delete record (hard delete)"""
        instance = await self.get_by_id(id)
        if instance:
            await self.session.delete(instance)
            await self.session.flush()
            return True
        return False

    async def soft_delete(self, id: str) -> bool:
        """Soft delete record if supported"""
        if hasattr(self.model_class, "is_deleted"):
            instance = await self.get_by_id(id)
            if instance:
                instance.is_deleted = True
                instance.deleted_at = datetime.utcnow()
                await self.session.flush()
                return True
        return False


# ===============================================================================
# EXPORTS
# ===============================================================================

__all__ = [
    # Core classes
    "Base",
    "DatabaseConfig",
    "IntegratedDatabaseManager",
    "BaseRepository",
    # Models
    "User",
    "Project",
    "Agent",
    "Task",
    "File",
    "AuditLog",
    # Mixins
    "TimestampMixin",
    "SoftDeleteMixin",
    # Migration
    "BaseMigration",
    "MigrationInfo",
    # Utilities
    "get_database_manager",
    "get_db_session",
    "init_database",
    "close_database",
]

# ===============================================================================
# VERSION INFO
# ===============================================================================

__version__ = "5.0.0"
__author__ = "YMERA Enterprise"
__description__ = "Fully Integrated Production-Ready Database System"
