#!/usr/bin/env python3
"""
YMERA API Gateway
RESTful API for agent system
"""

import importlib
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Add agents to path
sys.path.insert(0, str(Path(__file__).parent.parent / "agents"))

from agent_base import Priority, TaskRequest

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="YMERA Agent API", version="2.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Simple in-memory registry for sync operations
class SimpleAgentRegistry:
    """Simple synchronous agent registry for API gateway."""

    def __init__(self):
        self.agents = {}
        self._load_agents()

    def _load_agents(self):
        """Load all available agents from the agents directory."""
        agents_dir = Path(__file__).parent.parent / "agents"
        agent_files = list(agents_dir.glob("*_agent.py"))

        for agent_file in agent_files:
            try:
                module_name = agent_file.stem
                module = importlib.import_module(module_name)

                # Find agent class
                for item_name in dir(module):
                    item = getattr(module, item_name)
                    if (
                        isinstance(item, type)
                        and item_name.endswith("Agent")
                        and item_name != "BaseAgent"
                    ):
                        # Instantiate agent
                        agent = item()
                        self.agents[agent.agent_id] = agent
                        logger.info(f"Loaded agent: {agent.name} ({agent.agent_id})")
                        break
            except Exception as e:
                logger.error(f"Failed to load agent from {agent_file}: {e}")

    def get_agent(self, agent_id: str):
        """Get agent by ID."""
        return self.agents.get(agent_id)

    def get_agent_by_name(self, agent_name: str):
        """Get agent by name."""
        for agent in self.agents.values():
            if agent.name.lower() == agent_name.lower():
                return agent
        return None

    def list_agents(self) -> List[Dict[str, Any]]:
        """List all registered agents."""
        return [
            {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "description": agent.config.description,
                "capabilities": [cap.name for cap in agent.capabilities],
                "task_types": agent.get_supported_task_types(),
            }
            for agent in self.agents.values()
        ]

    def get_agent_count(self) -> int:
        """Get number of registered agents."""
        return len(self.agents)


# Initialize registry
registry = SimpleAgentRegistry()


class TaskRequestModel(BaseModel):
    """API model for task requests."""

    task_type: str
    priority: str = "medium"
    payload: Dict[str, Any]
    agent_id: Optional[str] = None
    agent_name: Optional[str] = None


@app.get("/")
def root():
    """Root endpoint."""
    return {"service": "YMERA Agent API", "version": "2.0", "status": "operational"}


@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "agents_registered": registry.get_agent_count(),
        "timestamp": datetime.now().isoformat(),
    }


@app.get("/agents")
def list_agents():
    """List all registered agents."""
    return {"agents": registry.list_agents()}


@app.get("/agents/{agent_id}")
def get_agent_info(agent_id: str):
    """Get information about a specific agent."""
    agent = registry.get_agent(agent_id)

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    return agent.get_info()


@app.post("/tasks")
def submit_task(request: TaskRequestModel):
    """Submit a task to an agent."""
    # Find agent
    if request.agent_id:
        agent = registry.get_agent(request.agent_id)
    elif request.agent_name:
        agent = registry.get_agent_by_name(request.agent_name)
    else:
        raise HTTPException(
            status_code=400, detail="Either agent_id or agent_name must be provided"
        )

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    # Create task
    try:
        task = TaskRequest(
            task_type=request.task_type,
            priority=Priority[request.priority.upper()],
            payload=request.payload,
        )
    except KeyError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid priority: {request.priority}. Must be one of: low, medium, high, critical",
        )

    # Process task
    response = agent.process_task(task)

    # Return result
    return {**response.to_dict(), "agent_id": agent.agent_id, "agent_name": agent.name}


if __name__ == "__main__":
    import uvicorn

    print("Starting YMERA API Gateway...")
    print(f"Loaded {registry.get_agent_count()} agents")
    uvicorn.run(app, host="0.0.0.0", port=8000)
