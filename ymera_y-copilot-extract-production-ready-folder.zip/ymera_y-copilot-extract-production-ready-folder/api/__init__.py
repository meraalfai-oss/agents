"""
YMERA API Package
Provides RESTful API gateway for the agent system.
"""

__version__ = "2.0.0"

__all__ = ["gateway"]
