"""
Demonstration script for the Expansion Framework

This script demonstrates all the functionality of the expansion_readiness module
and the created expansion framework components.
"""

import asyncio
from pathlib import Path


def print_section(title):
    """Print a formatted section header"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70 + "\n")


async def main():
    """Main demonstration function"""

    print("\n🎯 EXPANSION FRAMEWORK DEMONSTRATION")
    print("=" * 70)

    # Step 1: Initialize ExpansionManager
    print_section("Step 1: Initialize Expansion Manager")
    from expansion_readiness import ExpansionManager

    manager = ExpansionManager()
    print("✅ ExpansionManager initialized")
    print(f"   Expansion framework: {manager.expansion_framework}")

    # Step 2: Setup Expansion Framework
    print_section("Step 2: Setup Expansion Framework")
    manager.setup_expansion_framework()
    print("\n✅ All expansion framework components created")

    # Step 3: Demonstrate Plugin Architecture
    print_section("Step 3: Plugin Architecture Demo")
    from enhanced_workspace.integration.plugin_architecture import BasePlugin, PluginManager

    # Create a custom plugin
    class AnalyticsPlugin(BasePlugin):
        def __init__(self):
            super().__init__(name="Analytics", version="1.0.0")
            self.data = []

        async def initialize(self):
            print(f"   🔌 Initializing {self.name} plugin v{self.version}")
            return True

        async def execute(self, context):
            print(f"   📊 Executing {self.name} plugin")
            self.data.append(context)
            return {"status": "success", "data_count": len(self.data)}

    # Register and use the plugin
    plugin_mgr = PluginManager()
    plugin_mgr.register_plugin("analytics", AnalyticsPlugin)

    # Initialize and execute
    analytics = AnalyticsPlugin()
    await analytics.initialize()
    result = await analytics.execute({"event": "user_action", "type": "click"})
    print(f"   Result: {result}")

    # Demonstrate hooks
    print("\n   Hook System Demo:")
    hook_data = []

    def pre_request_hook(*args, **kwargs):
        hook_data.append(f"Pre-request hook called with {args}")
        print(f"   🪝 Pre-request hook executed")

    def post_request_hook(*args, **kwargs):
        hook_data.append(f"Post-request hook called with {args}")
        print(f"   🪝 Post-request hook executed")

    plugin_mgr.add_hook("pre_request", pre_request_hook)
    plugin_mgr.add_hook("post_request", post_request_hook)

    plugin_mgr.execute_hook("pre_request", "test_data")
    plugin_mgr.execute_hook("post_request", "response_data")
    print(f"   Hook executions: {len(hook_data)}")

    # Step 4: Demonstrate API Versioning
    print_section("Step 4: API Versioning Demo")
    from enhanced_workspace.integration.api_versioning import APIVersionManager

    api_mgr = APIVersionManager()

    # Register multiple API versions
    v1_routes = {"/users": "get_users_v1", "/posts": "get_posts_v1"}

    v2_routes = {
        "/users": "get_users_v2",
        "/posts": "get_posts_v2",
        "/analytics": "get_analytics_v2",
    }

    api_mgr.register_version("v1", v1_routes)
    api_mgr.register_version("v2", v2_routes)

    # Retrieve and display versions
    print(f"   Current version: {api_mgr.current_version}")
    print(f"   V1 routes: {api_mgr.get_version('v1')}")
    print(f"   V2 routes: {api_mgr.get_version('v2')}")

    # Deprecate a version
    api_mgr.deprecate_version("v1", "2025-12-31")

    # Step 5: Demonstrate Configuration
    print_section("Step 5: Configuration Management Demo")
    from enhanced_workspace.integration.config_template import expansion_config

    print("   Default Configuration:")
    print(f"   - Plugin settings: {expansion_config['plugin_settings']}")
    print(f"   - API settings: {expansion_config['api_settings']}")
    print(f"   - Feature flags: {expansion_config['feature_flags']}")

    # Modify configuration
    expansion_config["expansion_modules"]["analytics"]["enabled"] = True
    expansion_config["expansion_modules"]["analytics"]["config"] = {
        "tracking_enabled": True,
        "retention_days": 90,
    }

    print("\n   Updated Configuration:")
    print(
        f"   - Analytics enabled: {expansion_config['expansion_modules']['analytics']['enabled']}"
    )
    print(f"   - Analytics config: {expansion_config['expansion_modules']['analytics']['config']}")

    # Step 6: Display Documentation
    print_section("Step 6: Expansion Documentation")
    doc_path = Path("enhanced_workspace/integration/EXPANSION_GUIDE.md")
    if doc_path.exists():
        print(f"   📚 Documentation available at: {doc_path}")
        with open(doc_path, "r") as f:
            lines = f.readlines()[:10]
            print("\n   First few lines of documentation:")
            for line in lines:
                print(f"   {line.rstrip()}")

    # Step 7: Summary
    print_section("Summary")

    created_files = [
        "enhanced_workspace/integration/plugin_architecture.py",
        "enhanced_workspace/integration/api_versioning.py",
        "enhanced_workspace/integration/config_template.py",
        "enhanced_workspace/integration/EXPANSION_GUIDE.md",
    ]

    print("   ✅ Expansion Framework Components Created:")
    for file_path in created_files:
        if Path(file_path).exists():
            size = Path(file_path).stat().st_size
            print(f"      • {file_path} ({size} bytes)")

    print("\n   🎯 Key Features:")
    print("      • Plugin architecture with hooks system")
    print("      • API versioning for backward compatibility")
    print("      • Configuration templates for easy customization")
    print("      • Comprehensive documentation for developers")

    print("\n   🚀 Next Steps:")
    print("      1. Create custom plugins by extending BasePlugin")
    print("      2. Register API versions for your endpoints")
    print("      3. Configure expansion modules as needed")
    print("      4. Review EXPANSION_GUIDE.md for detailed instructions")

    print("\n" + "=" * 70)
    print("   ✅ DEMONSTRATION COMPLETED SUCCESSFULLY")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
