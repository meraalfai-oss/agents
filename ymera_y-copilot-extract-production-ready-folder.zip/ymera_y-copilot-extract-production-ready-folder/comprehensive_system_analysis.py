#!/usr/bin/env python3
"""
Comprehensive System Analysis Script
====================================

This script performs a complete analysis of the YMERA system including:
- Production readiness validation
- Error classification analysis
- Dependency analysis
- Documentation audit
- Testing infrastructure review
- File organization analysis
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import subprocess


class ComprehensiveSystemAnalyzer:
    """Comprehensive system analysis tool"""
    
    def __init__(self):
        self.root_path = Path(__file__).parent
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "production_readiness": {},
            "error_classification": {},
            "dependency_analysis": {},
            "documentation_audit": {},
            "file_organization": {},
            "testing_infrastructure": {},
            "recommendations": []
        }
    
    def run_production_readiness_check(self):
        """Run production readiness verification"""
        print("\n" + "="*80)
        print("RUNNING PRODUCTION READINESS CHECK")
        print("="*80 + "\n")
        
        try:
            result = subprocess.run(
                [sys.executable, "verify_production_readiness.py"],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            output = result.stdout
            print(output)
            
            # Parse the output
            self.results["production_readiness"] = {
                "status": "PASS" if "PRODUCTION READY" in output else "FAIL",
                "output": output,
                "checks_passed": output.count("✅"),
                "checks_failed": output.count("❌")
            }
        except Exception as e:
            print(f"Error running production readiness check: {e}")
            self.results["production_readiness"] = {"status": "ERROR", "error": str(e)}
    
    def run_error_classification(self):
        """Run error classification analysis"""
        print("\n" + "="*80)
        print("RUNNING ERROR CLASSIFICATION ANALYSIS")
        print("="*80 + "\n")
        
        try:
            # Run the analyzer
            result = subprocess.run(
                [sys.executable, "error_classification_analyzer.py"],
                capture_output=True,
                text=True,
                timeout=120
            )
            
            print("Error classification complete")
            
            # Load the JSON report
            report_path = self.root_path / "error_classification_report.json"
            if report_path.exists():
                with open(report_path, 'r') as f:
                    error_data = json.load(f)
                    self.results["error_classification"] = {
                        "total_agents": error_data.get("total_agents", 0),
                        "successful": error_data.get("successful_imports", 0),
                        "failed": error_data.get("failed_imports", 0),
                        "success_rate": f"{error_data.get('successful_imports', 0) / error_data.get('total_agents', 1) * 100:.1f}%",
                        "error_types": error_data.get("error_distribution", {}),
                        "priorities": error_data.get("priority_breakdown", {})
                    }
                    print(f"\nTotal Agents: {error_data.get('total_agents', 0)}")
                    print(f"Success Rate: {self.results['error_classification']['success_rate']}")
        except Exception as e:
            print(f"Error in error classification: {e}")
            self.results["error_classification"] = {"status": "ERROR", "error": str(e)}
    
    def run_dependency_analysis(self):
        """Run dependency analysis"""
        print("\n" + "="*80)
        print("RUNNING DEPENDENCY ANALYSIS")
        print("="*80 + "\n")
        
        try:
            result = subprocess.run(
                [sys.executable, "analyze_agent_dependencies.py"],
                capture_output=True,
                text=True,
                timeout=90
            )
            
            print("Dependency analysis complete")
            
            # Load the JSON report
            dep_report_path = self.root_path / "agent_dependency_analysis.json"
            if dep_report_path.exists():
                with open(dep_report_path, 'r') as f:
                    dep_data = json.load(f)
                    self.results["dependency_analysis"] = {
                        "total_agents": len(dep_data.get("agents", [])),
                        "by_level": dep_data.get("summary", {}).get("agents_by_level", {}),
                        "fix_order": dep_data.get("fix_order", [])
                    }
                    print(f"\nTotal Agents Analyzed: {self.results['dependency_analysis']['total_agents']}")
                    print(f"By Level: {self.results['dependency_analysis']['by_level']}")
        except Exception as e:
            print(f"Error in dependency analysis: {e}")
            self.results["dependency_analysis"] = {"status": "ERROR", "error": str(e)}
    
    def audit_documentation(self):
        """Audit documentation files"""
        print("\n" + "="*80)
        print("AUDITING DOCUMENTATION")
        print("="*80 + "\n")
        
        try:
            # Count documentation files
            md_files = list(self.root_path.glob("*.md"))
            docs_files = list((self.root_path / "docs").glob("**/*.md")) if (self.root_path / "docs").exists() else []
            
            # Find duplicates and old files
            old_files = [f for f in md_files if f.name.endswith('.old')]
            backup_files = [f for f in md_files if 'backup' in f.name.lower()]
            
            # Categorize docs
            categories = defaultdict(list)
            for f in md_files:
                name = f.name.upper()
                if 'AGENT' in name:
                    categories['agents'].append(f.name)
                elif 'TEST' in name or 'E2E' in name:
                    categories['testing'].append(f.name)
                elif 'DEPLOY' in name or 'PRODUCTION' in name:
                    categories['deployment'].append(f.name)
                elif 'ERROR' in name or 'FIX' in name:
                    categories['fixes'].append(f.name)
                elif 'PHASE' in name:
                    categories['phases'].append(f.name)
                else:
                    categories['other'].append(f.name)
            
            self.results["documentation_audit"] = {
                "total_md_files_root": len(md_files),
                "total_md_files_docs_dir": len(docs_files),
                "old_files": len(old_files),
                "backup_files": len(backup_files),
                "categories": {k: len(v) for k, v in categories.items()},
                "old_file_list": [f.name for f in old_files],
                "backup_file_list": [f.name for f in backup_files]
            }
            
            print(f"Total MD files in root: {len(md_files)}")
            print(f"Total MD files in docs/: {len(docs_files)}")
            print(f"Old files (.old): {len(old_files)}")
            print(f"Backup files: {len(backup_files)}")
            print("\nCategories:")
            for cat, count in self.results["documentation_audit"]["categories"].items():
                print(f"  {cat}: {count}")
        except Exception as e:
            print(f"Error in documentation audit: {e}")
            self.results["documentation_audit"] = {"status": "ERROR", "error": str(e)}
    
    def analyze_file_organization(self):
        """Analyze file organization"""
        print("\n" + "="*80)
        print("ANALYZING FILE ORGANIZATION")
        print("="*80 + "\n")
        
        try:
            # Find test report files
            test_reports = list(self.root_path.glob("*test_report*"))
            test_results = list(self.root_path.glob("*test_results*"))
            json_reports = list(self.root_path.glob("*.json"))
            
            # Find Python files
            py_files = list(self.root_path.glob("*.py"))
            agent_files = [f for f in py_files if 'agent' in f.name.lower()]
            test_files = [f for f in py_files if 'test' in f.name.lower()]
            
            # Find directories
            dirs = [d for d in self.root_path.iterdir() if d.is_dir() and not d.name.startswith('.')]
            
            self.results["file_organization"] = {
                "test_reports": len(test_reports),
                "test_results": len(test_results),
                "json_reports": len(json_reports),
                "python_files_root": len(py_files),
                "agent_files_root": len(agent_files),
                "test_files_root": len(test_files),
                "directories": len(dirs),
                "directory_names": [d.name for d in dirs]
            }
            
            print(f"Test report files: {len(test_reports)}")
            print(f"Test result files: {len(test_results)}")
            print(f"JSON report files: {len(json_reports)}")
            print(f"Python files in root: {len(py_files)}")
            print(f"Agent files in root: {len(agent_files)}")
            print(f"Directories: {len(dirs)}")
        except Exception as e:
            print(f"Error in file organization analysis: {e}")
            self.results["file_organization"] = {"status": "ERROR", "error": str(e)}
    
    def review_testing_infrastructure(self):
        """Review testing infrastructure"""
        print("\n" + "="*80)
        print("REVIEWING TESTING INFRASTRUCTURE")
        print("="*80 + "\n")
        
        try:
            # Find test files
            test_files = list(self.root_path.glob("test_*.py"))
            comprehensive_tests = list(self.root_path.glob("*comprehensive*test*.py"))
            e2e_tests = list(self.root_path.glob("*e2e*.py"))
            
            # Check for test directories
            tests_dir = self.root_path / "tests"
            tests_exist = tests_dir.exists()
            
            self.results["testing_infrastructure"] = {
                "test_files_root": len(test_files),
                "comprehensive_test_files": len(comprehensive_tests),
                "e2e_test_files": len(e2e_tests),
                "tests_directory_exists": tests_exist,
                "pytest_config_exists": (self.root_path / "pytest.ini").exists(),
                "conftest_exists": (self.root_path / "conftest.py").exists()
            }
            
            print(f"Test files in root: {len(test_files)}")
            print(f"Comprehensive test files: {len(comprehensive_tests)}")
            print(f"E2E test files: {len(e2e_tests)}")
            print(f"Tests directory exists: {tests_exist}")
        except Exception as e:
            print(f"Error in testing infrastructure review: {e}")
            self.results["testing_infrastructure"] = {"status": "ERROR", "error": str(e)}
    
    def generate_recommendations(self):
        """Generate recommendations based on analysis"""
        print("\n" + "="*80)
        print("GENERATING RECOMMENDATIONS")
        print("="*80 + "\n")
        
        recommendations = []
        
        # Check documentation
        doc_audit = self.results.get("documentation_audit", {})
        if doc_audit.get("old_files", 0) > 0:
            recommendations.append({
                "priority": "HIGH",
                "category": "Cleanup",
                "action": f"Remove {doc_audit['old_files']} old documentation files (.old)",
                "files": doc_audit.get("old_file_list", [])
            })
        
        if doc_audit.get("total_md_files_root", 0) > 50:
            recommendations.append({
                "priority": "HIGH",
                "category": "Organization",
                "action": "Organize documentation files into categorized directories",
                "details": f"Currently {doc_audit['total_md_files_root']} MD files in root"
            })
        
        # Check file organization
        file_org = self.results.get("file_organization", {})
        if file_org.get("test_reports", 0) > 5:
            recommendations.append({
                "priority": "MEDIUM",
                "category": "Cleanup",
                "action": f"Archive or remove {file_org['test_reports']} test report files",
                "details": "These are likely outdated test results"
            })
        
        if file_org.get("json_reports", 0) > 10:
            recommendations.append({
                "priority": "MEDIUM",
                "category": "Organization",
                "action": "Move JSON reports to a dedicated reports directory",
                "details": f"{file_org['json_reports']} JSON files in root"
            })
        
        # Check error classification
        error_class = self.results.get("error_classification", {})
        if error_class.get("failed", 0) > 0:
            success_rate = float(error_class.get("success_rate", "0%").rstrip('%'))
            if success_rate < 80:
                recommendations.append({
                    "priority": "HIGH",
                    "category": "Agent Fixes",
                    "action": "Fix agent import errors to improve success rate",
                    "details": f"Current success rate: {error_class['success_rate']}, Target: >90%"
                })
        
        # Check dependency analysis
        dep_analysis = self.results.get("dependency_analysis", {})
        if dep_analysis.get("by_level", {}).get("0", 0) > 0:
            recommendations.append({
                "priority": "HIGH",
                "category": "Agent Fixes",
                "action": "Fix Level 0 agents first (no dependencies)",
                "details": f"{dep_analysis['by_level'].get('0', 0)} agents to fix"
            })
        
        # Testing recommendations
        test_infra = self.results.get("testing_infrastructure", {})
        if test_infra.get("e2e_test_files", 0) > 3:
            recommendations.append({
                "priority": "LOW",
                "category": "Testing",
                "action": "Consolidate E2E test files",
                "details": f"{test_infra['e2e_test_files']} E2E test files found"
            })
        
        self.results["recommendations"] = recommendations
        
        print(f"\nGenerated {len(recommendations)} recommendations")
        for rec in recommendations:
            print(f"\n[{rec['priority']}] {rec['category']}: {rec['action']}")
            if 'details' in rec:
                print(f"  Details: {rec['details']}")
    
    def save_results(self):
        """Save analysis results to JSON"""
        output_file = self.root_path / "comprehensive_system_analysis_report.json"
        with open(output_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        print(f"\n\nFull report saved to: {output_file}")
        return output_file
    
    def print_summary(self):
        """Print executive summary"""
        print("\n" + "="*80)
        print("EXECUTIVE SUMMARY")
        print("="*80 + "\n")
        
        # Production readiness
        prod = self.results.get("production_readiness", {})
        print(f"Production Readiness: {prod.get('status', 'UNKNOWN')}")
        if prod.get('checks_passed'):
            print(f"  Checks Passed: {prod['checks_passed']}")
            print(f"  Checks Failed: {prod['checks_failed']}")
        
        # Agent status
        error = self.results.get("error_classification", {})
        if error.get("total_agents"):
            print(f"\nAgent System:")
            print(f"  Total Agents: {error['total_agents']}")
            print(f"  Success Rate: {error['success_rate']}")
            print(f"  Failed: {error['failed']}")
        
        # Documentation
        docs = self.results.get("documentation_audit", {})
        if docs.get("total_md_files_root"):
            print(f"\nDocumentation:")
            print(f"  MD Files in Root: {docs['total_md_files_root']}")
            print(f"  Old Files to Remove: {docs.get('old_files', 0)}")
        
        # Recommendations
        recs = self.results.get("recommendations", [])
        high_priority = [r for r in recs if r['priority'] == 'HIGH']
        print(f"\nRecommendations:")
        print(f"  Total: {len(recs)}")
        print(f"  High Priority: {len(high_priority)}")
    
    def run_complete_analysis(self):
        """Run complete system analysis"""
        print("\n" + "="*80)
        print("YMERA COMPREHENSIVE SYSTEM ANALYSIS")
        print("="*80)
        print(f"\nStarted: {self.results['timestamp']}")
        
        # Run all analysis components
        self.run_production_readiness_check()
        self.run_error_classification()
        self.run_dependency_analysis()
        self.audit_documentation()
        self.analyze_file_organization()
        self.review_testing_infrastructure()
        self.generate_recommendations()
        
        # Print summary and save
        self.print_summary()
        report_file = self.save_results()
        
        print("\n" + "="*80)
        print("ANALYSIS COMPLETE")
        print("="*80)
        print(f"\nReport saved to: {report_file}")
        print("\nNext steps:")
        print("1. Review the recommendations in the report")
        print("2. Start with HIGH priority items")
        print("3. Execute cleanup and organization tasks")
        print("4. Re-run analysis to verify improvements")


def main():
    """Main entry point"""
    analyzer = ComprehensiveSystemAnalyzer()
    analyzer.run_complete_analysis()


if __name__ == "__main__":
    main()
