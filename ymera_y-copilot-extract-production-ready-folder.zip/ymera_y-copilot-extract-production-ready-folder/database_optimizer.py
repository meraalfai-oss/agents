"""
Database Optimization Module
Provides database indexing, query optimization, and performance enhancements
Phase 4: Production Readiness - Database Optimization
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class DatabaseOptimizer:
    """
    Database optimization utilities for production deployment
    
    Features:
    - Index management
    - Query optimization
    - Connection pool configuration
    - Performance monitoring
    """

    # Recommended indexes for common queries
    RECOMMENDED_INDEXES = {
        "users": [
            ("idx_users_email", "email", "btree"),
            ("idx_users_username", "username", "btree"),
            ("idx_users_created_at", "created_at", "btree"),
        ],
        "tasks": [
            ("idx_tasks_status", "status", "btree"),
            ("idx_tasks_priority", "priority", "btree"),
            ("idx_tasks_user_id", "user_id", "btree"),
            ("idx_tasks_created_at", "created_at", "btree"),
            ("idx_tasks_user_status", ["user_id", "status"], "btree"),  # Composite
        ],
        "projects": [
            ("idx_projects_owner_id", "owner_id", "btree"),
            ("idx_projects_status", "status", "btree"),
            ("idx_projects_created_at", "created_at", "btree"),
        ],
        "agents": [
            ("idx_agents_status", "status", "btree"),
            ("idx_agents_agent_type", "agent_type", "btree"),
        ],
        "audit_logs": [
            ("idx_audit_user_id", "user_id", "btree"),
            ("idx_audit_action", "action", "btree"),
            ("idx_audit_timestamp", "timestamp", "btree"),
            ("idx_audit_user_timestamp", ["user_id", "timestamp"], "btree"),  # Composite
        ],
    }

    def __init__(self, database):
        """
        Initialize database optimizer
        
        Args:
            database: Database connection instance
        """
        self.database = database

    async def create_indexes(self, table_name: Optional[str] = None) -> Dict[str, List[str]]:
        """
        Create recommended indexes for optimal query performance
        
        Args:
            table_name: Specific table to index, or None for all tables
            
        Returns:
            Dictionary of created indexes by table
        """
        created_indexes = {}
        tables_to_process = (
            [table_name] if table_name else self.RECOMMENDED_INDEXES.keys()
        )

        for table in tables_to_process:
            if table not in self.RECOMMENDED_INDEXES:
                logger.warning(f"No recommended indexes defined for table: {table}")
                continue

            created_indexes[table] = []
            
            for index_def in self.RECOMMENDED_INDEXES[table]:
                idx_name = index_def[0]
                idx_columns = index_def[1]
                idx_type = index_def[2] if len(index_def) > 2 else "btree"

                try:
                    # Handle composite indexes (list of columns)
                    if isinstance(idx_columns, list):
                        columns_str = ", ".join(idx_columns)
                    else:
                        columns_str = idx_columns

                    # Check if index already exists
                    check_query = """
                        SELECT indexname FROM pg_indexes 
                        WHERE tablename = $1 AND indexname = $2
                    """
                    existing = await self.database.execute_query(check_query, table, idx_name)

                    if existing:
                        logger.info(f"Index {idx_name} already exists on {table}")
                        continue

                    # Create index
                    create_query = f"""
                        CREATE INDEX IF NOT EXISTS {idx_name} 
                        ON {table} USING {idx_type} ({columns_str})
                    """
                    await self.database.execute_command(create_query)
                    created_indexes[table].append(idx_name)
                    logger.info(f"Created index: {idx_name} on {table}({columns_str})")

                except Exception as e:
                    logger.error(f"Failed to create index {idx_name} on {table}: {e}")

        return created_indexes

    async def analyze_tables(self, table_name: Optional[str] = None) -> bool:
        """
        Run ANALYZE on tables to update query planner statistics
        
        Args:
            table_name: Specific table to analyze, or None for all tables
            
        Returns:
            Success status
        """
        try:
            if table_name:
                await self.database.execute_command(f"ANALYZE {table_name}")
                logger.info(f"Analyzed table: {table_name}")
            else:
                await self.database.execute_command("ANALYZE")
                logger.info("Analyzed all tables")
            return True
        except Exception as e:
            logger.error(f"Failed to analyze tables: {e}")
            return False

    async def vacuum_tables(self, table_name: Optional[str] = None, full: bool = False) -> bool:
        """
        Run VACUUM to reclaim storage and update statistics
        
        Args:
            table_name: Specific table to vacuum, or None for all tables
            full: Whether to run VACUUM FULL (requires exclusive lock)
            
        Returns:
            Success status
        """
        try:
            vacuum_cmd = "VACUUM FULL" if full else "VACUUM"
            
            if table_name:
                await self.database.execute_command(f"{vacuum_cmd} {table_name}")
                logger.info(f"Vacuumed table: {table_name}")
            else:
                await self.database.execute_command(vacuum_cmd)
                logger.info("Vacuumed all tables")
            return True
        except Exception as e:
            logger.error(f"Failed to vacuum tables: {e}")
            return False

    async def get_index_usage_stats(self) -> List[Dict]:
        """
        Get index usage statistics for optimization analysis
        
        Returns:
            List of index usage statistics
        """
        query = """
            SELECT 
                schemaname,
                tablename,
                indexname,
                idx_scan as scans,
                idx_tup_read as tuples_read,
                idx_tup_fetch as tuples_fetched
            FROM pg_stat_user_indexes
            ORDER BY idx_scan DESC
        """
        try:
            return await self.database.execute_query(query)
        except Exception as e:
            logger.error(f"Failed to get index usage stats: {e}")
            return []

    async def get_table_sizes(self) -> List[Dict]:
        """
        Get table size information for capacity planning
        
        Returns:
            List of table sizes
        """
        query = """
            SELECT 
                schemaname,
                tablename,
                pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as total_size,
                pg_size_pretty(pg_relation_size(schemaname||'.'||tablename)) as table_size,
                pg_size_pretty(pg_indexes_size(schemaname||'.'||tablename)) as indexes_size
            FROM pg_tables
            WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
            ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
        """
        try:
            return await self.database.execute_query(query)
        except Exception as e:
            logger.error(f"Failed to get table sizes: {e}")
            return []

    async def get_slow_queries(self, min_duration_ms: int = 1000) -> List[Dict]:
        """
        Get slow query statistics (requires pg_stat_statements extension)
        
        Args:
            min_duration_ms: Minimum query duration in milliseconds
            
        Returns:
            List of slow queries
        """
        query = """
            SELECT 
                query,
                calls,
                total_time,
                mean_time,
                max_time,
                stddev_time
            FROM pg_stat_statements
            WHERE mean_time > $1
            ORDER BY mean_time DESC
            LIMIT 50
        """
        try:
            return await self.database.execute_query(query, min_duration_ms)
        except Exception as e:
            logger.warning(f"pg_stat_statements not available or failed: {e}")
            return []

    async def optimize_connection_pool(self) -> Dict:
        """
        Get recommendations for connection pool optimization
        
        Returns:
            Dictionary with pool optimization recommendations
        """
        try:
            # Get current connection stats
            stats_query = """
                SELECT 
                    count(*) as total_connections,
                    count(*) FILTER (WHERE state = 'active') as active,
                    count(*) FILTER (WHERE state = 'idle') as idle,
                    count(*) FILTER (WHERE state = 'idle in transaction') as idle_in_transaction
                FROM pg_stat_activity
            """
            stats = await self.database.execute_single(stats_query)

            # Get database configuration
            config_query = """
                SELECT name, setting 
                FROM pg_settings 
                WHERE name IN ('max_connections', 'shared_buffers', 'effective_cache_size')
            """
            config = await self.database.execute_query(config_query)
            config_dict = {item["name"]: item["setting"] for item in config}

            max_connections = int(config_dict.get("max_connections", 100))
            active = stats.get("active", 0)
            idle = stats.get("idle", 0)

            recommendations = {
                "current_stats": stats,
                "database_config": config_dict,
                "recommendations": [],
            }

            # Provide recommendations
            if active / max_connections > 0.8:
                recommendations["recommendations"].append(
                    "Consider increasing max_connections or connection pool size"
                )

            if idle > active * 2:
                recommendations["recommendations"].append(
                    "Consider reducing connection pool size - many idle connections"
                )

            if stats.get("idle_in_transaction", 0) > 5:
                recommendations["recommendations"].append(
                    "Warning: idle in transaction connections detected - check for uncommitted transactions"
                )

            return recommendations

        except Exception as e:
            logger.error(f"Failed to get connection pool recommendations: {e}")
            return {"error": str(e)}

    async def create_all_optimizations(self) -> Dict:
        """
        Apply all recommended optimizations
        
        Returns:
            Summary of applied optimizations
        """
        results = {
            "indexes_created": {},
            "tables_analyzed": False,
            "recommendations": {},
        }

        # Create indexes
        logger.info("Creating recommended indexes...")
        results["indexes_created"] = await self.create_indexes()

        # Analyze tables
        logger.info("Analyzing tables...")
        results["tables_analyzed"] = await self.analyze_tables()

        # Get recommendations
        logger.info("Getting optimization recommendations...")
        results["recommendations"] = await self.optimize_connection_pool()

        return results


# Utility function for easy access
async def optimize_database(database) -> Dict:
    """
    Convenience function to optimize database with recommended settings
    
    Args:
        database: Database connection instance
        
    Returns:
        Optimization summary
    """
    optimizer = DatabaseOptimizer(database)
    return await optimizer.create_all_optimizations()
