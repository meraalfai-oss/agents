# AGENT COVERAGE REPORT
## Test Coverage Analysis with MEASURED Data

**Report Generated:** 2025-10-21T06:11:52.674716
**Test Timestamp:** 2025-10-21T06:09:32.636316

---

## 📊 Coverage Metrics - ACTUAL MEASUREMENTS

### Test Execution (MEASURED)
- **Agents Tested:** 173
- **Agents Passed:** 12
- **Agents Failed:** 161
- **Agents Skipped:** 0
- **Test Duration:** 2992.86ms

### Test Statistics (MEASURED)
- **Total Tests Run:** 332
- **Tests Passed:** 149
- **Tests Failed:** 183
- **Overall Pass Rate:** 6.94%

### Success Rates (MEASURED)
- **Agent Pass Rate:** 6.94%
- **Test Pass Rate:** 44.88%

---

## 🎯 Agent Status Distribution (MEASURED)

- **FAIL:** 161 agents (93.1%)
- **PASS:** 12 agents (6.9%)


---

## ❌ Failure Analysis (MEASURED)

### Import Failure Types
- **ModuleNotFoundError:** 107 failures (61.8%)
- **ImportError:** 9 failures (5.2%)
- **NameError:** 2 failures (1.2%)
- **SyntaxError:** 1 failures (0.6%)


### Common Error Types
- **ModuleNotFoundError:** 107 occurrences
- **RequiresArguments:** 58 occurrences
- **ImportError:** 9 occurrences
- **AttributeError:** 3 occurrences
- **NameError:** 2 occurrences
- **TypeError:** 2 occurrences
- **RuntimeError:** 1 occurrences
- **SyntaxError:** 1 occurrences


---

## 📋 Coverage Recommendations

### Priority Actions (Based on MEASURED Data)

1. **Missing Dependencies** (107 cases)
   - Install required Python packages
   - Update requirements.txt with all dependencies
   
2. **Import Errors** (9 cases)
   - Fix import statements
   - Resolve circular dependencies

3. **Code Quality Issues** (8 error types)
   - Address most common errors first
   - Run automated fixes where possible

---

## 🎯 Coverage Goals vs Actuals

| Metric | Target | Actual (MEASURED) | Status |
|--------|--------|-------------------|--------|
| Agent Pass Rate | 80% | 6.94% | ❌ |
| Test Pass Rate | 90% | 44.88% | ❌ |
| Import Success | 95% | 38.2% | ❌ |

---

**Report Status:** COMPLETE  
**Data Type:** 100% MEASURED (zero estimates)  
**Honesty Mandate:** All values are actual test results
