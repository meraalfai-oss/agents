# Production Deployment Guide - Engine Platform

## 🔧 Installation & Setup

### 1. System Requirements

```bash
# Minimum Requirements
- Python 3.8+
- RAM: 4GB minimum, 8GB recommended
- CPU: 2 cores minimum, 4 cores recommended
- Disk: 10GB free space

# Production Requirements
- Python 3.10+
- RAM: 16GB+
- CPU: 8 cores+
- Disk: 50GB+ SSD
```

### 2. Dependencies Installation

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate  # Windows

# Install core dependencies
pip install --upgrade pip
pip install asyncio logging python-dateutil

# Optional but recommended
pip install jinja2>=3.0.0  # For Generator Engine templates
pip install esprima>=4.0.0  # For JavaScript parsing
pip install tree-sitter-languages>=1.0.0  # For multi-language parsing

# Development dependencies
pip install pytest pytest-asyncio black flake8 mypy

# Monitoring (production)
pip install prometheus-client structlog
```

### 3. Configuration Files

Create `config/production.yaml`:

```yaml
# Engine Configuration
engines:
  parser:
    max_workers: 8
    cache_size: 500
    max_file_size_mb: 20
    enable_metrics: true
    
  generator:
    enable_validation: true
    quality_threshold: 75.0
    enable_metrics: true
    
  intelligence:
    max_agents: 200
    decision_cache_size: 5000
    enable_circuit_breakers: true
    enable_metrics: true

# Logging
logging:
  level: INFO
  format: json
  output: /var/log/engines/app.log
  rotation: daily
  retention_days: 30

# Performance
performance:
  async_workers: 16
  connection_pool_size: 100
  request_timeout_seconds: 300
  health_check_interval: 30

# Monitoring
monitoring:
  enable_prometheus: true
  metrics_port: 9090
  health_check_port: 8080
```

---

## 🐳 Docker Deployment

### Dockerfile

```dockerfile
FROM python:3.10-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    make \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY engines/ ./engines/
COPY config/ ./config/

# Create logs directory
RUN mkdir -p /var/log/engines

# Non-root user
RUN useradd -m -u 1000 engine-user && \
    chown -R engine-user:engine-user /app /var/log/engines
USER engine-user

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD python -c "import asyncio; from engines.health import check; asyncio.run(check())" || exit 1

# Expose ports
EXPOSE 8080 9090

# Run application
CMD ["python", "-m", "engines.main"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  parser-engine:
    build: .
    image: engine-platform/parser:latest
    container_name: parser-engine
    restart: unless-stopped
    environment:
      - ENGINE_TYPE=parser
      - LOG_LEVEL=INFO
      - WORKERS=8
    volumes:
      - ./config:/app/config:ro
      - parser-logs:/var/log/engines
    ports:
      - "8081:8080"
      - "9091:9090"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - engine-network
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 8G
        reservations:
          cpus: '2'
          memory: 4G

  generator-engine:
    build: .
    image: engine-platform/generator:latest
    container_name: generator-engine
    restart: unless-stopped
    environment:
      - ENGINE_TYPE=generator
      - LOG_LEVEL=INFO
      - ENABLE_VALIDATION=true
    volumes:
      - ./config:/app/config:ro
      - generator-logs:/var/log/engines
    ports:
      - "8082:8080"
      - "9092:9090"
    networks:
      - engine-network
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 8G

  intelligence-engine:
    build: .
    image: engine-platform/intelligence:latest
    container_name: intelligence-engine
    restart: unless-stopped
    environment:
      - ENGINE_TYPE=intelligence
      - LOG_LEVEL=INFO
      - MAX_AGENTS=200
    volumes:
      - ./config:/app/config:ro
      - intelligence-logs:/var/log/engines
    ports:
      - "8083:8080"
      - "9093:9090"
    networks:
      - engine-network
    deploy:
      resources:
        limits:
          cpus: '8'
          memory: 16G

  prometheus:
    image: prom/prometheus:latest
    container_name: prometheus
    volumes:
      - ./config/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus-data:/prometheus
    ports:
      - "9094:9090"
    networks:
      - engine-network

  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-data:/var/lib/grafana
    ports:
      - "3000:3000"
    networks:
      - engine-network

volumes:
  parser-logs:
  generator-logs:
  intelligence-logs:
  prometheus-data:
  grafana-data:

networks:
  engine-network:
    driver: bridge
```

---

## ☸️ Kubernetes Deployment

### k8s/deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: parser-engine
  namespace: engines
  labels:
    app: parser-engine
    version: v1
spec:
  replicas: 3
  selector:
    matchLabels:
      app: parser-engine
  template:
    metadata:
      labels:
        app: parser-engine
        version: v1
    spec:
      containers:
      - name: parser-engine
        image: engine-platform/parser:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8080
          name: http
        - containerPort: 9090
          name: metrics
        env:
        - name: ENGINE_TYPE
          value: "parser"
        - name: LOG_LEVEL
          value: "INFO"
        - name: WORKERS
          value: "8"
        resources:
          requests:
            cpu: "2"
            memory: "4Gi"
          limits:
            cpu: "4"
            memory: "8Gi"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
      volumes:
      - name: config
        configMap:
          name: engine-config

---
apiVersion: v1
kind: Service
metadata:
  name: parser-engine-service
  namespace: engines
spec:
  selector:
    app: parser-engine
  ports:
  - name: http
    port: 80
    targetPort: 8080
  - name: metrics
    port: 9090
    targetPort: 9090
  type: ClusterIP

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: parser-engine-hpa
  namespace: engines
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: parser-engine
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## 🔍 Monitoring & Observability

### Prometheus Configuration

```yaml
# config/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'parser-engine'
    static_configs:
      - targets: ['parser-engine:9090']
        labels:
          service: 'parser'
          
  - job_name: 'generator-engine'
    static_configs:
      - targets: ['generator-engine:9090']
        labels:
          service: 'generator'
          
  - job_name: 'intelligence-engine'
    static_configs:
      - targets: ['intelligence-engine:9090']
        labels:
          service: 'intelligence'
```

### Grafana Dashboard JSON

Create dashboards for:
- Engine performance metrics
- Request rates and latencies
- Error rates and circuit breaker states
- Resource utilization (CPU, memory)
- Agent health and availability

---

## 🧪 Testing

### Unit Tests

```python
# tests/test_parser_engine.py
import pytest
import asyncio
from engines.parser_engine import ParserEngine

@pytest.mark.asyncio
async def test_parser_python_code():
    parser = ParserEngine()
    
    code = """
def hello(name: str) -> str:
    return f"Hello, {name}!"
"""
    
    result = await parser.parse(code, "python")
    
    assert result.success
    assert len(result.symbols) > 0
    assert result.language == "python"
    assert result.quality_score > 70

@pytest.mark.asyncio
async def test_parser_invalid_code():
    parser = ParserEngine()
    
    code = "def invalid syntax here"
    result = await parser.parse(code, "python")
    
    assert not result.success
    assert len(result.errors) > 0

# Run: pytest tests/ -v --asyncio-mode=auto
```

### Integration Tests

```python
# tests/test_integration.py
import pytest
import asyncio
from engines.intelligence_engine import IntelligenceEngine

@pytest.mark.asyncio
async def test_full_routing_workflow():
    engine = IntelligenceEngine()
    await engine.initialize()
    
    # Register agents
    await engine.register_agent("agent1", {
        'capabilities': ['parsing', 'validation']
    })
    
    # Route task
    decision = await engine.route_task("parsing")
    
    assert decision.agent_id == "agent1"
    assert decision.confidence > 0.5
    
    # Update health
    await engine.update_agent_health("agent1", {
        'status': 'healthy',
        'load': 0.3
    })
    
    # Record result
    await engine.record_task_result(
        "agent1", "parsing", 
        success=True, duration=1.5
    )
    
    status = engine.get_system_status()
    assert status['agents']['healthy'] == 1
```

### Load Testing

```python
# tests/load_test.py
import asyncio
import time
from engines.parser_engine import ParserEngine

async def load_test(concurrent_requests=100):
    parser = ParserEngine(max_workers=8)
    
    code = "def test(): pass"
    
    async def parse_task():
        return await parser.parse(code, "python")
    
    start = time.time()
    tasks = [parse_task() for _ in range(concurrent_requests)]
    results = await asyncio.gather(*tasks)
    duration = time.time() - start
    
    success_count = sum(1 for r in results if r.success)
    
    print(f"Processed {concurrent_requests} requests in {duration:.2f}s")
    print(f"Success rate: {success_count/concurrent_requests*100:.1f}%")
    print(f"Throughput: {concurrent_requests/duration:.1f} req/s")

if __name__ == "__main__":
    asyncio.run(load_test(100))
```

---

## 🔒 Security Considerations

### 1. Input Validation

```python
# Implement in all engines
def validate_input(code: str, max_size: int = 10_000_000) -> bool:
    """Validate input before processing"""
    if not code or not code.strip():
        raise ValueError("Empty input")
    
    if len(code.encode('utf-8')) > max_size:
        raise ValueError(f"Input exceeds {max_size} bytes")
    
    # Check for suspicious patterns
    suspicious_patterns = [
        r'__import__\s*\(',
        r'eval\s*\(',
        r'exec\s*\(',
        r'compile\s*\('
    ]
    
    import re
    for pattern in suspicious_patterns:
        if re.search(pattern, code):
            raise ValueError("Suspicious code pattern detected")
    
    return True
```

### 2. Rate Limiting

```python
# Add to Intelligence Engine
from collections import defaultdict
import time

class RateLimiter:
    def __init__(self, requests_per_minute: int = 100):
        self.rpm = requests_per_minute
        self.requests = defaultdict(list)
    
    def check_limit(self, client_id: str) -> bool:
        now = time.time()
        minute_ago = now - 60
        
        # Clean old requests
        self.requests[client_id] = [
            req_time for req_time in self.requests[client_id]
            if req_time > minute_ago
        ]
        
        if len(self.requests[client_id]) >= self.rpm:
            return False
        
        self.requests[client_id].append(now)
        return True
```

### 3. Authentication

```python
# Add JWT authentication
import jwt
from datetime import datetime, timedelta

def generate_token(user_id: str, secret: str) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(hours=24)
    }
    return jwt.encode(payload, secret, algorithm='HS256')

def verify_token(token: str, secret: str) -> dict:
    try:
        return jwt.decode(token, secret, algorithms=['HS256'])
    except jwt.ExpiredSignatureError:
        raise ValueError("Token expired")
    except jwt.InvalidTokenError:
        raise ValueError("Invalid token")
```

---

## 📊 Performance Optimization

### 1. Caching Strategy

```python
# Implement Redis caching
import redis.asyncio as redis
import json

class CacheManager:
    def __init__(self, redis_url: str):
        self.redis = redis.from_url(redis_url)
    
    async def get(self, key: str):
        value = await self.redis.get(key)
        return json.loads(value) if value else None
    
    async def set(self, key: str, value: any, ttl: int = 3600):
        await self.redis.setex(
            key, ttl, json.dumps(value)
        )
    
    async def invalidate(self, pattern: str):
        keys = await self.redis.keys(pattern)
        if keys:
            await self.redis.delete(*keys)
```

### 2. Connection Pooling

```python
# PostgreSQL connection pool
import asyncpg

class DatabasePool:
    def __init__(self, dsn: str, min_size: int = 10, max_size: int = 100):
        self.dsn = dsn
        self.min_size = min_size
        self.max_size = max_size
        self.pool = None
    
    async def initialize(self):
        self.pool = await asyncpg.create_pool(
            self.dsn,
            min_size=self.min_size,
            max_size=self.max_size,
            command_timeout=60
        )
    
    async def execute(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.execute(query, *args)
    
    async def fetch(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetch(query, *args)
    
    async def close(self):
        await self.pool.close()
```

---

## 🚨 Error Handling & Logging

### Structured Logging

```python
import structlog
import logging

def setup_logging(level: str = "INFO", format_type: str = "json"):
    """Setup structured logging"""
    
    logging.basicConfig(
        format="%(message)s",
        level=getattr(logging, level.upper())
    )
    
    processors = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]
    
    if format_type == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())
    
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

# Usage
logger = structlog.get_logger()
logger.info("engine_started", engine_type="parser", version="3.0")
```

---

## 📝 Production Checklist

### Pre-Deployment
- [ ] All unit tests passing
- [ ] Integration tests passing
- [ ] Load tests completed
- [ ] Security audit completed
- [ ] Dependencies updated
- [ ] Configuration validated
- [ ] Documentation updated
- [ ] Backup strategy defined
- [ ] Rollback plan created
- [ ] Monitoring dashboards configured

### Deployment
- [ ] Blue-green deployment ready
- [ ] Database migrations tested
- [ ] Environment variables set
- [ ] SSL certificates installed
- [ ] Firewall rules configured
- [ ] Load balancer configured
- [ ] Health checks working
- [ ] Logging aggregation active
- [ ] Metrics collection active
- [ ] Alerts configured

### Post-Deployment
- [ ] Smoke tests passed
- [ ] Performance metrics normal
- [ ] Error rates acceptable
- [ ] Resource utilization optimal
- [ ] Logs being collected
- [ ] Metrics visible in Grafana
- [ ] Alerts functional
- [ ] Documentation updated
- [ ] Team notified
- [ ] Post-mortem scheduled

---

## 🆘 Troubleshooting

### Common Issues

**Issue: High memory usage**
```bash
# Check memory usage
docker stats parser-engine

# Reduce cache size in config
parser:
  cache_size: 100  # Reduce from 500
```

**Issue: Slow parsing**
```bash
# Increase workers
parser:
  max_workers: 16  # Increase from 8

# Check for file size issues
parser:
  max_file_size_mb: 10  # Reduce if needed
```

**Issue: Circuit breakers stuck open**
```python
# Reset circuit breakers
engine = IntelligenceEngine()
for agent_id in engine.circuit_breakers:
    breaker = engine.circuit_breakers[agent_id]
    breaker.state = 'closed'
    breaker.failures = 0
```

---

## 📞 Support

For issues or questions:
- GitHub Issues: https://github.com/your-org/engine-platform/issues
- Documentation: https://docs.engine-platform.com
- Slack: #engine-platform

---

## 📄 License

MIT License - See LICENSE file for details