# YMERA Deployment Guide

**Version:** 2.0.0  
**Last Updated:** 2025-10-21

---

## Prerequisites

- Python 3.11+
- PostgreSQL 14+
- Redis 7+
- 4GB RAM minimum
- Ubuntu 20.04+ or equivalent Linux distribution

## Local Development

### 1. Clone Repository

```bash
git clone <your-repo-url>
cd ymera
```

### 2. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your settings:

```env
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/ymera
ASYNC_DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/ymera

# Redis
REDIS_URL=redis://localhost:6379/0

# API
API_HOST=0.0.0.0
API_PORT=8000
SECRET_KEY=your-secret-key-here

# Logging
LOG_LEVEL=INFO
```

### 5. Initialize Database

```bash
# Run migrations
alembic upgrade head

# Seed data (optional)
python3 scripts/seed_data.py
```

### 6. Run API Server

```bash
python3 api/gateway.py
```

API will be available at: `http://localhost:8000`

### 7. Test Installation

```bash
# Health check
curl http://localhost:8000/health

# List agents
curl http://localhost:8000/agents

# Run test suite
python3 cleanup/07_complete_test_suite.py
```

---

## Production Deployment

### Option 1: Docker

#### Build Image

```bash
docker build -t ymera-api:latest .
```

#### Run Container

```bash
docker run -d   --name ymera-api   -p 8000:8000   --env-file .env   ymera-api:latest
```

#### Docker Compose

```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/ymera
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - db
      - redis
    restart: unless-stopped
  
  db:
    image: postgres:14
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=ymera
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped
  
  redis:
    image: redis:7
    restart: unless-stopped

volumes:
  postgres_data:
```

Run with:
```bash
docker-compose up -d
```

---

### Option 2: Systemd Service

#### Create Service File

`/etc/systemd/system/ymera-api.service`:

```ini
[Unit]
Description=YMERA API Gateway
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=ymera
WorkingDirectory=/opt/ymera
Environment="PATH=/opt/ymera/venv/bin"
ExecStart=/opt/ymera/venv/bin/python3 /opt/ymera/api/gateway.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

#### Enable and Start

```bash
sudo systemctl daemon-reload
sudo systemctl enable ymera-api
sudo systemctl start ymera-api
sudo systemctl status ymera-api
```

---

### Option 3: Kubernetes

#### Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ymera-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ymera-api
  template:
    metadata:
      labels:
        app: ymera-api
    spec:
      containers:
      - name: api
        image: ymera-api:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: ymera-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: ymera-secrets
              key: redis-url
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

#### Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: ymera-api
spec:
  selector:
    app: ymera-api
  ports:
  - port: 80
    targetPort: 8000
  type: LoadBalancer
```

Deploy:
```bash
kubectl apply -f k8s/
```

---

## Reverse Proxy (Nginx)

### Configuration

`/etc/nginx/sites-available/ymera`:

```nginx
upstream ymera_api {
    server localhost:8000;
}

server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://ymera_api;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/ymera /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## SSL/TLS (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d api.yourdomain.com
```

---

## Monitoring

### Prometheus

Add to `prometheus.yml`:

```yaml
scrape_configs:
  - job_name: 'ymera-api'
    static_configs:
      - targets: ['localhost:8000']
```

### Health Checks

Setup monitoring for:
- `GET /health` - every 30 seconds
- Alert if status != "healthy"
- Alert if response time > 5s

---

## Backup & Recovery

### Database Backup

```bash
# Daily backup
pg_dump ymera > backup_$(date +%Y%m%d).sql

# Restore
psql ymera < backup_20251021.sql
```

### Application State

```bash
# Backup configuration
tar -czf config_backup.tar.gz .env agents/ core/

# Backup logs
tar -czf logs_backup.tar.gz /var/log/ymera/
```

---

## Performance Tuning

### Database

```sql
-- Increase connection pool
ALTER SYSTEM SET max_connections = 200;
ALTER SYSTEM SET shared_buffers = '2GB';
```

### API Server

```python
# In api/gateway.py
uvicorn.run(
    app, 
    host="0.0.0.0", 
    port=8000,
    workers=4,  # Number of worker processes
    limit_concurrency=1000,
    timeout_keep_alive=5
)
```

### Redis

```conf
# /etc/redis/redis.conf
maxmemory 2gb
maxmemory-policy allkeys-lru
```

---

## Security Checklist

- [ ] Use strong SECRET_KEY
- [ ] Enable HTTPS/TLS
- [ ] Configure firewall (allow only 80, 443)
- [ ] Use environment variables for secrets
- [ ] Regular security updates
- [ ] Enable API authentication
- [ ] Set up rate limiting
- [ ] Configure CORS properly
- [ ] Regular backups
- [ ] Monitor logs for suspicious activity

---

## Troubleshooting

### API Won't Start

```bash
# Check logs
journalctl -u ymera-api -f

# Check port availability
sudo netstat -tlnp | grep 8000

# Check Python environment
which python3
python3 --version
```

### Database Connection Issues

```bash
# Test connection
psql -U user -d ymera -h localhost

# Check PostgreSQL status
sudo systemctl status postgresql
```

### High Memory Usage

```bash
# Check process memory
ps aux | grep python

# Check system resources
htop

# Reduce workers in uvicorn
```

---

## Scaling

### Horizontal Scaling

1. Deploy multiple API instances
2. Use load balancer (Nginx, HAProxy)
3. Share Redis and PostgreSQL
4. Use session affinity if needed

### Vertical Scaling

1. Increase server resources
2. Tune database parameters
3. Increase worker processes
4. Optimize queries

---

## Maintenance

### Regular Tasks

- Daily: Check logs and monitoring
- Weekly: Review performance metrics
- Monthly: Update dependencies
- Quarterly: Security audit

### Updates

```bash
# Update dependencies
pip install --upgrade -r requirements.txt

# Run migrations
alembic upgrade head

# Restart service
sudo systemctl restart ymera-api
```

---

## Support

For deployment issues:
- Check logs in `/var/log/ymera/`
- Review API_DOCS.md for API usage
- Check ARCHITECTURE.md for system design
- Create issue in repository
