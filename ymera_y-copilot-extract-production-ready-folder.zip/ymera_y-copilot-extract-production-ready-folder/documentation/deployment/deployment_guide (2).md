# YMERA Agent Manager - Production Deployment Guide

## Overview

This guide covers the complete production deployment of the YMERA Agent Management System, including the Agent Manager and Agent Coordinator.

## Architecture Summary

```
┌─────────────┐
│   Users     │
└──────┬──────┘
       │
       ▼
┌─────────────────────────┐
│  Agent Coordinator      │ ◄── Understands requests, plans workflows
└──────┬──────────────────┘
       │
       ▼
┌─────────────────────────┐
│   Agent Manager         │ ◄── Manages all agents, enforces policies
└──────┬──────────────────┘
       │
       ├──► Coding Agent
       ├──► Enhancement Agent
       ├──► Examination Agent
       ├──► Testing Agent
       ├──► Documentation Agent
       ├──► Security Agent
       ├──► Deployment Agent
       ├──► Learning Agent
       └──► Project Agent (Integration)
```

## Prerequisites

### System Requirements
- Python 3.11+
- PostgreSQL 14+ (with asyncpg support)
- Redis 7+ (for caching)
- RabbitMQ 3.12+ or Kafka (for message broker)
- Minimum 4 CPU cores, 8GB RAM for manager
- Monitoring stack (Prometheus + Grafana)

### Python Dependencies

```bash
# Core dependencies
sqlalchemy[asyncio]>=2.0.0
asyncpg>=0.29.0
pydantic>=2.5.0
structlog>=23.2.0
prometheus-client>=0.19.0
tenacity>=8.2.3
circuitbreaker>=1.4.0

# Optional but recommended
redis>=5.0.0
aioredis>=2.0.1
pika>=1.3.2  # for RabbitMQ
kafka-python>=2.0.2  # for Kafka
cryptography>=41.0.7
python-jose[cryptography]>=3.3.0
```

## Configuration

### Environment Variables

Create a `.env` file:

```bash
# Database
AGENT_MANAGER_DB_CONNECTION_STRING=postgresql+asyncpg://user:password@localhost:5432/ymera
AGENT_MANAGER_DB_POOL_SIZE=20
AGENT_MANAGER_DB_POOL_TIMEOUT=30

# Cache
REDIS_URL=redis://localhost:6379/0
CACHE_TTL=3600

# Message Broker
RABBITMQ_URL=amqp://user:password@localhost:5672/
MESSAGE_BROKER_TYPE=rabbitmq  # or kafka

# Monitoring
AGENT_MANAGER_MONITORING_INTERVAL=30
AGENT_MANAGER_MAX_AGENT_SILENCE=300
AGENT_MANAGER_REPORTING_INTERVAL=60

# Security
AGENT_MANAGER_CREDENTIAL_ROTATION_DAYS=90
AGENT_MANAGER_MAX_FAILED_AUTH_ATTEMPTS=5
ENCRYPTION_KEY=<generate-secure-key>

# Performance
AGENT_MANAGER_MAX_REPORTS_PER_MINUTE=100
AGENT_MANAGER_MAX_CONCURRENT_WORKFLOWS=100

# Feature Flags
AGENT_MANAGER_ENABLE_AUTO_SCALING=true
AGENT_MANAGER_ENABLE_AUDIT_LOGGING=true
AGENT_MANAGER_ENABLE_PERFORMANCE_PROFILING=false
AGENT_MANAGER_STRICT_VALIDATION=true

# Prometheus
PROMETHEUS_PORT=9090
PROMETHEUS_MULTIPROC_DIR=/tmp/prometheus_multiproc

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
```

## Database Setup

### 1. Create Database

```sql
-- Create database
CREATE DATABASE ymera;

-- Create user
CREATE USER ymera_user WITH ENCRYPTED PASSWORD 'secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE ymera TO ymera_user;

-- Connect to database
\c ymera

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
```

### 2. Run Migrations

The application will create tables automatically, but for production, use Alembic:

```bash
# Initialize Alembic
alembic init migrations

# Create migration
alembic revision --autogenerate -m "Initial schema"

# Apply migration
alembic upgrade head
```

### 3. Create Indexes

```sql
-- Performance indexes
CREATE INDEX CONCURRENTLY idx_agents_status_heartbeat 
ON agents (status, last_heartbeat DESC);

CREATE INDEX CONCURRENTLY idx_agent_reports_agent_timestamp 
ON agent_reports (agent_id, timestamp DESC);

CREATE INDEX CONCURRENTLY idx_agent_tasks_agent_status 
ON agent_tasks (agent_id, status) 
WHERE status IN ('pending', 'in_progress');

-- Full-text search indexes
CREATE INDEX CONCURRENTLY idx_agents_config_gin 
ON agents USING gin (config);
```

## Deployment Steps

### 1. Application Setup

```bash
# Clone repository
git clone <repository-url>
cd agent-manager

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create necessary directories
mkdir -p logs metrics data

# Set permissions
chmod 755 logs metrics data
```

### 2. Initialize Agent Manager

```python
# main.py
import asyncio
import os
from dotenv import load_dotenv
from agent_manager import create_agent_manager, AgentManagerConfig
from agent_coordinator import AgentCoordinator, CoordinatorAPI

# Load environment variables
load_dotenv()

async def main():
    # Configuration from environment
    config = AgentManagerConfig(
        db_connection_string=os.getenv("AGENT_MANAGER_DB_CONNECTION_STRING"),
        db_pool_size=int(os.getenv("AGENT_MANAGER_DB_POOL_SIZE", 20)),
        monitoring_interval=int(os.getenv("AGENT_MANAGER_MONITORING_INTERVAL", 30)),
        max_agent_silence=int(os.getenv("AGENT_MANAGER_MAX_AGENT_SILENCE", 300)),
        enable_audit_logging=os.getenv("AGENT_MANAGER_ENABLE_AUDIT_LOGGING", "true").lower() == "true"
    )
    
    # Create and start agent manager
    agent_manager = await create_agent_manager(config.dict())
    
    # Create coordinator
    coordinator = AgentCoordinator(
        agent_manager=agent_manager,
        db_session=agent_manager.db,
        config=config.dict()
    )
    
    # Create API
    api = CoordinatorAPI(coordinator)
    
    try:
        # Keep running
        print("Agent Manager started successfully")
        await asyncio.Event().wait()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await agent_manager.stop()

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. FastAPI Integration

```python
# api_server.py
from fastapi import FastAPI, Depends, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn

from agent_manager import create_agent_manager, AgentManagerConfig
from agent_coordinator import AgentCoordinator, CoordinatorAPI
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

# Global instances
agent_manager_instance = None
coordinator_instance = None
api_instance = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global agent_manager_instance, coordinator_instance, api_instance
    
    config = AgentManagerConfig(
        db_connection_string=os.getenv("AGENT_MANAGER_DB_CONNECTION_STRING"),
        # ... other config
    )
    
    agent_manager_instance = await create_agent_manager(config.dict())
    coordinator_instance = AgentCoordinator(
        agent_manager=agent_manager_instance,
        db_session=agent_manager_instance.db,
        config=config.dict()
    )
    api_instance = CoordinatorAPI(coordinator_instance)
    
    yield
    
    # Shutdown
    await agent_manager_instance.stop()

# Create FastAPI app
app = FastAPI(
    title="YMERA Agent Manager API",
    version="2.1.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request models
class SubmitRequestModel(BaseModel):
    user_id: str
    message: str
    files: Optional[List[Dict[str, Any]]] = None
    priority: str = "medium"

class ApproveWorkflowModel(BaseModel):
    request_id: str
    actions: List[str]
    user_id: str

# Endpoints
@app.post("/api/v1/requests/submit")
async def submit_request(request: SubmitRequestModel):
    """Submit a new user request"""
    try:
        result = await api_instance.submit_request(
            user_id=request.user_id,
            message=request.message,
            files=request.files,
            priority=request.priority
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/workflows/{workflow_id}/status")
async def get_workflow_status(workflow_id: str):
    """Get workflow status"""
    try:
        status = await api_instance.check_status(workflow_id)
        return status
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/workflows/approve")
async def approve_workflow(request: ApproveWorkflowModel):
    """Approve pending workflow"""
    try:
        result = await api_instance.approve_actions(
            request_id=request.request_id,
            actions=request.actions,
            user_id=request.user_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    if agent_manager_instance:
        health = await agent_manager_instance.get_health()
        return health
    return {"status": "initializing"}

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
    from starlette.responses import Response
    
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

if __name__ == "__main__":
    uvicorn.run(
        "api_server:app",
        host="0.0.0.0",
        port=8000,
        workers=4,
        log_level="info"
    )
```

### 4. Docker Deployment

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Create non-root user
RUN useradd -m -u 1000 ymera && \
    chown -R ymera:ymera /app

USER ymera

# Expose ports
EXPOSE 8000 9090

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD python -c "import requests; requests.get('http://localhost:8000/health')"

# Start application
CMD ["uvicorn", "api_server:app", "--host", "0.0.0.0", "--port", "8000"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: ymera
      POSTGRES_USER: ymera_user
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ymera_user"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    command: redis-server --appendonly yes

  rabbitmq:
    image: rabbitmq:3.12-management-alpine
    ports:
      - "5672:5672"
      - "15672:15672"
    environment:
      RABBITMQ_DEFAULT_USER: ymera
      RABBITMQ_DEFAULT_PASS: secure_password
    volumes:
      - rabbitmq_data:/var/lib/rabbitmq

  agent-manager:
    build: .
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_started
      rabbitmq:
        condition: service_started
    environment:
      - AGENT_MANAGER_DB_CONNECTION_STRING=postgresql+asyncpg://ymera_user:secure_password@postgres:5432/ymera
      - REDIS_URL=redis://redis:6379/0
      - RABBITMQ_URL=amqp://ymera:secure_password@rabbitmq:5672/
    ports:
      - "8000:8000"
      - "9090:9090"
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    restart: unless-stopped

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9091:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    volumes:
      - grafana_data:/var/lib/grafana
      - ./grafana-dashboards:/etc/grafana/provisioning/dashboards
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin

volumes:
  postgres_data:
  redis_data:
  rabbitmq_data:
  prometheus_data:
  grafana_data:
```

### 5. Kubernetes Deployment

```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: ymera-agents

---
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: agent-manager-config
  namespace: ymera-agents
data:
  AGENT_MANAGER_MONITORING_INTERVAL: "30"
  AGENT_MANAGER_MAX_AGENT_SILENCE: "300"
  AGENT_MANAGER_REPORTING_INTERVAL: "60"
  AGENT_MANAGER_ENABLE_AUDIT_LOGGING: "true"

---
# k8s/secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: agent-manager-secrets
  namespace: ymera-agents
type: Opaque
stringData:
  AGENT_MANAGER_DB_CONNECTION_STRING: "postgresql+asyncpg://user:pass@postgres:5432/ymera"
  REDIS_URL: "redis://redis:6379/0"
  RABBITMQ_URL: "amqp://user:pass@rabbitmq:5672/"
  ENCRYPTION_KEY: "your-secure-encryption-key"

---
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-manager
  namespace: ymera-agents
spec:
  replicas: 3
  selector:
    matchLabels:
      app: agent-manager
  template:
    metadata:
      labels:
        app: agent-manager
    spec:
      containers:
      - name: agent-manager
        image: ymera/agent-manager:2.1.0
        ports:
        - containerPort: 8000
          name: http
        - containerPort: 9090
          name: metrics
        envFrom:
        - configMapRef:
            name: agent-manager-config
        - secretRef:
            name: agent-manager-secrets
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
        volumeMounts:
        - name: logs
          mountPath: /app/logs
      volumes:
      - name: logs
        persistentVolumeClaim:
          claimName: agent-manager-logs

---
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: agent-manager
  namespace: ymera-agents
spec:
  selector:
    app: agent-manager
  ports:
  - name: http
    port: 80
    targetPort: 8000
  - name: metrics
    port: 9090
    targetPort: 9090
  type: ClusterIP

---
# k8s/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: agent-manager-ingress
  namespace: ymera-agents
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/rate-limit: "100"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - api.ymera.com
    secretName: agent-manager-tls
  rules:
  - host: api.ymera.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: agent-manager
            port:
              number: 80

---
# k8s/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: agent-manager-hpa
  namespace: ymera-agents
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: agent-manager
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

## Monitoring & Observability

### Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'agent-manager'
    static_configs:
      - targets: ['agent-manager:9090']
    metrics_path: '/metrics'

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']

alerting:
  alertmanagers:
    - static_configs:
        - targets: ['alertmanager:9093']

rule_files:
  - 'alerts.yml'
```

### Alert Rules

```yaml
# alerts.yml
groups:
  - name: agent_manager_alerts
    interval: 30s
    rules:
      - alert: HighErrorRate
        expr: rate(agent_manager_errors_total[5m]) > 0.1
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High error rate in Agent Manager"
          description: "Error rate is {{ $value }} errors/sec"

      - alert: AgentUnresponsive
        expr: agent_manager_active_agents{status="error"} > 0
        for: 2m
        labels:
          severity: warning
        annotations:
          summary: "Agent(s) unresponsive"
          description: "{{ $value }} agent(s) are not responding"

      - alert: DatabaseConnectionPoolExhausted
        expr: agent_manager_db_connections > 18
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Database connection pool near capacity"
          description: "Connection pool at {{ $value }}/20 connections"

      - alert: HighMemoryUsage
        expr: process_resident_memory_bytes > 1.5e9
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High memory usage"
          description: "Memory usage is {{ $value | humanize }}B"
```

### Grafana Dashboard

```json
{
  "dashboard": {
    "title": "YMERA Agent Manager",
    "panels": [
      {
        "title": "Active Agents",
        "targets": [
          {
            "expr": "agent_manager_active_agents"
          }
        ]
      },
      {
        "title": "Operation Rate",
        "targets": [
          {
            "expr": "rate(agent_manager_operations_total[5m])"
          }
        ]
      },
      {
        "title": "Error Rate",
        "targets": [
          {
            "expr": "rate(agent_manager_errors_total[5m])"
          }
        ]
      },
      {
        "title": "Response Time P95",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(agent_manager_operation_duration_seconds_bucket[5m]))"
          }
        ]
      }
    ]
  }
}
```

## Security Hardening

### 1. Network Security

```yaml
# k8s/network-policy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: agent-manager-network-policy
  namespace: ymera-agents
spec:
  podSelector:
    matchLabels:
      app: agent-manager
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    ports:
    - protocol: TCP
      port: 8000
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: postgres
    ports:
    - protocol: TCP
      port: 5432
  - to:
    - podSelector:
        matchLabels:
          app: redis
    ports:
    - protocol: TCP
      port: 6379
```

### 2. RBAC Configuration

```yaml
# k8s/rbac.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: agent-manager
  namespace: ymera-agents

---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: agent-manager-role
  namespace: ymera-agents
rules:
- apiGroups: [""]
  resources: ["configmaps", "secrets"]
  verbs: ["get", "list"]
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "list", "watch"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: agent-manager-rolebinding
  namespace: ymera-agents
subjects:
- kind: ServiceAccount
  name: agent-manager
  namespace: ymera-agents
roleRef:
  kind: Role
  name: agent-manager-role
  apiGroup: rbac.authorization.k8s.io
```

### 3. Pod Security Policy

```yaml
# k8s/psp.yaml
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: agent-manager-psp
spec:
  privileged: false
  allowPrivilegeEscalation: false
  requiredDropCapabilities:
    - ALL
  volumes:
    - 'configMap'
    - 'secret'
    - 'persistentVolumeClaim'
  hostNetwork: false
  hostIPC: false
  hostPID: false
  runAsUser:
    rule: 'MustRunAsNonRoot'
  seLinux:
    rule: 'RunAsAny'
  fsGroup:
    rule: 'RunAsAny'
```

## Performance Optimization

### 1. Database Optimization

```sql
-- Partitioning for large tables
CREATE TABLE agent_reports_partitioned (
    LIKE agent_reports INCLUDING ALL
) PARTITION BY RANGE (timestamp);

-- Create monthly partitions
CREATE TABLE agent_reports_2024_01 PARTITION OF agent_reports_partitioned
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

-- Automated partition creation function
CREATE OR REPLACE FUNCTION create_monthly_partition()
RETURNS void AS $
DECLARE
    partition_date DATE;
    partition_name TEXT;
    start_date TEXT;
    end_date TEXT;
BEGIN
    partition_date := DATE_TRUNC('month', CURRENT_DATE + INTERVAL '1 month');
    partition_name := 'agent_reports_' || TO_CHAR(partition_date, 'YYYY_MM');
    start_date := TO_CHAR(partition_date, 'YYYY-MM-DD');
    end_date := TO_CHAR(partition_date + INTERVAL '1 month', 'YYYY-MM-DD');
    
    EXECUTE format(
        'CREATE TABLE IF NOT EXISTS %I PARTITION OF agent_reports_partitioned
         FOR VALUES FROM (%L) TO (%L)',
        partition_name, start_date, end_date
    );
END;
$ LANGUAGE plpgsql;

-- Connection pooling configuration
ALTER SYSTEM SET max_connections = 200;
ALTER SYSTEM SET shared_buffers = '2GB';
ALTER SYSTEM SET effective_cache_size = '6GB';
ALTER SYSTEM SET maintenance_work_mem = '512MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;
```

### 2. Caching Strategy

```python
# caching_config.py
CACHE_STRATEGIES = {
    "agent_info": {
        "ttl": 3600,  # 1 hour
        "key_pattern": "agent:{agent_id}:info"
    },
    "agent_metrics": {
        "ttl": 300,  # 5 minutes
        "key_pattern": "agent:{agent_id}:metrics:latest"
    },
    "workflow_status": {
        "ttl": 60,  # 1 minute
        "key_pattern": "workflow:{workflow_id}:status"
    },
    "system_overview": {
        "ttl": 30,  # 30 seconds
        "key_pattern": "system:overview"
    }
}
```

## Backup & Disaster Recovery

### 1. Database Backup

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DB_NAME="ymera"

# Full backup
pg_dump -h localhost -U ymera_user -F c -b -v \
    -f "${BACKUP_DIR}/ymera_full_${TIMESTAMP}.backup" \
    ${DB_NAME}

# Backup retention (keep 7 days)
find ${BACKUP_DIR} -name "ymera_full_*.backup" -mtime +7 -delete

# Upload to S3 (optional)
aws s3 cp "${BACKUP_DIR}/ymera_full_${TIMESTAMP}.backup" \
    s3://ymera-backups/database/
```

### 2. Disaster Recovery Plan

```yaml
# Kubernetes CronJob for automated backups
apiVersion: batch/v1
kind: CronJob
metadata:
  name: database-backup
  namespace: ymera-agents
spec:
  schedule: "0 2 * * *"  # Daily at 2 AM
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: backup
            image: postgres:15-alpine
            env:
            - name: PGPASSWORD
              valueFrom:
                secretKeyRef:
                  name: postgres-secret
                  key: password
            command:
            - /bin/sh
            - -c
            - |
              pg_dump -h postgres -U ymera_user -F c \
                -f /backups/backup_$(date +%Y%m%d_%H%M%S).backup ymera
            volumeMounts:
            - name: backup-storage
              mountPath: /backups
          volumes:
          - name: backup-storage
            persistentVolumeClaim:
              claimName: backup-pvc
          restartPolicy: OnFailure
```

## Testing

### 1. Unit Tests

```python
# tests/test_agent_manager.py
import pytest
from agent_manager import ProductionAgentManager, AgentManagerConfig
from agent_manager import AgentRegistrationRequest, AgentType

@pytest.mark.asyncio
async def test_register_agent():
    config = AgentManagerConfig(
        db_connection_string="postgresql+asyncpg://test:test@localhost/test_db"
    )
    manager = ProductionAgentManager(config)
    await manager.start()
    
    try:
        request = AgentRegistrationRequest(
            agent_id="test_agent_001",
            agent_type=AgentType.CODING,
            capabilities=["python"],
            config={}
        )
        
        result = await manager.register_agent(request)
        
        assert result["status"] == "registered"
        assert "credentials" in result
    finally:
        await manager.stop()
```

### 2. Integration Tests

```python
# tests/test_integration.py
import pytest
from agent_coordinator import AgentCoordinator, UserRequest, Priority

@pytest.mark.asyncio
async def test_end_to_end_workflow():
    # Setup
    manager = await setup_test_manager()
    coordinator = AgentCoordinator(manager, db_session, config)
    
    # Submit request
    request = UserRequest(
        user_id="test_user",
        message="Enhance this code",
        files=[{"name": "test.py", "content": "def test(): pass"}],
        priority=Priority.MEDIUM
    )
    
    result = await coordinator.process_user_request(request)
    
    assert result["status"] in ["completed", "pending_approval"]
    assert "workflow_id" in result or "request_id" in result
```

### 3. Load Testing

```python
# load_test.py
import asyncio
from locust import User, task, between
import aiohttp

class AgentManagerUser(User):
    wait_time = between(1, 3)
    
    @task
    def submit_request(self):
        payload = {
            "user_id": "test_user",
            "message": "Test request",
            "priority": "medium"
        }
        self.client.post("/api/v1/requests/submit", json=payload)
    
    @task(2)
    def check_health(self):
        self.client.get("/health")
```

## Troubleshooting

### Common Issues

1. **High Memory Usage**
   ```bash
   # Check memory usage
   kubectl top pods -n ymera-agents
   
   # Restart pods if needed
   kubectl rollout restart deployment/agent-manager -n ymera-agents
   ```

2. **Database Connection Issues**
   ```bash
   # Check connections
   psql -h localhost -U ymera_user -d ymera \
     -c "SELECT count(*) FROM pg_stat_activity;"
   
   # Kill idle connections
   psql -h localhost -U ymera_user -d ymera \
     -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity 
         WHERE state = 'idle' AND state_change < now() - interval '5 minutes';"
   ```

3. **Agent Unresponsive**
   ```bash
   # Check agent status via API
   curl http://localhost:8000/api/v1/agents/agent_001/status
   
   # Check logs
   kubectl logs -n ymera-agents deployment/agent-manager --tail=100
   ```

## Maintenance

### Regular Tasks

1. **Weekly**
   - Review error logs
   - Check disk usage
   - Verify backup success
   - Review security alerts

2. **Monthly**
   - Update dependencies
   - Rotate credentials
   - Archive old data
   - Review performance metrics

3. **Quarterly**
   - Disaster recovery drill
   - Security audit
   - Capacity planning review

## Production Checklist

- [ ] Database configured with connection pooling
- [ ] Redis cache configured and tested
- [ ] Message broker (RabbitMQ/Kafka) configured
- [ ] Prometheus metrics collection enabled
- [ ] Grafana dashboards deployed
- [ ] Alert rules configured
- [ ] Backup strategy implemented and tested
- [ ] Disaster recovery plan documented
- [ ] Load testing completed
- [ ] Security hardening applied
- [ ] RBAC and network policies configured
- [ ] Monitoring and logging verified
- [ ] Health checks configured
- [ ] Auto-scaling rules tested
- [ ] Documentation complete

## Support & Maintenance

For issues and support:
- GitHub Issues: [repository-url]/issues
- Documentation: https://docs.ymera.com
- Email: support@ymera.com