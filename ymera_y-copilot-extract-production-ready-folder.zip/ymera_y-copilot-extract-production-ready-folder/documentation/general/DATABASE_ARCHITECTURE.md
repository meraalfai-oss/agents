# YMERA Database System V5 - Architecture Documentation

## 📋 System Overview

**Database Type**: PostgreSQL / MySQL / SQLite (Multi-database support)  
**ORM Framework**: SQLAlchemy 2.0 (Async)  
**Architecture Pattern**: Repository Pattern with Service Layer  
**Migration System**: Custom + Alembic Compatible  
**Version**: 5.0.0

---

## 🏗️ Architecture Layers

### 1. Data Layer (Models)
- **Location**: `database_core_integrated.py` (Lines 100-448)
- **Purpose**: Define database schema and relationships
- **Components**:
  - Base Models with mixins
  - Core entity models
  - Association tables
  - Indexes and constraints

### 2. Repository Layer
- **Location**: `database_core_integrated.py` (Lines 853-918)
- **Purpose**: Data access abstraction
- **Components**:
  - BaseRepository for CRUD operations
  - Custom repositories for complex queries
  - Transaction management

### 3. Service Layer (Database Manager)
- **Location**: `database_core_integrated.py` (Lines 496-808)
- **Purpose**: Business logic and orchestration
- **Components**:
  - Connection management
  - Health monitoring
  - Optimization routines
  - Statistics aggregation

### 4. Migration Layer
- **Location**: `database_core_integrated.py` (Lines 453-491)
- **Purpose**: Schema version control
- **Components**:
  - Migration base class
  - Version tracking
  - Rollback support
  - Validation hooks

---

## 📊 Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    User ||--o{ Project : owns
    User ||--o{ Task : creates
    User ||--o{ File : uploads
    User ||--o{ AuditLog : generates
    
    Project ||--o{ Task : contains
    Project ||--o{ File : stores
    Project }o--o{ Agent : assigns
    
    Agent ||--o{ Task : executes
    
    Task }o--|| Task : parent_child
    
    User {
        string id PK
        string username UK
        string email UK
        string password_hash
        string role
        json permissions
        datetime created_at
        boolean is_active
    }
    
    Project {
        string id PK
        string name
        string owner_id FK
        string status
        float progress
        json settings
        datetime created_at
    }
    
    Agent {
        string id PK
        string name
        string agent_type
        json capabilities
        float success_rate
        datetime last_active
    }
    
    Task {
        string id PK
        string title
        string user_id FK
        string project_id FK
        string agent_id FK
        string status
        float progress
        datetime created_at
    }
    
    File {
        string id PK
        string filename
        string user_id FK
        string project_id FK
        string checksum_sha256
        int file_size
    }
    
    AuditLog {
        string id PK
        string user_id FK
        string action
        string resource_type
        json action_details
        datetime created_at
    }
```

---

## 🗄️ Database Schema

### Core Tables

#### 1. users
Primary table for user management and authentication.

| Column | Type | Constraints | Index | Description |
|--------|------|------------|-------|-------------|
| id | VARCHAR(36) | PRIMARY KEY | Yes | UUID primary key |
| username | VARCHAR(255) | UNIQUE, NOT NULL | Yes | Unique username |
| email | VARCHAR(255) | UNIQUE, NOT NULL | Yes | User email |
| password_hash | VARCHAR(255) | NOT NULL | No | Hashed password |
| first_name | VARCHAR(100) | NULL | No | First name |
| last_name | VARCHAR(100) | NULL | No | Last name |
| role | VARCHAR(50) | DEFAULT 'user' | Yes | User role |
| permissions | JSON/JSONB | DEFAULT [] | No | Role permissions |
| is_active | BOOLEAN | DEFAULT true | Yes | Account status |
| is_deleted | BOOLEAN | DEFAULT false | Yes | Soft delete flag |
| created_at | TIMESTAMP | NOT NULL | Yes | Creation timestamp |
| updated_at | TIMESTAMP | NOT NULL | No | Update timestamp |
| deleted_at | TIMESTAMP | NULL | No | Deletion timestamp |

**Indexes**:
- `idx_user_email_active` (email, is_active)
- `idx_users_username` (username)
- `idx_users_role` (role)

**Constraints**:
- `username_min_length`: CHECK(length(username) >= 3)

---

#### 2. projects
Project management and tracking.

| Column | Type | Constraints | Index | Description |
|--------|------|------------|-------|-------------|
| id | VARCHAR(36) | PRIMARY KEY | Yes | UUID primary key |
| name | VARCHAR(255) | NOT NULL | Yes | Project name |
| description | TEXT | NULL | No | Project description |
| owner_id | VARCHAR(36) | FK(users.id), NOT NULL | Yes | Project owner |
| status | VARCHAR(50) | DEFAULT 'active' | Yes | Project status |
| priority | VARCHAR(20) | DEFAULT 'medium' | Yes | Priority level |
| progress | FLOAT | DEFAULT 0.0 | No | Completion % |
| total_tasks | INTEGER | DEFAULT 0 | No | Total task count |
| completed_tasks | INTEGER | DEFAULT 0 | No | Completed tasks |
| success_rate | FLOAT | DEFAULT 0.0 | No | Success rate % |
| tags | JSON/JSONB | DEFAULT [] | No | Project tags |
| settings | JSON/JSONB | DEFAULT {} | No | Configuration |
| created_at | TIMESTAMP | NOT NULL | Yes | Creation timestamp |
| updated_at | TIMESTAMP | NOT NULL | No | Update timestamp |

**Indexes**:
- `idx_project_owner_status` (owner_id, status)
- `idx_projects_name` (name)

**Constraints**:
- `progress_range`: CHECK(progress >= 0 AND progress <= 100)
- `success_rate_range`: CHECK(success_rate >= 0 AND success_rate <= 100)

---

#### 3. agents
AI agent management and monitoring.

| Column | Type | Constraints | Index | Description |
|--------|------|------------|-------|-------------|
| id | VARCHAR(36) | PRIMARY KEY | Yes | UUID primary key |
| name | VARCHAR(255) | NOT NULL | Yes | Agent name |
| agent_type | VARCHAR(100) | NOT NULL | Yes | Agent type |
| description | TEXT | NULL | No | Agent description |
| capabilities | JSON/JSONB | DEFAULT [] | No | Agent capabilities |
| configuration | JSON/JSONB | DEFAULT {} | No | Agent config |
| status | VARCHAR(50) | DEFAULT 'active' | Yes | Agent status |
| health_status | VARCHAR(50) | DEFAULT 'healthy' | Yes | Health status |
| success_rate | FLOAT | DEFAULT 100.0 | No | Success rate % |
| tasks_completed | INTEGER | DEFAULT 0 | No | Completed tasks |
| tasks_failed | INTEGER | DEFAULT 0 | No | Failed tasks |
| created_at | TIMESTAMP | NOT NULL | Yes | Creation timestamp |
| updated_at | TIMESTAMP | NOT NULL | No | Update timestamp |

**Indexes**:
- `idx_agent_type_status` (agent_type, status)
- `idx_agents_name` (name)

**Constraints**:
- `agent_success_rate_range`: CHECK(success_rate >= 0 AND success_rate <= 100)

---

#### 4. tasks
Task execution and tracking.

| Column | Type | Constraints | Index | Description |
|--------|------|------------|-------|-------------|
| id | VARCHAR(36) | PRIMARY KEY | Yes | UUID primary key |
| title | VARCHAR(500) | NOT NULL | Yes | Task title |
| description | TEXT | NULL | No | Task description |
| task_type | VARCHAR(100) | NOT NULL | Yes | Task type |
| user_id | VARCHAR(36) | FK(users.id), NOT NULL | Yes | Creator user |
| project_id | VARCHAR(36) | FK(projects.id), NULL | Yes | Parent project |
| agent_id | VARCHAR(36) | FK(agents.id), NULL | Yes | Assigned agent |
| parent_task_id | VARCHAR(36) | FK(tasks.id), NULL | No | Parent task |
| status | VARCHAR(50) | DEFAULT 'pending' | Yes | Task status |
| priority | VARCHAR(20) | DEFAULT 'medium' | Yes | Priority level |
| progress | FLOAT | DEFAULT 0.0 | No | Completion % |
| execution_time | FLOAT | DEFAULT 0.0 | No | Execution time (s) |
| input_data | JSON/JSONB | DEFAULT {} | No | Input data |
| output_data | JSON/JSONB | DEFAULT {} | No | Output results |
| created_at | TIMESTAMP | NOT NULL | Yes | Creation timestamp |
| completed_at | TIMESTAMP | NULL | No | Completion time |

**Indexes**:
- `idx_task_status_priority` (status, priority)
- `idx_task_agent_status` (agent_id, status)

**Constraints**:
- `task_progress_range`: CHECK(progress >= 0 AND progress <= 100)
- `urgency_range`: CHECK(urgency >= 1 AND urgency <= 10)

---

#### 5. files
File storage and management.

| Column | Type | Constraints | Index | Description |
|--------|------|------------|-------|-------------|
| id | VARCHAR(36) | PRIMARY KEY | Yes | UUID primary key |
| filename | VARCHAR(500) | NOT NULL | Yes | Stored filename |
| original_filename | VARCHAR(500) | NOT NULL | No | Original filename |
| file_path | VARCHAR(1000) | NOT NULL | No | Storage path |
| file_size | INTEGER | NOT NULL | No | File size (bytes) |
| mime_type | VARCHAR(200) | NULL | Yes | MIME type |
| checksum_sha256 | VARCHAR(64) | NULL | Yes | SHA-256 checksum |
| user_id | VARCHAR(36) | FK(users.id), NOT NULL | Yes | Owner user |
| project_id | VARCHAR(36) | FK(projects.id), NULL | Yes | Parent project |
| access_level | VARCHAR(50) | DEFAULT 'private' | Yes | Access control |
| created_at | TIMESTAMP | NOT NULL | Yes | Creation timestamp |

**Indexes**:
- `idx_file_user_project` (user_id, project_id)
- `idx_files_checksum_sha256` (checksum_sha256)

**Constraints**:
- `positive_file_size`: CHECK(file_size > 0)

---

#### 6. audit_logs
Activity auditing and compliance.

| Column | Type | Constraints | Index | Description |
|--------|------|------------|-------|-------------|
| id | VARCHAR(36) | PRIMARY KEY | Yes | UUID primary key |
| user_id | VARCHAR(36) | FK(users.id), NULL | Yes | Acting user |
| action | VARCHAR(200) | NOT NULL | Yes | Action performed |
| resource_type | VARCHAR(100) | NOT NULL | Yes | Resource type |
| resource_id | VARCHAR(36) | NULL | Yes | Resource ID |
| success | BOOLEAN | NOT NULL | Yes | Success flag |
| action_details | JSON/JSONB | DEFAULT {} | No | Action details |
| created_at | TIMESTAMP | NOT NULL | Yes | Action timestamp |

**Indexes**:
- `idx_audit_action_time` (action, created_at)
- `idx_audit_resource` (resource_type, resource_id)

---

### Association Tables

#### project_agents
Many-to-many relationship between projects and agents.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| project_id | VARCHAR(36) | FK(projects.id), PK | Project reference |
| agent_id | VARCHAR(36) | FK(agents.id), PK | Agent reference |
| role | VARCHAR(50) | DEFAULT 'member' | Agent role |
| assigned_at | TIMESTAMP | DEFAULT NOW() | Assignment time |

---

## 🔍 Index Strategy

### Primary Indexes
All tables have primary key indexes on `id` column (UUID).

### Foreign Key Indexes
- `users`: None (root table)
- `projects.owner_id`: Links to users
- `agents`: None (independent table)
- `tasks.user_id`, `tasks.project_id`, `tasks.agent_id`: Multi-foreign key
- `files.user_id`, `files.project_id`: Multi-foreign key
- `audit_logs.user_id`: Links to users

### Composite Indexes
1. **User Activity**: (email, is_active) - Fast active user lookup
2. **Project Management**: (owner_id, status) - User's active projects
3. **Task Filtering**: (status, priority) - Priority task queries
4. **Task Assignment**: (agent_id, status) - Agent workload
5. **Audit Trail**: (action, created_at) - Activity reports
6. **Resource Audit**: (resource_type, resource_id) - Resource history

### Performance Considerations
- Created_at indexed on all tables for time-based queries
- Status fields indexed for filtering
- Composite indexes for common query patterns
- Checksum indexes for file deduplication

---

## 🔐 Security Features

### Data Protection
1. **Soft Deletes**: All major entities support soft deletion
2. **Checksums**: Files verified with SHA-256
3. **Audit Trail**: All actions logged
4. **Access Control**: Role-based permissions

### Authentication
- Password hashing (bcrypt recommended)
- API key management
- Two-factor authentication ready
- Session tracking

### Compliance
- GDPR-ready (soft deletes, data export)
- Audit logging for compliance
- Data retention policies supported
- Access logging

---

## 📈 Performance Optimization

### Connection Pooling
```python
# PostgreSQL/MySQL
pool_size = 20          # Base connections
max_overflow = 40       # Additional connections
pool_timeout = 30       # Wait timeout (seconds)
pool_recycle = 3600     # Recycle after 1 hour
```

### Query Optimization
1. **Eager Loading**: Use `selectinload()` for relationships
2. **Pagination**: Always use LIMIT/OFFSET
3. **Filtering**: Use indexed columns
4. **Aggregation**: Computed columns for counts

### Caching Strategy
- Application-level caching for frequently accessed data
- Query result caching for expensive queries
- Redis integration ready

---

## 🔄 Migration Strategy

### Version Control
- Migrations tracked in `schema_migrations` table
- Each migration has unique version number
- Checksum verification for integrity
- Rollback capability built-in

### Migration Workflow
1. Create migration class extending `BaseMigration`
2. Implement `up()` and `down()` methods
3. Add validation hooks
4. Run migration through manager
5. Track in migration table

### Best Practices
- Never modify existing migrations
- Always test rollback
- Validate before and after
- Keep migrations atomic
- Document changes

---

## 📊 Statistics & Monitoring

### Built-in Metrics
1. **Record Counts**: All tables
2. **Activity Tracking**: 24-hour activity
3. **Performance Metrics**: Query times
4. **Pool Statistics**: Connection usage
5. **Health Status**: Database connectivity

### Custom Metrics
- Agent performance rates
- Project completion rates
- Task execution times
- File storage usage
- User activity patterns

---

## 🛠️ Maintenance Operations

### Automatic Optimization
```python
# Updates project statistics
UPDATE projects SET
    total_tasks = (COUNT from tasks),
    completed_tasks = (COUNT completed),
    success_rate = (percentage calculation)

# Updates agent statistics  
UPDATE agents SET
    tasks_completed = (COUNT from tasks),
    success_rate = (percentage calculation)
```

### Data Cleanup
- Old audit logs (configurable retention)
- Soft-deleted records (after grace period)
- Orphaned files
- Expired sessions

---

## 🔌 Integration Points

### Application Layer
```python
from DATABASE_CORE import (
    init_database,       # Initialize
    get_db_session,      # Get session
    BaseRepository,      # Data access
    User, Project, Task  # Models
)
```

### API Layer (FastAPI)
```python
from DATABASE_CORE import get_db_session

@app.get("/api/endpoint")
async def endpoint(db: AsyncSession = Depends(get_db_session)):
    # Use session
    pass
```

### Service Layer
```python
from DATABASE_CORE import get_database_manager

db_manager = await get_database_manager()
health = await db_manager.health_check()
stats = await db_manager.get_statistics()
```

---

## 📚 Technology Stack

### Core Dependencies
- **SQLAlchemy 2.0+**: Async ORM
- **asyncpg**: PostgreSQL async driver
- **aiosqlite**: SQLite async driver
- **structlog**: Structured logging
- **pydantic**: Data validation

### Optional Dependencies
- **alembic**: Advanced migrations
- **FastAPI**: Web framework
- **pytest**: Testing framework
- **Redis**: Caching layer

---

## 🎯 Best Practices

### Development
1. Always use async/await
2. Use context managers for sessions
3. Implement proper error handling
4. Type hint everything
5. Document complex queries

### Production
1. Use PostgreSQL for production
2. Configure connection pooling
3. Enable query logging initially
4. Monitor pool statistics
5. Regular optimization runs

### Security
1. Never store plain passwords
2. Validate all input
3. Use parameterized queries
4. Enable audit logging
5. Regular security audits

---

## 📖 Additional Resources

- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [PostgreSQL Performance](https://www.postgresql.org/docs/current/performance-tips.html)
- [Database Normalization](https://en.wikipedia.org/wiki/Database_normalization)
- [ACID Properties](https://en.wikipedia.org/wiki/ACID)

---

**Version**: 5.0.0  
**Last Updated**: 2024-10-17  
**Status**: Production Ready
