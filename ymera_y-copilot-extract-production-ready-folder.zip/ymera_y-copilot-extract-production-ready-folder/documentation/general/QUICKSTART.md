# YMERA Quick Start Guide

Get up and running with YMERA in 5 minutes!

## Prerequisites

- Python 3.11+
- pip

## Installation

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd ymera

# 2. Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 3. Install minimal dependencies
pip install fastapi uvicorn pydantic
```

## Run the API

```bash
# Start the API server
python3 api/gateway.py
```

You should see:
```
Starting YMERA API Gateway...
Loaded X agents
INFO:     Uvicorn running on http://0.0.0.0:8000
```

## Test the API

Open a new terminal and try these commands:

### 1. Health Check
```bash
curl http://localhost:8000/health
```

Expected response:
```json
{
  "status": "healthy",
  "agents_registered": 2,
  "timestamp": "2025-10-21T..."
}
```

### 2. List Agents
```bash
curl http://localhost:8000/agents
```

Expected response:
```json
{
  "agents": [
    {
      "agent_id": "...",
      "name": "CalculatorAgent",
      "description": "Performs mathematical calculations",
      "capabilities": ["basic_arithmetic", "advanced_math"],
      "task_types": ["add", "subtract", "multiply", "divide", ...]
    }
  ]
}
```

### 3. Submit a Task
```bash
curl -X POST http://localhost:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "agent_name": "CalculatorAgent",
    "task_type": "add",
    "priority": "medium",
    "payload": {
      "a": 5,
      "b": 3
    }
  }'
```

Expected response:
```json
{
  "task_id": "...",
  "status": "success",
  "result": {
    "operation": "add",
    "a": 5.0,
    "b": 3.0,
    "result": 8.0,
    "formula": "5.0 + 3.0 = 8.0"
  },
  "execution_time": 0.0001,
  "agent_name": "CalculatorAgent"
}
```

## Run Tests

```bash
# Run the complete test suite
python3 cleanup/07_complete_test_suite.py
```

Expected output:
```
================================================================================
COMPLETE AGENT TEST SUITE
================================================================================

Found 2 agent files

Testing agents...

calculator_agent.py... ✅ PASS
data_processor_agent.py... ✅ PASS

================================================================================
TEST SUMMARY
================================================================================
Total: 2
Passed: 2 (100.0%)
Failed: 0 (0.0%)
================================================================================
```

## Next Steps

### 1. Explore the Documentation
- **[README.md](README.md)** - Overview and features
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System design and components
- **[API_DOCS.md](API_DOCS.md)** - Complete API reference
- **[DEPLOYMENT.md](DEPLOYMENT.md)** - Production deployment guide

### 2. Create a Custom Agent

```python
# my_custom_agent.py
from agents import BaseAgent, AgentConfig, AgentCapability

class MyCustomAgent(BaseAgent):
    def __init__(self):
        config = AgentConfig(
            name="MyCustomAgent",
            description="Does custom processing",
            capabilities=[
                AgentCapability(
                    name="custom_processing",
                    description="Custom task processing",
                    task_types=["process"],
                    required_params=["data"]
                )
            ]
        )
        super().__init__(config)
    
    def _execute_task(self, task):
        data = task.payload.get('data')
        # Your custom logic here
        result = f"Processed: {data}"
        return {"result": result}
```

Place in `agents/` directory and restart the API.

### 3. Integrate with Your Application

**Python:**
```python
import requests

response = requests.post('http://localhost:8000/tasks', json={
    'agent_name': 'CalculatorAgent',
    'task_type': 'add',
    'payload': {'a': 10, 'b': 20}
})
print(response.json()['result'])
```

**JavaScript:**
```javascript
const response = await fetch('http://localhost:8000/tasks', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    agent_name: 'CalculatorAgent',
    task_type: 'add',
    payload: {a: 10, b: 20}
  })
});
const result = await response.json();
console.log(result.result);
```

### 4. Deploy to Production

Follow the instructions in [DEPLOYMENT.md](DEPLOYMENT.md) for:
- Docker deployment
- Kubernetes deployment
- Systemd service setup
- SSL/TLS configuration
- Production security best practices

## Troubleshooting

### Port Already in Use
```bash
# Change port in api/gateway.py or use environment variable
PORT=8001 python3 api/gateway.py
```

### Module Not Found
```bash
# Ensure you're in the virtual environment
source venv/bin/activate

# Install missing packages
pip install fastapi uvicorn pydantic
```

### Agent Not Loading
```bash
# Check agent file is in agents/ directory
ls agents/*_agent.py

# Verify agent syntax
python3 -c "from agents.calculator_agent import CalculatorAgent"
```

## Support

- 📖 Documentation: See the docs/ directory
- 🐛 Issues: Create an issue in the repository
- 💬 Questions: Check existing issues or create a new one

## Success!

You're now running YMERA! 🎉

The API is ready to:
- ✅ Accept task requests
- ✅ Route to appropriate agents
- ✅ Process and return results
- ✅ Handle errors gracefully

Happy coding!
