# Dependency Installation Guide

## Overview

This guide explains how to install all dependencies required for the YMERA performance analysis system. All dependencies are now included in `requirements.txt` for easy installation.

## Quick Start

### Option 1: Automated Installation (Recommended)

```bash
./install_all_dependencies.sh
```

This script will:
- Check your Python version
- Install all dependencies from requirements.txt
- Verify installation status
- Display next steps

### Option 2: Manual Installation

```bash
pip3 install -r requirements.txt --upgrade
```

### Option 3: Virtual Environment (Recommended for Development)

```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate  # On Linux/Mac
# or
venv\Scripts\activate     # On Windows

# Install dependencies
pip install -r requirements.txt --upgrade
```

## Dependencies Included

The `requirements.txt` file now includes **76 packages** organized by category:

### Core Framework (6 packages)
- FastAPI, Uvicorn, Pydantic for web services
- Python-multipart for file uploads

### Database (6 packages)
- AsyncPG, SQLAlchemy, Alembic
- PostgreSQL and SQLite support

### AI/ML Core (10 packages)
- **OpenAI** - GPT models
- **Anthropic** - Claude AI
- **PyTorch** - Deep learning framework
- **Transformers** - Hugging Face models
- **Sentence-Transformers** - Text embeddings
- **LangChain** - LLM application framework
- NumPy, scikit-learn, NLTK, spaCy

### NLP & Document Processing (6 packages)
- **TextBlob** - Text processing
- **PyMuPDF** - PDF handling
- **python-docx** - Word documents
- **Markdown** - Markdown processing
- **BeautifulSoup4** - HTML parsing
- **lxml** - XML processing

### Vector Databases & Cloud (4 packages)
- **Qdrant-client** - Vector database
- **FAISS** - Similarity search
- **ChromaDB** - Vector database
- **Google-GenerativeAI** - Gemini API

### Integration Tools (4 packages)
- **QRCode** - QR code generation
- **Atlassian-Python-API** - Jira/Confluence
- **Python-GitLab** - GitLab API
- **PyGithub** - GitHub API

### Monitoring & Testing (15+ packages)
- Prometheus, OpenTelemetry
- Pytest, pytest-asyncio, pytest-cov
- psutil for system monitoring

### Additional Utilities (25+ packages)
- Redis, HTTP clients (httpx, aiohttp)
- Websockets, message queues
- Security, authentication, encryption
- And more...

## Verification

After installation, verify all dependencies are installed:

```bash
python3 dependency_checker.py check
```

Expected output:
```
======================================================================
DEPENDENCY STATUS CHECK
======================================================================

Priority 1: Core AI/ML
----------------------------------------------------------------------
  ✅ openai                         (installed)
  ✅ anthropic                      (installed)
  ✅ torch                          (installed)
  ✅ transformers                   (installed)
  ✅ sentence_transformers          (installed)
  ✅ langchain                      (installed)

... (additional dependencies)

======================================================================
Summary: 20/20 installed, 0 missing
======================================================================
```

## Installation Issues

### Common Problems

#### 1. Python Version
**Error:** "Requires Python 3.11+"

**Solution:**
```bash
python3 --version  # Check version
# Upgrade Python if needed
```

#### 2. Disk Space
**Error:** "No space left on device"

**Solution:**
- PyTorch and Transformers require ~5GB
- Ensure sufficient disk space before installation

#### 3. Network Timeouts
**Error:** "Read timed out"

**Solution:**
```bash
pip3 install -r requirements.txt --timeout=300 --retries=5
```

#### 4. Permission Errors
**Error:** "Permission denied"

**Solution:**
```bash
# Use --user flag
pip3 install -r requirements.txt --user

# Or use virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

#### 5. Conflicting Dependencies
**Error:** "Incompatible package versions"

**Solution:**
```bash
# Create fresh virtual environment
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Specific Package Issues

#### PyTorch Installation
If PyTorch fails to install, try CPU-only version:
```bash
pip3 install torch --index-url https://download.pytorch.org/whl/cpu
```

#### ChromaDB Issues
If ChromaDB has dependency conflicts:
```bash
pip3 install chromadb --no-deps
pip3 install opentelemetry-sdk --upgrade
```

#### Language-Tool-Python
This package requires Java and is NOT included by default:
```bash
# Install Java first
sudo apt-get install default-jre  # Linux
brew install java                  # Mac

# Then install package
pip3 install language-tool-python
```

## System Requirements

### Minimum Requirements
- **Python:** 3.11+
- **RAM:** 8GB (16GB recommended for ML operations)
- **Disk Space:** 10GB free space
- **OS:** Linux, macOS, Windows (WSL recommended)

### Recommended for Full Functionality
- **RAM:** 16GB+ (for large model operations)
- **Disk Space:** 20GB+ (for model caches)
- **GPU:** Optional (for accelerated PyTorch operations)

## Post-Installation

After successful installation:

### 1. Run Dependency Check
```bash
python3 dependency_checker.py check
```

### 2. Run Performance Benchmarks
```bash
# Quick test (10 iterations)
python3 run_comprehensive_benchmarks.py --iterations 10 --operations

# Full benchmark (100 iterations)
python3 run_comprehensive_benchmarks.py --iterations 100 --operations
```

### 3. Run Load Tests
```bash
python3 load_testing_framework.py --requests 100 --workers 10
```

### 4. Generate Performance Report
```bash
python3 enhanced_report_generator.py
```

### 5. View Report
```bash
cat AGENT_PERFORMANCE_REPORT_ENHANCED.md
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Install Dependencies

on: [push, pull_request]

jobs:
  install:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      
      - name: Cache pip packages
        uses: actions/cache@v2
        with:
          path: ~/.cache/pip
          key: ${{ runner.os }}-pip-${{ hashFiles('requirements.txt') }}
      
      - name: Install dependencies
        run: |
          pip install --upgrade pip
          pip install -r requirements.txt
      
      - name: Verify installation
        run: |
          python dependency_checker.py check
```

### Docker Example

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .

# Install Python dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Verify installation
RUN python3 dependency_checker.py check

CMD ["python3", "run_comprehensive_benchmarks.py"]
```

## Maintenance

### Updating Dependencies

```bash
# Check for outdated packages
pip list --outdated

# Update specific package
pip install --upgrade <package-name>

# Update all packages (careful!)
pip install --upgrade -r requirements.txt
```

### Freezing Exact Versions

```bash
# Generate exact versions currently installed
pip freeze > requirements-frozen.txt
```

## Getting Help

If you encounter issues:

1. **Check Documentation:**
   - PERFORMANCE_ANALYSIS_GUIDE.md
   - MISSING_DEPENDENCIES_ANALYSIS.md
   - PERFORMANCE_ANALYSIS_QUICKSTART.md

2. **Run Diagnostics:**
   ```bash
   python3 dependency_checker.py check
   python3 -m pip check  # Check for conflicts
   ```

3. **Check Logs:**
   - Installation logs in terminal output
   - Error messages from pip

4. **Community Support:**
   - Check existing GitHub issues
   - Create new issue with:
     - Python version
     - OS information
     - Full error message
     - Installation command used

## Summary

- ✅ **76 packages** now in requirements.txt
- ✅ **Automated installation** script available
- ✅ **Comprehensive verification** with dependency_checker.py
- ✅ **Full documentation** for troubleshooting
- ✅ **CI/CD examples** for automation

The dependency installation process is now streamlined and production-ready!

---

**Last Updated:** 2025-10-20  
**Version:** 2.0.0  
**Status:** ✅ Complete
