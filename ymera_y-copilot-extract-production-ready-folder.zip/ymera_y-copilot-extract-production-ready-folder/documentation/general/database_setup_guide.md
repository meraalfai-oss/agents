# YMERA Production Database Setup Guide

## 📋 Overview

This guide provides comprehensive instructions for setting up a production-ready database infrastructure on Azure with all critical components.

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Azure Infrastructure                      │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Primary    │───►│  Secondary   │    │  Read        │  │
│  │   SQL DB     │    │  SQL DB      │    │  Replicas    │  │
│  │  (East US)   │    │  (West US 2) │    │              │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│         │                    │                    │          │
│         └────────────────────┴────────────────────┘          │
│                          │                                   │
│                   ┌──────▼──────┐                           │
│                   │  Connection  │                           │
│                   │  Pool Manager│                           │
│                   └──────────────┘                           │
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Backup     │    │  Monitoring  │    │   Query      │  │
│  │   System     │    │  & Alerts    │    │  Optimizer   │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

```bash
# Install required tools
pip install -r requirements.txt

# Azure CLI
az --version  # Ensure version 2.50+

# Python packages
pip install sqlalchemy alembic pyodbc azure-identity azure-mgmt-sql
```

### 1. Initial Deployment

```bash
# Set environment variables
export SQL_ADMIN_PASSWORD="YourSecurePassword123!"

# Make scripts executable
chmod +x deploy-production.sh
chmod +x troubleshoot-azure.sh

# Deploy infrastructure
./deploy-production.sh
```

### 2. Configure Environment

```bash
# Copy and configure environment file
cp .env.azure.production .env

# Update with your values from deployment output
nano .env
```

### 3. Initialize Database

```python
# Initialize database manager
from app.database import init_db, db_manager

# Initialize connections
init_db()

# Verify health
health = db_manager.health_check()
print(health)
```

## 📊 Components

### 1. Connection Pool Management

**Features:**
- Automatic connection pooling
- Health checks with pre-ping
- Connection recycling
- Overflow handling

**Configuration:**

```python
from app.database import DatabaseConfig, DatabaseManager

config = DatabaseConfig()
config.pool_size = 20          # Base pool size
config.max_overflow = 40       # Additional connections
config.pool_timeout = 30       # Connection timeout
config.pool_recycle = 3600     # Recycle after 1 hour

db_manager = DatabaseManager()
db_manager.initialize()
```

**Usage:**

```python
# Get session for operations
with db_manager.get_session() as session:
    users = session.query(User).all()
    session.commit()
```

### 2. Migration System

**Setup Alembic:**

```bash
# Initialize Alembic (if not done)
alembic init alembic

# Create migration
python migration_manager.py create "Add user table"

# Test migration
python migration_manager.py test head

# Run migration
python migration_manager.py upgrade head

# Rollback if needed
python migration_manager.py downgrade -1
```

**Migration Best Practices:**

```python
from migration_manager import MigrationManager

manager = MigrationManager()

# Always test before production
success = manager.test_migration_upgrade("head")
if success:
    manager.upgrade("head", backup=True)
```

### 3. Backup & Recovery

**Configure Backups:**

```python
from app.backup_recovery import AzureBackupManager

backup_manager = AzureBackupManager()

# Configure long-term retention
backup_manager.create_long_term_retention_policy(
    weekly_retention="P4W",    # 4 weeks
    monthly_retention="P12M",  # 12 months
    yearly_retention="P5Y",    # 5 years
    week_of_year=1
)
```

**Point-in-Time Recovery:**

```python
from datetime import datetime, timedelta

# Restore to 1 hour ago
restore_point = datetime.now() - timedelta(hours=1)
result = backup_manager.restore_to_point_in_time(
    restore_point=restore_point,
    target_database_name="ymeradb-restored"
)
```

**Geo-Replication:**

```bash
# Configured automatically in deployment
# View replication status
az sql db replica list-links \
    --resource-group ymera \
    --server ymera-sql \
    --name ymeradb
```

### 4. Query Optimization

**Enable Monitoring:**

```python
from app.query_optimization import QueryPerformanceMonitor

monitor = QueryPerformanceMonitor(slow_query_threshold=1.0)
monitor.register_listeners(db_manager._engine)

# Get statistics
stats = monitor.get_query_statistics()
for stat in stats[:10]:  # Top 10 slowest
    print(f"Query: Avg {stat['avg_time']:.2f}s, Count: {stat['count']}")
```

**Index Analysis:**

```python
from app.query_optimization import IndexAnalyzer

analyzer = IndexAnalyzer(session)

# Find missing indexes
missing = analyzer.find_missing_indexes()
for idx in missing:
    print(idx['create_statement'])

# Find unused indexes
unused = analyzer.find_unused_indexes(days_threshold=30)
for idx in unused:
    print(idx['recommendation'])
```

### 5. Read Replicas & Horizontal Scaling

**Setup Read Replicas:**

```python
from app.read_replica_config import ReadReplicaManager, LoadBalancingStrategy

replica_manager = ReadReplicaManager(
    primary_connection_string=os.getenv('DATABASE_URL'),
    replica_connection_strings=[
        os.getenv('DATABASE_REPLICA_1_URL'),
        os.getenv('DATABASE_REPLICA_2_URL'),
    ],
    load_balancing_strategy=LoadBalancingStrategy.LEAST_CONNECTIONS
)

replica_manager.initialize()
```

**Route Queries:**

```python
from app.read_replica_config import DatabaseRouter

router = DatabaseRouter(replica_manager)

# Read operations (uses replicas)
with router.session(for_write=False) as session:
    users = session.query(User).all()

# Write operations (uses primary)
with router.session(for_write=True) as session:
    new_user = User(name="John")
    session.add(new_user)
    session.commit()
```

### 6. Health Monitoring

**Setup Continuous Monitoring:**

```python
from app.db_monitoring import DatabaseHealthMonitor
import asyncio

monitor = DatabaseHealthMonitor(
    db_manager=db_manager,
    alert_config={
        'email_enabled': True,
        'smtp': {
            'host': 'smtp.gmail.com',
            'port': 587,
            'username': 'your-email@gmail.com',
            'password': 'your-app-password'
        },
        'alert_recipients': ['admin@yourdomain.com'],
        'webhook_url': 'https://hooks.slack.com/services/YOUR/WEBHOOK'
    }
)

# Start monitoring
asyncio.create_task(monitor.monitor_continuously(interval_seconds=60))
```

**Check Health:**

```python
# Get current metrics
metrics = await monitor.collect_metrics()

# Get summary
summary = monitor.get_metrics_summary(hours=24)
print(f"Average connections: {summary['avg_connections']}")
print(f"Alerts in last 24h: {summary['alerts_count']}")
```

### 7. Automated Maintenance

**Schedule Maintenance:**

```python
from app.db_monitoring import DatabaseMaintenanceScheduler

scheduler = DatabaseMaintenanceScheduler(db_manager)

# Run maintenance tasks
await scheduler.run_maintenance()
```

**Maintenance Tasks:**
- Update statistics
- Rebuild fragmented indexes
- Clean old backups
- Analyze query performance

## 🔧 Configuration Files

### requirements.txt

```txt
# Database
SQLAlchemy==2.0.23
alembic==1.13.0
pyodbc==5.0.1

# Azure
azure-identity==1.15.0
azure-mgmt-sql==4.0.0
azure-storage-blob==12.19.0

# Monitoring
aiohttp==3.9.1
python-dotenv==1.0.0

# Optional
psycopg2-binary==2.9.9  # If using PostgreSQL
redis==5.0.1            # For caching
```

### alembic.ini

```ini
[alembic]
script_location = alembic
prepend_sys_path = .
version_path_separator = os

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
```

## 📈 Monitoring Dashboards

### Key Metrics to Monitor

1. **Connection Pool**
   - Pool size utilization
   - Checked out connections
   - Connection wait time
   - Connection timeouts

2. **Performance**
   - Query execution time
   - Slow queries (> 1s)
   - CPU utilization
   - Memory usage

3. **Storage**
   - Database size growth
   - Available space
   - Fragmentation levels

4. **Replication**
   - Replication lag
   - Replication state
   - Failover readiness

### Azure Portal Monitoring

```bash
# Enable diagnostic settings
az monitor diagnostic-settings create \
    --name SQLDatabaseDiagnostics \
    --resource /subscriptions/$SUBSCRIPTION_ID/resourceGroups/ymera/providers/Microsoft.Sql/servers/ymera-sql/databases/ymeradb \
    --workspace ymera-logs \
    --logs '[{"category": "SQLInsights", "enabled": true}]' \
    --metrics '[{"category": "Basic", "enabled": true}]'
```

## 🔐 Security Best Practices

1. **Connection Strings**
   - Never commit to version control
   - Use Azure Key Vault for production
   - Rotate passwords regularly

2. **Network Security**
   - Enable firewall rules
   - Use private endpoints
   - Configure VNet integration

3. **Encryption**
   - TLS 1.2+ only
   - Transparent Data Encryption (TDE)
   - Always Encrypted for sensitive columns

4. **Access Control**
   - Use Azure AD authentication
   - Implement RBAC
   - Audit database access

## 🚨 Troubleshooting

### Common Issues

**Connection Pool Exhaustion:**
```python
# Increase pool size
config.pool_size = 30
config.max_overflow = 60
```

**Slow Queries:**
```bash
# Run index analysis
python -c "from app.query_optimization import IndexAnalyzer; analyzer.find_missing_indexes()"
```

**Replication Lag:**
```bash
# Check replication status
az sql db replica list-links \
    --resource-group ymera \
    --server ymera-sql \
    --name ymeradb
```

**Storage Full:**
```bash
# Check and increase max size
az sql db update \
    --resource-group ymera \
    --server ymera-sql \
    --name ymeradb \
    --max-size 50GB
```

## 📞 Support & Maintenance

### Regular Tasks

- **Daily:** Check health dashboard, review alerts
- **Weekly:** Review slow queries, check backup status
- **Monthly:** Analyze index usage, review storage growth
- **Quarterly:** Test disaster recovery, update dependencies

### Emergency Contacts

- DBA On-Call: [Your contact]
- Azure Support: [Support plan details]
- Backup Restoration SLA: 4 hours

## 📚 Additional Resources

- [Azure SQL Database Documentation](https://docs.microsoft.com/azure/sql-database/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [Alembic Documentation](https://alembic.sqlalchemy.org/)
- [Azure Best Practices](https://docs.microsoft.com/azure/architecture/best-practices/)

## 🎯 Next Steps

1. ✅ Deploy infrastructure
2. ✅ Configure backups
3. ✅ Setup monitoring
4. ✅ Run initial migrations
5. ⬜ Load test the system
6. ⬜ Configure auto-scaling
7. ⬜ Document runbooks
8. ⬜ Train team on procedures