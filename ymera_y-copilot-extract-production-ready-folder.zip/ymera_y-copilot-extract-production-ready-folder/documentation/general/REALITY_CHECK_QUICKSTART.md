# YMERA Reality Check - Quick Start Guide

## What is Reality Check?

A comprehensive validation system that tests what **actually works** vs. what we **think works** in the YMERA system.

- No optimism
- No assumptions  
- Only facts

## Quick Start

### 1. Run Reality Check

```bash
# From project root
python3 scripts/reality_check.py
```

### 2. Check Results

The script will:
- Print colored console output with ✅/❌/⚠️ indicators
- Save detailed results to `reality_check_results.json`
- Exit with appropriate status code for CI/CD

### 3. View Detailed Results

```bash
# Pretty-print JSON results
cat reality_check_results.json | python -m json.tool

# Or just view the file
less reality_check_results.json
```

## What It Tests

1. **Dependency Availability** (10 tests)
   - Checks if critical Python packages are installed
   - numpy, nats, nltk, spacy, tiktoken, redis, asyncpg, fastapi, sqlalchemy, pydantic

2. **Module Imports** (8 tests)
   - Validates core modules can import without errors
   - config, database, models, unified_system, base_agent, learning_agent, intelligence_engine, main

3. **Database Schema** (9 tests)
   - Verifies all database models are defined
   - User, Agent, Task, Experience, Project, File, AuditLog, SecurityEvent

4. **Configuration Loading** (2 tests)
   - Tests configuration classes load from environment
   - Settings, ProjectAgentSettings

5. **API Structure** (2 tests)
   - Validates FastAPI app initializes
   - Checks routes are defined

6. **Agent Loading** (N tests)
   - Loads all .py files from agents/ directory
   - Reports which agents load successfully

7. **Real-World Scenarios** (2 tests)
   - Tests basic model instantiation
   - Validates core operations work

## Understanding Results

### Exit Codes

- `0` = GOOD (80%+ pass rate)
- `1` = CRITICAL (<50% pass rate) 
- `2` = DEGRADED (50-80% pass rate)

### Console Output

```
✅ Test Name: PASSED
   - Test passed successfully

❌ Test Name: FAILED
   Details: Error message here
   - Critical failure that blocks functionality

⚠️  Test Name: WARNING
   Details: Issue description
   - Non-critical issue, functionality degraded
```

### Current Status

As of latest run:
- **Pass Rate:** 95.1% (39/41 tests)
- **Critical Blockers:** 0
- **Status:** ✅ GOOD - Core functionality operational

## Common Issues and Fixes

### Issue: Missing Dependencies

**Symptom:**
```
❌ Dependency: numpy: FAILED
   Details: Package not installed
```

**Fix:**
```bash
pip install -r requirements.txt
# Or install specific package
pip install numpy
```

### Issue: Config Validation Error

**Symptom:**
```
❌ Import: config: FAILED
   Details: SettingsError: error parsing value for field "cors_origins"
```

**Fix:** Already fixed in current version
- Config now handles comma-separated strings in environment variables
- Use format: `CORS_ORIGINS=http://localhost:3000,http://localhost:8000`

### Issue: Module Import Failure

**Symptom:**
```
❌ Import: main: FAILED
   Details: ModuleNotFoundError: No module named 'passlib'
```

**Fix:**
```bash
pip install passlib
# Or install all missing dependencies
pip install -r requirements.txt
```

## Integration with CI/CD

### GitHub Actions

```yaml
- name: Run Reality Check
  run: |
    python3 scripts/reality_check.py
  
- name: Upload Results
  uses: actions/upload-artifact@v3
  if: always()
  with:
    name: reality-check-results
    path: reality_check_results.json
```

### Pre-commit Hook

```bash
#!/bin/bash
# .git/hooks/pre-push

echo "Running reality check..."
python3 scripts/reality_check.py

if [ $? -eq 1 ]; then
  echo "❌ Reality check FAILED - System in CRITICAL state"
  echo "Fix critical blockers before pushing"
  exit 1
fi

echo "✅ Reality check passed"
```

### Docker Health Check

```dockerfile
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
  CMD python3 scripts/reality_check.py || exit 1
```

## Customization

### Add New Tests

Edit `scripts/reality_check.py` and add test methods:

```python
async def test_my_feature(self) -> Dict[str, Any]:
    """Test my custom feature."""
    results = {"working": False}
    
    try:
        # Your test code here
        results["working"] = True
        self.log_test("My Feature", "PASSED")
    except Exception as e:
        self.log_test("My Feature", "FAILED", str(e), critical=True)
    
    return results
```

Then add to `run_all_tests()`:

```python
test_functions = [
    # ... existing tests ...
    ("My Feature", self.test_my_feature),
]
```

### Change Pass Rate Thresholds

Edit the `generate_summary()` method:

```python
if pass_rate >= 90:  # Changed from 80
    print("✅ SYSTEM STATUS: GOOD - Most components working")
elif pass_rate >= 60:  # Changed from 50
    print("⚠️  SYSTEM STATUS: DEGRADED - Significant issues found")
else:
    print("❌ SYSTEM STATUS: CRITICAL - Major components broken")
```

## Troubleshooting

### Script Won't Run

```bash
# Make script executable
chmod +x scripts/reality_check.py

# Run with Python directly
python3 scripts/reality_check.py
```

### Import Errors

```bash
# Ensure you're in the project root
cd /path/to/ymera_y

# Check Python path
python3 -c "import sys; print(sys.path)"

# Run from correct directory
python3 scripts/reality_check.py
```

### JSON Parsing Errors

If reality_check_results.json is corrupted:

```bash
# Delete and re-run
rm reality_check_results.json
python3 scripts/reality_check.py
```

## Advanced Usage

### Run Specific Test Categories

Modify the script to comment out tests you don't want:

```python
test_functions = [
    ("Dependency Availability", self.test_dependency_availability),
    # ("Module Imports", self.test_module_imports),  # Commented out
    ("Database Schema", self.test_database_schema),
]
```

### Continuous Monitoring

```bash
# Run every hour
watch -n 3600 python3 scripts/reality_check.py

# Or with cron
0 * * * * cd /path/to/ymera_y && python3 scripts/reality_check.py
```

### Compare Results Over Time

```bash
# Save timestamped results
python3 scripts/reality_check.py
cp reality_check_results.json "results_$(date +%Y%m%d_%H%M%S).json"

# Compare with previous
diff results_20231023_083000.json results_20231023_090000.json
```

## Related Documentation

- **REALITY_CHECK_VALIDATION_REPORT.md** - Full validation report with analysis
- **ERROR_CLASSIFICATION_COMPLETE.md** - Error classification and fixing guide
- **requirements.txt** - Complete dependency list
- **requirements_missing.txt** - Previously missing dependencies reference

## Support

For issues or questions:

1. Check `REALITY_CHECK_VALIDATION_REPORT.md` for detailed analysis
2. Review test output in console and JSON file
3. Verify all dependencies are installed: `pip list`
4. Check environment variables: `cat .env`
5. Review error tracebacks in reality_check_results.json

## Success Stories

**Before Reality Check:**
- 29% pass rate
- 14 critical blockers
- System status: CRITICAL

**After Reality Check:**
- 95.1% pass rate
- 0 critical blockers  
- System status: GOOD

**Improvement:** +66.1 percentage points in system health! 🎉

---

**Last Updated:** 2025-10-23  
**Script Version:** 1.0.0  
**Maintained by:** YMERA Development Team
