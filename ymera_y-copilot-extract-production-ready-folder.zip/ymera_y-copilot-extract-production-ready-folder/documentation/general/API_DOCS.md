# YMERA API Documentation

**Version:** 2.0.0  
**Last Updated:** 2025-10-21

---

## Base URL

```
http://localhost:8000
```

For production, replace with your deployment URL.

## Authentication

Currently, the API is open. For production, add authentication headers:

```http
Authorization: Bearer <your-jwt-token>
```

## Endpoints

### 1. Root Endpoint

Get API information.

**Endpoint:** `GET /`

**Response:**
```json
{
  "service": "YMERA Agent API",
  "version": "2.0",
  "status": "operational"
}
```

**Example:**
```bash
curl http://localhost:8000/
```

---

### 2. Health Check

Check API and system health.

**Endpoint:** `GET /health`

**Response:**
```json
{
  "status": "healthy",
  "agents_registered": 4,
  "timestamp": "2025-10-21T03:00:00.000000"
}
```

**Example:**
```bash
curl http://localhost:8000/health
```

---

### 3. List Agents

Get all registered agents.

**Endpoint:** `GET /agents`

**Response:**
```json
{
  "agents": [
    {
      "agent_id": "abc-123",
      "name": "CalculatorAgent",
      "description": "Performs mathematical calculations",
      "capabilities": ["calculate"],
      "task_types": ["add", "subtract", "multiply", "divide"]
    }
  ]
}
```

**Example:**
```bash
curl http://localhost:8000/agents
```

---

### 4. Get Agent Info

Get detailed information about a specific agent.

**Endpoint:** `GET /agents/{agent_id}`

**Path Parameters:**
- `agent_id` (string, required): Agent ID

**Response:**
```json
{
  "agent_id": "abc-123",
  "name": "CalculatorAgent",
  "description": "Performs mathematical calculations",
  "capabilities": [
    {
      "name": "calculate",
      "description": "Perform calculations",
      "task_types": ["add", "subtract", "multiply", "divide"],
      "required_params": ["operation", "a", "b"]
    }
  ],
  "config": {
    "max_concurrent_tasks": 10,
    "task_timeout": 300,
    "retry_attempts": 3
  }
}
```

**Errors:**
- `404`: Agent not found

**Example:**
```bash
curl http://localhost:8000/agents/abc-123
```

---

### 5. Submit Task

Submit a task to an agent for processing.

**Endpoint:** `POST /tasks`

**Request Body:**
```json
{
  "agent_id": "abc-123",
  "task_type": "add",
  "priority": "medium",
  "payload": {
    "a": 5,
    "b": 3
  }
}
```

**Parameters:**
- `agent_id` (string, optional): Agent ID (provide either this or agent_name)
- `agent_name` (string, optional): Agent name (provide either this or agent_id)
- `task_type` (string, required): Type of task
- `priority` (string, optional): Priority level - "low", "medium", "high", "critical" (default: "medium")
- `payload` (object, required): Task-specific data

**Response:**
```json
{
  "task_id": "task-456",
  "status": "success",
  "result": {
    "answer": 8
  },
  "error": null,
  "execution_time": 0.012,
  "completed_at": "2025-10-21T03:00:00.000000",
  "metadata": {},
  "agent_id": "abc-123",
  "agent_name": "CalculatorAgent"
}
```

**Errors:**
- `400`: Missing or invalid parameters
- `404`: Agent not found

**Example:**
```bash
curl -X POST http://localhost:8000/tasks   -H "Content-Type: application/json"   -d '{
    "agent_name": "CalculatorAgent",
    "task_type": "add",
    "priority": "medium",
    "payload": {
      "a": 5,
      "b": 3
    }
  }'
```

---

## Response Format

### Success Response

All successful responses follow this structure:

```json
{
  "task_id": "string",
  "status": "success",
  "result": {},
  "error": null,
  "execution_time": 0.0,
  "completed_at": "timestamp",
  "metadata": {},
  "agent_id": "string",
  "agent_name": "string"
}
```

### Error Response

Error responses include:

```json
{
  "detail": "Error message"
}
```

With appropriate HTTP status codes:
- `400`: Bad Request
- `404`: Not Found
- `500`: Internal Server Error

---

## Status Codes

- `200`: Success
- `400`: Bad Request (invalid input)
- `404`: Not Found (agent or resource doesn't exist)
- `422`: Validation Error (invalid request format)
- `500`: Internal Server Error

---

## Task Priorities

Priority levels affect task scheduling:

1. `critical` - Highest priority
2. `high` - High priority
3. `medium` - Normal priority (default)
4. `low` - Lowest priority

---

## Rate Limiting

Currently no rate limiting. For production:
- Implement rate limiting middleware
- Set per-client limits
- Return `429 Too Many Requests`

---

## Examples

### Python

```python
import requests

# List agents
response = requests.get('http://localhost:8000/agents')
agents = response.json()['agents']

# Submit task
response = requests.post('http://localhost:8000/tasks', json={
    'agent_name': 'CalculatorAgent',
    'task_type': 'add',
    'priority': 'medium',
    'payload': {'a': 5, 'b': 3}
})
result = response.json()
```

### JavaScript/Node.js

```javascript
// List agents
const response = await fetch('http://localhost:8000/agents');
const data = await response.json();
const agents = data.agents;

// Submit task
const taskResponse = await fetch('http://localhost:8000/tasks', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    agent_name: 'CalculatorAgent',
    task_type: 'add',
    priority: 'medium',
    payload: {a: 5, b: 3}
  })
});
const result = await taskResponse.json();
```

### cURL

```bash
# List agents
curl http://localhost:8000/agents

# Submit task
curl -X POST http://localhost:8000/tasks   -H "Content-Type: application/json"   -d '{"agent_name":"CalculatorAgent","task_type":"add","payload":{"a":5,"b":3}}'
```

---

## WebSocket Support

WebSocket support is planned for future versions to enable:
- Real-time task updates
- Agent status notifications
- Streaming results

---

## Support

For issues or questions:
- Create an issue in the repository
- Check ARCHITECTURE.md for system design
- Review DEPLOYMENT.md for setup help
