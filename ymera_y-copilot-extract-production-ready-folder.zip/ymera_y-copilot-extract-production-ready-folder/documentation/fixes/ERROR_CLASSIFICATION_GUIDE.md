# Error Classification & Priority System

## Overview

This guide explains the automated error classification and fix prioritization system for YMERA agent imports.

## 📊 Error Distribution

Based on analysis of 88 agents in the system:

### Current Status
- **Total Agents:** 88
- **Successful Imports:** 50 (56.8%)
- **Failed Imports:** 38 (43.2%)

### Error Type Distribution
1. **ModuleNotFoundError:** 32 agents (84.2% of errors)
2. **ImportError:** 4 agents (10.5% of errors)
3. **NameError:** 1 agent (2.6% of errors)
4. **IndentationError:** 1 agent (2.6% of errors)

## 🎯 Priority Levels

**Strategy:** Prioritize automated fixes (pip install) over manual fixes (code editing) for maximum efficiency.

### Priority 1: CRITICAL (automated fixes - missing critical dependencies)
- **Type:** Automated fixes via pip install
- **Impact:** Blocks multiple agents and core system functionality
- **Affected Agents:** 12
- **Estimated Fix Time:** 5 minutes per package
- **Packages:**
  - `pydantic>=2.0` - Core validation framework
  - `pydantic-settings` - Configuration management
  - `fastapi` - API framework

### Priority 2: HIGH (automated fixes - missing important dependencies)
- **Type:** Automated fixes via pip install
- **Impact:** Prevents important features and functionality
- **Affected Agents:** 13
- **Estimated Fix Time:** 5-15 minutes per package
- **Packages:**
  - `sqlalchemy[asyncio]` - Database ORM
  - `redis[hiredis]` - Caching
  - `nats-py` - Message broker
  - `asyncpg` - PostgreSQL driver
  - `httpx` - HTTP client
  - `aiofiles` - Async file I/O
  - `numpy` - Numerical computing
  - `hvac` - Vault client
  - `psutil` - System monitoring

### Priority 3: MEDIUM (mixed - optional dependencies or code quality issues)
- **Type:** Mix of automated (pip install) and manual (code editing) fixes
- **Impact:** Affects optional functionality or requires code quality improvements
- **Affected Agents:** 12
- **Estimated Fix Time:** 5-30 minutes
- **Fixes:**
  - **Automated:** `structlog` - Structured logging (7 agents)
  - **Manual:** Import structure fixes (4 agents)
  - **Manual:** Code quality fixes (1 agent)

### Priority 4: LOW (manual investigation - complex file-specific issues)
- **Type:** Extensive manual investigation and code editing required
- **Impact:** Single-file issues requiring significant effort
- **Affected Agents:** 1
- **Estimated Fix Time:** 10-60 minutes (extensive manual work)
- **Issues:**
  - `code_editor_agent_api.py` - Multiple IndentationErrors requiring extensive refactoring

## 🛠️ Tools

### 1. Error Classification Analyzer

Analyzes all agent files and classifies errors by type and priority.

**Usage:**
```bash
python3 error_classification_analyzer.py
```

**Outputs:**
- `error_classification_report.json` - Detailed JSON report
- `error_classification_report.txt` - Human-readable report

**What it does:**
- Discovers all agent files
- Attempts to import each agent
- Captures and classifies errors
- Assigns priorities based on impact
- Generates fix strategies

### 2. Automated Error Fixer

Applies fixes based on classification priority.

**Usage:**

Dry run (shows what would be done):
```bash
python3 fix_agent_errors.py
```

Install critical packages only:
```bash
python3 fix_agent_errors.py --priority 1 --install
```

Install all packages:
```bash
python3 fix_agent_errors.py --install
```

Generate installation script:
```bash
python3 fix_agent_errors.py --generate-script
bash install_agent_dependencies.sh
```

## 📋 Fix Strategy by Error Type

### ModuleNotFoundError
**Root Cause:** Missing Python package

**Fix Strategy:**
1. Identify the missing package from error message
2. Install using pip: `pip install <package>`
3. Verify import works

**Example:**
```python
# Error: ModuleNotFoundError: No module named 'pydantic_settings'
# Fix:
pip install pydantic-settings
```

### ImportError
**Root Cause:** Incorrect import statement or circular dependency

**Fix Strategy:**
1. Review import statement
2. Check for circular imports
3. Update import path or refactor code

**Example:**
```python
# Error: ImportError: cannot import name 'X' from 'Y'
# Fix options:
# 1. Update import: from Y import Z (instead of X)
# 2. Fix circular import by moving import inside function
# 3. Update module structure
```

### ValidationError
**Root Cause:** Configuration or data validation failure

**Fix Strategy:**
1. Review configuration requirements
2. Provide required environment variables
3. Fix data format

**Example:**
```python
# Error: ValidationError: field required
# Fix:
# 1. Add to .env file
# 2. Or provide in config
```

### NameError
**Root Cause:** Undefined variable or typo

**Fix Strategy:**
1. Define the missing variable
2. Fix typo in variable name
3. Import missing symbol

**Example:**
```python
# Error: NameError: name 'app' is not defined
# Fix:
app = FastAPI()  # Define the variable
```

### SyntaxError / IndentationError
**Root Cause:** Code syntax issues

**Fix Strategy:**
1. Review code for syntax errors
2. Fix indentation
3. Check for missing brackets/parentheses

**Example:**
```python
# Error: IndentationError: unexpected indent
# Fix: Correct indentation to match Python syntax
```

## 🚀 Quick Start

### Step 1: Analyze Errors
```bash
python3 error_classification_analyzer.py
```

Review the generated reports to understand the error landscape.

### Step 2: Fix Critical Errors (Priority 1)
```bash
python3 fix_agent_errors.py --priority 1 --install
```

This installs packages that are blocking multiple agents.

### Step 3: Fix High Priority Errors (Priority 2)
```bash
python3 fix_agent_errors.py --priority 2 --install
```

This addresses core functionality issues.

### Step 4: Verify Improvements
```bash
python3 error_classification_analyzer.py
```

Check the new success rate and remaining errors.

### Step 5: Address Remaining Errors
For Priority 3 and 4 errors, review the detailed report and apply manual fixes as needed.

## 📈 Expected Results

### After Priority 1 Fixes
- **Success Rate:** ~70% (12 more agents working)
- **Time Investment:** ~15 minutes

### After Priority 2 Fixes
- **Success Rate:** ~90% (17 more agents working)
- **Time Investment:** ~45 minutes total

### After Priority 3 Fixes
- **Success Rate:** ~95% (8 more agents working)
- **Time Investment:** ~55 minutes total

### After Manual Fixes (Priority 4)
- **Success Rate:** ~100%
- **Time Investment:** ~2 hours total

## 🔄 Workflow

```
┌─────────────────────────┐
│  Run Error Analyzer     │
│  (Find all errors)      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Review Classification  │
│  (Understand priorities)│
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Fix Priority 1         │
│  (Critical issues)      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Verify & Re-analyze    │
│  (Check improvements)   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Fix Priority 2 & 3     │
│  (High/Medium issues)   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Manual fixes (P4)      │
│  (Edge cases)           │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Final verification     │
│  (All agents working)   │
└─────────────────────────┘
```

## 📊 Metrics

The system tracks the following metrics:

- **Total Agents:** Number of agent files found
- **Success Rate:** Percentage of agents that import successfully
- **Error Distribution:** Breakdown by error type
- **Priority Distribution:** Agents affected by each priority level
- **Fix Effort:** Estimated time to resolve each category

## 🎓 Best Practices

### 1. Run Analysis Regularly
Run the error analyzer after code changes to catch new issues early.

### 2. Fix by Priority
Always address errors in priority order for maximum impact.

### 3. Verify After Each Fix
Re-run the analyzer after applying fixes to confirm improvements.

### 4. Use Dry Run First
Test fixes with `--dry-run` before applying them.

### 5. Generate Scripts
Use `--generate-script` to create reproducible installation commands.

### 6. Keep Reports
Save classification reports to track improvements over time.

## 🔍 Troubleshooting

### Issue: Analysis finds no agents
**Solution:** Ensure you're running from the repository root directory.

### Issue: Packages fail to install
**Solution:** Check internet connection and pip configuration.

### Issue: Errors persist after fixing
**Solution:** Some errors may require code changes, not just package installation.

### Issue: New errors appear
**Solution:** This is normal as fixing some imports may reveal downstream issues.

## 📚 Additional Resources

- [Agent System Documentation](./AGENT_SYSTEM_COMPLETION_README.md)
- [Production Readiness Guide](./PRODUCTION_READINESS.md)
- [Deployment Guide](./DEPLOYMENT_GUIDE.md)
- [Testing Framework](./TESTING_FRAMEWORK_IMPLEMENTATION.md)

## 🤝 Contributing

When adding new agents:
1. Run the error analyzer to check for issues
2. Fix any errors before committing
3. Update this guide if new error patterns emerge

## 📝 Notes

- The error classifier uses static analysis and import testing
- Some errors may only appear at runtime
- Priority assignments are based on impact analysis
- Fix time estimates are averages and may vary
- The system is designed to be run iteratively

---

**Last Updated:** 2025-10-21
**Version:** 1.0.0
**Maintained By:** YMERA Development Team
