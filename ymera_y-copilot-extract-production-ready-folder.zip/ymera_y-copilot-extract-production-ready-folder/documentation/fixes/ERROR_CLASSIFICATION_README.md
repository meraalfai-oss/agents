# Error Classification & Priority System - Quick Reference

## Quick Commands

### Analyze All Errors
```bash
python3 error_classification_analyzer.py
```

### View Results
```bash
cat error_classification_report.txt
```

### Fix Critical Errors Only
```bash
python3 fix_agent_errors.py --priority 1 --install
```

### Fix All Errors (Dry Run)
```bash
python3 fix_agent_errors.py
```

### Fix All Errors (Actually Install)
```bash
python3 fix_agent_errors.py --install
```

### Generate Installation Script
```bash
python3 fix_agent_errors.py --generate-script
bash install_agent_dependencies.sh
```

## Current Status

- **Total Agents:** 88
- **Working:** 50 (56.8%)
- **Failed:** 38 (43.2%)

## Error Distribution

| Error Type | Count | Percentage |
|-----------|-------|------------|
| ModuleNotFoundError | 32 | 84.2% |
| ImportError | 4 | 10.5% |
| NameError | 1 | 2.6% |
| IndentationError | 1 | 2.6% |

## Priority Levels

**Strategy:** Prioritize automated fixes (pip install) over manual fixes for maximum impact.

| Priority | Name | Type | Agents | Time | Packages |
|----------|------|------|--------|------|----------|
| 1 | CRITICAL | Automated | 12 | 15 min | 3 |
| 2 | HIGH | Automated | 13 | 45 min | 9 |
| 3 | MEDIUM | Mixed | 12 | 10-30 min | 1 + manual |
| 4 | LOW | Manual | 1 | 10-60 min | 0 |

## Files

- `error_classification_analyzer.py` - Main analysis tool
- `fix_agent_errors.py` - Automated fix tool
- `error_classification_report.json` - Detailed JSON report
- `error_classification_report.txt` - Human-readable report
- `install_agent_dependencies.sh` - Generated install script
- `ERROR_CLASSIFICATION_GUIDE.md` - Comprehensive documentation

## Recommended Workflow

1. **Analyze:** `python3 error_classification_analyzer.py`
2. **Review:** `cat error_classification_report.txt | head -100`
3. **Fix P1:** `python3 fix_agent_errors.py --priority 1 --install`
4. **Verify:** Re-run analyzer
5. **Fix P2:** `python3 fix_agent_errors.py --priority 2 --install`
6. **Fix P3:** `python3 fix_agent_errors.py --priority 3 --install`
7. **Manual:** Address remaining errors manually

## Expected Improvements

- **After P1 fixes:** ~70% success rate (+13%)
- **After P2 fixes:** ~90% success rate (+33%)
- **After P3 fixes:** ~95% success rate (+38%)
- **After manual:** ~100% success rate (+43%)

## Need Help?

See `ERROR_CLASSIFICATION_GUIDE.md` for detailed documentation.
