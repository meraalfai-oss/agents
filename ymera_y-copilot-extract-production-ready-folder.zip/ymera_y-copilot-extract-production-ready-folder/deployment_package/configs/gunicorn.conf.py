"""
Gunicorn configuration for YMERA Platform
"""

import multiprocessing
import os

# Server socket
bind = "0.0.0.0:8000"
backlog = 2048

# Worker processes
workers = int(os.getenv("MAX_WORKERS", multiprocessing.cpu_count() * 2 + 1))
worker_class = "uvicorn.workers.UvicornWorker"
worker_connections = 1000
max_requests = 10000
max_requests_jitter = 1000
timeout = 60
keepalive = 5

# Logging
accesslog = "-"
errorlog = "-"
loglevel = os.getenv("LOG_LEVEL", "info").lower()
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process naming
proc_name = "ymera"

# Server mechanics
daemon = False
pidfile = None
umask = 0
user = None
group = None
tmp_upload_dir = None

# SSL (if needed)
# keyfile = "/path/to/key.pem"
# certfile = "/path/to/cert.pem"

# Restart workers after this many requests
reload = False
reload_engine = "auto"
reload_extra_files = []

# Preload app for better performance
preload_app = True


# Server hooks
def on_starting(server):
    """Called just before the master process is initialized."""


def on_reload(server):
    """Called to recycle workers during a reload via SIGHUP."""


def when_ready(server):
    """Called just after the server is started."""


def pre_fork(server, worker):
    """Called just before a worker is forked."""


def post_fork(server, worker):
    """Called just after a worker has been forked."""


def post_worker_init(worker):
    """Called just after a worker has initialized the application."""


def worker_int(worker):
    """Called just after a worker exited on SIGINT or SIGQUIT."""


def worker_abort(worker):
    """Called when a worker received the SIGABRT signal."""


def pre_exec(server):
    """Called just before a new master process is forked."""


def pre_request(worker, req):
    """Called just before a worker processes the request."""


def post_request(worker, req, environ, resp):
    """Called after a worker processes the request."""


def child_exit(server, worker):
    """Called just after a worker has been exited."""


def worker_exit(server, worker):
    """Called just after a worker has been exited."""


def nworkers_changed(server, new_value, old_value):
    """Called just after num_workers has been changed."""


def on_exit(server):
    """Called just before exiting Gunicorn."""
