# YMERA Platform - Deployment Package

This package contains everything needed to deploy the YMERA platform.

## Quick Start

```bash
# 1. Extract and enter directory
cd deployment_package

# 2. Configure environment
cp .env.example .env
# Edit .env with your settings

# 3. Deploy using Docker
./deploy.sh

# 4. Verify deployment
./health-check.sh
```

## Prerequisites

### Required
- **Docker** >= 20.10
- **Docker Compose** >= 2.0
- **Python** >= 3.9 (for management scripts)
- **PostgreSQL** >= 13 (if not using Docker)
- **Redis** >= 6.0 (if not using Docker)

### Recommended
- 4GB RAM minimum
- 20GB disk space
- Ubuntu 20.04+ or similar Linux distribution

## Package Contents

```
deployment_package/
├── README.md              # This file
├── docker-compose.yml     # Docker orchestration
├── .env.example           # Configuration template
├── requirements.txt       # Python dependencies
├── deploy.sh              # Deployment script
├── rollback.sh            # Rollback script
├── health-check.sh        # Health verification
├── migrations/            # Database migrations
├── configs/               # Service configurations
│   ├── nginx.conf         # Nginx configuration
│   ├── gunicorn.conf.py   # Gunicorn settings
│   └── supervisord.conf   # Process manager
├── monitoring/            # Monitoring configs
│   ├── prometheus.yml     # Prometheus configuration
│   └── grafana-dashboard.json
└── docs/                  # Documentation
    ├── DEPLOYMENT_GUIDE.md
    ├── CONFIGURATION_GUIDE.md
    ├── TROUBLESHOOTING.md
    └── API_DOCUMENTATION.md
```

## Deployment Steps

### Step 1: Configuration

1. Copy environment template:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and set required values:
   ```bash
   # Database
   DATABASE_URL=postgresql+asyncpg://user:password@db:5432/ymera
   
   # Redis
   REDIS_URL=redis://redis:6379/0
   
   # Security
   JWT_SECRET_KEY=your-secret-key-here
   
   # Application
   APP_ENV=production
   LOG_LEVEL=INFO
   ```

### Step 2: Deploy

Using Docker (Recommended):
```bash
./deploy.sh
```

Manual deployment:
```bash
# Install dependencies
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run migrations
alembic upgrade head

# Start application
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Step 3: Verify

```bash
./health-check.sh
```

Or manually:
```bash
# Check health endpoint
curl http://localhost:8000/health

# Check API documentation
open http://localhost:8000/docs
```

### Step 4: Monitor

Access monitoring dashboards:
- **Application Metrics:** http://localhost:9090 (Prometheus)
- **Grafana Dashboard:** http://localhost:3000 (Grafana)
- **Application Logs:** `docker-compose logs -f app`

## Configuration Guide

### Environment Variables

See `.env.example` for all available options.

**Critical Settings:**
- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `JWT_SECRET_KEY` - Secret for JWT tokens (CHANGE THIS!)
- `CORS_ORIGINS` - Allowed CORS origins

**Optional Settings:**
- `LOG_LEVEL` - Logging level (DEBUG, INFO, WARNING, ERROR)
- `MAX_WORKERS` - Number of worker processes
- `RATE_LIMIT_PER_MINUTE` - API rate limiting

### Database Configuration

The application supports PostgreSQL and SQLite:

**PostgreSQL (Production):**
```env
DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/dbname
```

**SQLite (Development):**
```env
DATABASE_URL=sqlite+aiosqlite:///./ymera.db
```

### Redis Configuration

**Redis (Caching):**
```env
REDIS_URL=redis://localhost:6379/0
REDIS_PASSWORD=optional-password
```

## Deployment Scenarios

### Scenario 1: Docker Compose (Recommended)

All-in-one deployment with Docker:

```bash
./deploy.sh
```

Services included:
- Application server (FastAPI)
- PostgreSQL database
- Redis cache
- Nginx reverse proxy
- Prometheus monitoring
- Grafana dashboards

### Scenario 2: Kubernetes

For Kubernetes deployment:

```bash
# Apply configurations
kubectl apply -f k8s/

# Check status
kubectl get pods -n ymera

# Access service
kubectl port-forward svc/ymera-app 8000:8000
```

### Scenario 3: Manual Deployment

For traditional server deployment:

1. Install system dependencies
2. Setup virtual environment
3. Configure services (PostgreSQL, Redis, Nginx)
4. Run application with supervisor or systemd
5. Configure monitoring

See `docs/DEPLOYMENT_GUIDE.md` for detailed instructions.

## Rollback Procedure

If deployment fails or issues arise:

```bash
./rollback.sh
```

This will:
1. Stop current services
2. Restore previous version
3. Rollback database migrations
4. Restart services

## Health Checks

Automated health checks:
```bash
./health-check.sh
```

Manual health checks:
```bash
# Application health
curl http://localhost:8000/health

# Database connectivity
curl http://localhost:8000/health/db

# Redis connectivity
curl http://localhost:8000/health/redis

# Metrics
curl http://localhost:8000/metrics
```

## Troubleshooting

### Common Issues

**Issue: Database connection failed**
```bash
# Check database is running
docker-compose ps db

# Check logs
docker-compose logs db

# Verify connection string in .env
```

**Issue: Application won't start**
```bash
# Check logs
docker-compose logs app

# Verify all environment variables set
cat .env

# Check port availability
netstat -tulpn | grep 8000
```

**Issue: High memory usage**
```bash
# Reduce worker count in .env
MAX_WORKERS=2

# Restart services
./deploy.sh
```

See `docs/TROUBLESHOOTING.md` for more issues and solutions.

## Monitoring

### Metrics

Application exposes Prometheus metrics at `/metrics`:

- Request count and latency
- Database connection pool stats
- Cache hit/miss rates
- Agent execution metrics
- Error rates

### Logging

Structured JSON logs are written to:
- Docker: `docker-compose logs -f`
- Manual: `logs/app.log`

Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL

### Alerts

Configure alerts in `monitoring/prometheus.yml`:
- High error rate
- Database connection issues
- High response latency
- Service down

## Backup and Recovery

### Database Backup

Automated backup:
```bash
./backup-db.sh
```

Manual backup:
```bash
docker-compose exec db pg_dump -U ymera ymera > backup.sql
```

### Restore from Backup

```bash
docker-compose exec -T db psql -U ymera ymera < backup.sql
```

### Application State

Important directories to backup:
- `./data/` - Application data
- `./logs/` - Application logs
- `.env` - Configuration

## Security Checklist

Before production deployment:

- [ ] Change all default passwords
- [ ] Set strong JWT_SECRET_KEY
- [ ] Configure firewall rules
- [ ] Enable HTTPS/TLS
- [ ] Review CORS settings
- [ ] Enable rate limiting
- [ ] Setup backup procedures
- [ ] Configure log retention
- [ ] Review security headers
- [ ] Enable audit logging

## Performance Tuning

### Application

```env
# Worker processes (2-4 x CPU cores)
MAX_WORKERS=4

# Connection pools
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=10
```

### Database

```sql
-- Optimize PostgreSQL
ALTER SYSTEM SET max_connections = 100;
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
```

### Caching

```env
# Redis cache settings
REDIS_MAX_CONNECTIONS=50
CACHE_TTL=3600
```

## Scaling

### Vertical Scaling
- Increase server resources (CPU, RAM)
- Adjust worker count
- Increase database connections

### Horizontal Scaling
- Add more application instances
- Use load balancer (Nginx, HAProxy)
- Share Redis for session storage
- Use read replicas for database

## Support

### Documentation
- Deployment Guide: `docs/DEPLOYMENT_GUIDE.md`
- Configuration Guide: `docs/CONFIGURATION_GUIDE.md`
- API Documentation: `docs/API_DOCUMENTATION.md`
- Troubleshooting: `docs/TROUBLESHOOTING.md`

### Getting Help
- Check logs: `docker-compose logs -f`
- Review health checks: `./health-check.sh`
- Consult troubleshooting guide

### Reporting Issues
Include in bug reports:
1. Deployment method used
2. Environment details (OS, Docker version)
3. Error messages from logs
4. Steps to reproduce
5. Configuration (sanitized .env)

## License

See LICENSE file in main repository.

---

**Last Updated:** 2025-10-20
**Version:** 2.0.0
