#!/bin/bash
# YMERA Platform Deployment Script
# Version: 2.0.0

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "============================================="
echo "YMERA Platform Deployment"
echo "============================================="
echo ""

# Check prerequisites
echo "Checking prerequisites..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Error: Docker is not installed${NC}"
    echo "Please install Docker: https://docs.docker.com/get-docker/"
    exit 1
fi
echo -e "${GREEN}✓${NC} Docker found"

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo -e "${RED}Error: Docker Compose is not installed${NC}"
    echo "Please install Docker Compose: https://docs.docker.com/compose/install/"
    exit 1
fi
echo -e "${GREEN}✓${NC} Docker Compose found"

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}Warning: .env file not found${NC}"
    echo "Creating from .env.example..."
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo -e "${GREEN}✓${NC} Created .env from template"
        echo -e "${YELLOW}Please edit .env with your configuration before proceeding${NC}"
        exit 0
    else
        echo -e "${RED}Error: .env.example not found${NC}"
        exit 1
    fi
fi
echo -e "${GREEN}✓${NC} Configuration file found"

# Validate critical environment variables
echo ""
echo "Validating configuration..."

source .env

if [ -z "$DATABASE_URL" ]; then
    echo -e "${RED}Error: DATABASE_URL not set in .env${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} DATABASE_URL configured"

if [ -z "$JWT_SECRET_KEY" ] || [ "$JWT_SECRET_KEY" == "your-secret-key-change-this-in-production" ]; then
    echo -e "${RED}Error: Please set a secure JWT_SECRET_KEY in .env${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} JWT_SECRET_KEY configured"

# Backup current deployment if exists
echo ""
echo "Checking for existing deployment..."
if docker-compose ps | grep -q "Up"; then
    echo -e "${YELLOW}Existing deployment found${NC}"
    read -p "Create backup before deploying? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
        mkdir -p "$BACKUP_DIR"
        
        # Backup database
        echo "Backing up database..."
        docker-compose exec -T db pg_dump -U ${DB_USER:-ymera} ${DB_NAME:-ymera} > "$BACKUP_DIR/database.sql" 2>/dev/null || true
        
        # Backup volumes
        echo "Backing up volumes..."
        docker-compose exec -T app tar czf - /app/data 2>/dev/null > "$BACKUP_DIR/data.tar.gz" || true
        
        echo -e "${GREEN}✓${NC} Backup created in $BACKUP_DIR"
    fi
fi

# Pull latest images
echo ""
echo "Pulling latest images..."
docker-compose pull || true

# Build images
echo ""
echo "Building application images..."
docker-compose build --no-cache

# Stop existing containers
echo ""
echo "Stopping existing containers..."
docker-compose down

# Start services
echo ""
echo "Starting services..."
docker-compose up -d

# Wait for services to be ready
echo ""
echo "Waiting for services to start..."
sleep 10

# Check if services are running
echo ""
echo "Checking service status..."
if docker-compose ps | grep -q "Up"; then
    echo -e "${GREEN}✓${NC} Services are running"
else
    echo -e "${RED}Error: Services failed to start${NC}"
    echo "Check logs with: docker-compose logs"
    exit 1
fi

# Run database migrations
echo ""
echo "Running database migrations..."
docker-compose exec -T app alembic upgrade head || true

# Health check
echo ""
echo "Performing health check..."
sleep 5

MAX_RETRIES=30
RETRY_COUNT=0
HEALTH_URL="http://localhost:8000/health"

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    if curl -f -s "$HEALTH_URL" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} Health check passed"
        break
    fi
    
    RETRY_COUNT=$((RETRY_COUNT + 1))
    echo "Waiting for application to be ready... ($RETRY_COUNT/$MAX_RETRIES)"
    sleep 2
done

if [ $RETRY_COUNT -eq $MAX_RETRIES ]; then
    echo -e "${RED}Error: Health check failed${NC}"
    echo "Check logs with: docker-compose logs app"
    exit 1
fi

# Display deployment info
echo ""
echo "============================================="
echo -e "${GREEN}Deployment Successful!${NC}"
echo "============================================="
echo ""
echo "Services:"
echo "  - Application: http://localhost:8000"
echo "  - API Docs:    http://localhost:8000/docs"
echo "  - Health:      http://localhost:8000/health"
echo "  - Metrics:     http://localhost:8000/metrics"
echo ""
echo "Monitoring:"
echo "  - Prometheus:  http://localhost:9090"
echo "  - Grafana:     http://localhost:3000"
echo ""
echo "Management Commands:"
echo "  - View logs:   docker-compose logs -f"
echo "  - Stop:        docker-compose stop"
echo "  - Restart:     docker-compose restart"
echo "  - Status:      docker-compose ps"
echo ""
echo "To rollback: ./rollback.sh"
echo "============================================="
