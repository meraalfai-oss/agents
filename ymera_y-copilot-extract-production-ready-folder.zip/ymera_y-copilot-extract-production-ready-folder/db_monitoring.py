"""
Database Health Monitoring and Alerting System
"""

import asyncio
import json
import logging
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class DatabaseHealthMonitor:
    """Monitor database health and performance metrics"""

    def __init__(self, db_manager, alert_config: Optional[Dict] = None):
        self.db_manager = db_manager
        self.alert_config = alert_config or {}
        self.metrics_history = []
        self.alert_history = []

        # Thresholds
        self.thresholds = {
            "cpu_percent": 80,
            "memory_percent": 85,
            "connection_percent": 90,
            "slow_query_threshold": 5.0,  # seconds
            "deadlock_threshold": 5,  # per hour
            "failed_login_threshold": 10,  # per hour
        }

    async def monitor_continuously(self, interval_seconds: int = 60):
        """Continuously monitor database health"""
        while True:
            try:
                metrics = await self.collect_metrics()
                self.metrics_history.append(metrics)

                # Keep only last 24 hours
                cutoff_time = datetime.now() - timedelta(hours=24)
                self.metrics_history = [
                    m
                    for m in self.metrics_history
                    if datetime.fromisoformat(m["timestamp"]) > cutoff_time
                ]

                # Check for alerts
                await self.check_alerts(metrics)

                # Log metrics
                self._log_metrics(metrics)

            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")

            await asyncio.sleep(interval_seconds)

    async def collect_metrics(self) -> Dict:
        """Collect comprehensive database metrics"""
        with self.db_manager.get_session() as session:
            metrics = {
                "timestamp": datetime.now().isoformat(),
                "database_status": await self._check_database_status(session),
                "performance": await self._collect_performance_metrics(session),
                "connections": await self._collect_connection_metrics(session),
                "storage": await self._collect_storage_metrics(session),
                "replication": await self._check_replication_status(session),
            }

        return metrics

    async def _check_database_status(self, session) -> Dict:
        """Check overall database status"""
        try:
            query = """
                SELECT
                    DB_NAME() as database_name,
                    state_desc,
                    recovery_model_desc,
                    is_read_only,
                    compatibility_level
                FROM sys.databases
                WHERE name = DB_NAME()
            """
            result = session.execute(query).fetchone()

            return {
                "database_name": result[0],
                "state": result[1],
                "recovery_model": result[2],
                "is_read_only": result[3],
                "compatibility_level": result[4],
                "status": "healthy" if result[1] == "ONLINE" else "unhealthy",
            }
        except Exception as e:
            logger.error(f"Failed to check database status: {e}")
            return {"status": "error", "error": str(e)}

    async def _collect_performance_metrics(self, session) -> Dict:
        """Collect performance metrics"""
        try:
            # CPU and memory usage
            perf_query = """
                SELECT
                    (SELECT CAST(SUM(size) * 8. / 1024 AS DECIMAL(10,2))
                     FROM sys.master_files
                     WHERE DB_NAME(database_id) = DB_NAME()) as db_size_mb,
                    (SELECT COUNT(*) FROM sys.dm_exec_requests WHERE database_id = DB_ID()) as active_requests,
                    (SELECT COUNT(*) FROM sys.dm_tran_active_transactions) as active_transactions
            """
            result = session.execute(perf_query).fetchone()

            return {
                "db_size_mb": float(result[0]),
                "active_requests": result[1],
                "active_transactions": result[2],
                "collected_at": datetime.now().isoformat(),
            }
        except Exception as e:
            logger.error(f"Failed to collect performance metrics: {e}")
            return {}

    async def _collect_connection_metrics(self, session) -> Dict:
        """Collect connection pool metrics"""
        try:
            conn_query = """
                SELECT
                    COUNT(*) as total_connections,
                    SUM(CASE WHEN status = 'sleeping' THEN 1 ELSE 0 END) as sleeping,
                    SUM(CASE WHEN status = 'running' THEN 1 ELSE 0 END) as running,
                    SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended
                FROM sys.dm_exec_sessions
                WHERE is_user_process = 1
            """
            result = session.execute(conn_query).fetchone()

            pool_status = self.db_manager.health_check()

            return {
                "total_connections": result[0],
                "sleeping": result[1],
                "running": result[2],
                "suspended": result[3],
                "pool_size": pool_status.get("pool_size", 0),
                "checked_out": pool_status.get("checked_out", 0),
                "overflow": pool_status.get("overflow", 0),
            }
        except Exception as e:
            logger.error(f"Failed to collect connection metrics: {e}")
            return {}

    async def _collect_storage_metrics(self, session) -> Dict:
        """Collect storage and space metrics"""
        try:
            storage_query = """
                SELECT
                    SUM(CAST(FILEPROPERTY(name, 'SpaceUsed') AS BIGINT) * 8. / 1024) as used_mb,
                    SUM(CAST(size AS BIGINT) * 8. / 1024) as allocated_mb,
                    SUM(CAST(max_size AS BIGINT) * 8. / 1024) as max_size_mb
                FROM sys.database_files
                WHERE type = 0  -- Data files only
            """
            result = session.execute(storage_query).fetchone()

            used_mb = float(result[0] or 0)
            allocated_mb = float(result[1] or 0)
            max_size_mb = float(result[2] or 0)

            return {
                "used_mb": used_mb,
                "allocated_mb": allocated_mb,
                "max_size_mb": max_size_mb,
                "usage_percent": (used_mb / allocated_mb * 100) if allocated_mb > 0 else 0,
                "space_available_mb": allocated_mb - used_mb,
            }
        except Exception as e:
            logger.error(f"Failed to collect storage metrics: {e}")
            return {}

    async def _check_replication_status(self, session) -> Dict:
        """Check geo-replication status"""
        try:
            repl_query = """
                SELECT
                    partner_server,
                    partner_database,
                    replication_state_desc,
                    role_desc
                FROM sys.dm_geo_replication_link_status
            """
            result = session.execute(repl_query).fetchall()

            if result:
                replicas = []
                for row in result:
                    replicas.append(
                        {
                            "partner_server": row[0],
                            "partner_database": row[1],
                            "replication_state": row[2],
                            "role": row[3],
                        }
                    )
        except Exception as e:
            logger.error(f"Failed to check replication: {e}")

        # Check storage
        storage_metrics = metrics.get("storage", {})
        if storage_metrics.get("usage_percent", 0) > 85:
            alerts.append(
                {
                    "severity": "critical",
                    "type": "storage",
                    "message": f"Database storage usage critical: {storage_metrics['usage_percent']:.1f}%",
                    "value": storage_metrics["usage_percent"],
                }
            )

        # Check database status
        db_status = metrics.get("database_status", {})
        if db_status.get("status") != "healthy":
            alerts.append(
                {
                    "severity": "critical",
                    "type": "database_status",
                    "message": f"Database not in healthy state: {db_status.get('state', 'unknown')}",
                    "value": db_status.get("state"),
                }
            )

        # Check replication
        repl_status = metrics.get("replication", {})
        if repl_status.get("enabled") and repl_status.get("replicas"):
            for replica in repl_status["replicas"]:
                if replica["replication_state"] not in ["SYNCHRONIZED", "SYNCHRONIZING"]:
                    alerts.append(
                        {
                            "severity": "warning",
                            "type": "replication",
                            "message": f"Replication issue with {replica['partner_server']}: {replica['replication_state']}",
                            "value": replica["replication_state"],
                        }
                    )

        # Send alerts if any
        if alerts:
            for alert in alerts:
                await self._send_alert(alert)
                self.alert_history.append({**alert, "timestamp": datetime.now().isoformat()})

    async def _send_alert(self, alert: Dict):
        """Send alert via configured channels"""
        logger.warning(f"ALERT: {alert['type']} - {alert['message']}")

        # Email alerts
        if self.alert_config.get("email_enabled"):
            await self._send_email_alert(alert)

        # Webhook alerts
        if self.alert_config.get("webhook_url"):
            await self._send_webhook_alert(alert)

    async def _send_email_alert(self, alert: Dict):
        """Send email alert"""
        try:
            smtp_config = self.alert_config.get("smtp", {})
            recipients = self.alert_config.get("alert_recipients", [])

            if not recipients:
                return

            msg = MIMEMultipart()
            msg["From"] = smtp_config.get("from_email")
            msg["To"] = ", ".join(recipients)
            msg["Subject"] = f"[{alert['severity'].upper()}] Database Alert: {alert['type']}"

            body = f"""
            Database Alert
            ==============

            Severity: {alert['severity']}
            Type: {alert['type']}
            Message: {alert['message']}
            Value: {alert.get('value', 'N/A')}
            Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

            Please investigate immediately.
            """

            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(smtp_config.get("host"), smtp_config.get("port", 587)) as server:
                server.starttls()
                server.login(smtp_config.get("username"), smtp_config.get("password"))
                server.send_message(msg)

            logger.info(f"Email alert sent for {alert['type']}")

        except Exception as e:
            logger.error(f"Failed to send email alert: {e}")

    async def _send_webhook_alert(self, alert: Dict):
        """Send webhook alert (e.g., to Slack, Teams, etc.)"""
        try:
            import aiohttp

            webhook_url = self.alert_config.get("webhook_url")
            payload = {
                "text": f"🚨 Database Alert: {alert['message']}",
                "severity": alert["severity"],
                "type": alert["type"],
                "value": alert.get("value"),
                "timestamp": datetime.now().isoformat(),
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(webhook_url, json=payload) as response:
                    if response.status == 200:
                        logger.info(f"Webhook alert sent for {alert['type']}")
                    else:
                        logger.error(f"Webhook alert failed: {response.status}")

        except Exception as e:
            logger.error(f"Failed to send webhook alert: {e}")

    def _log_metrics(self, metrics: Dict):
        """Log metrics to file for historical analysis"""
        log_file = Path("logs/database_metrics.jsonl")
        log_file.parent.mkdir(parents=True, exist_ok=True)

        with open(log_file, "a") as f:
            f.write(json.dumps(metrics) + "\n")

    def get_metrics_summary(self, hours: int = 24) -> Dict:
        """Get summary of metrics over time period"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_metrics = [
            m for m in self.metrics_history if datetime.fromisoformat(m["timestamp"]) > cutoff_time
        ]

        if not recent_metrics:
            return {}

        # Calculate averages
        avg_connections = sum(
            m.get("connections", {}).get("total_connections", 0) for m in recent_metrics
        ) / len(recent_metrics)

        avg_storage_usage = sum(
            m.get("storage", {}).get("usage_percent", 0) for m in recent_metrics
        ) / len(recent_metrics)

        return {
            "period_hours": hours,
            "data_points": len(recent_metrics),
            "avg_connections": avg_connections,
            "avg_storage_usage_percent": avg_storage_usage,
            "alerts_count": len(
                [
                    a
                    for a in self.alert_history
                    if datetime.fromisoformat(a["timestamp"]) > cutoff_time
                ]
            ),
        }


class DatabaseMaintenanceScheduler:
    """Schedule and execute database maintenance tasks"""

    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.maintenance_log = []

    async def run_maintenance(self):
        """Run all maintenance tasks"""
        logger.info("Starting database maintenance...")

        tasks = [
            self.update_statistics(),
            self.rebuild_fragmented_indexes(),
            self.clean_old_backups(),
            self.analyze_query_performance(),
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Log results
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Maintenance task {i} failed: {result}")
            else:
                logger.info(f"Maintenance task {i} completed: {result}")

        logger.info("Database maintenance completed")

    async def update_statistics(self):
        """Update database statistics"""
        with self.db_manager.get_session() as session:
            try:
                session.execute("EXEC sp_updatestats")
                self._log_maintenance("update_statistics", "success")
                return "Statistics updated successfully"
            except Exception as e:
                self._log_maintenance("update_statistics", "failed", str(e))
                raise

    async def rebuild_fragmented_indexes(self):
        """Rebuild fragmented indexes"""
        with self.db_manager.get_session() as session:
            try:
                # Find fragmented indexes
                query = """
                    SELECT
                        OBJECT_SCHEMA_NAME(ips.object_id) AS schema_name,
                        OBJECT_NAME(ips.object_id) AS table_name,
                        i.name AS index_name,
                        ips.avg_fragmentation_in_percent
                    FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') ips
                    INNER JOIN sys.indexes i ON ips.object_id = i.object_id
                        AND ips.index_id = i.index_id
                    WHERE ips.avg_fragmentation_in_percent > 30
                        AND ips.page_count > 1000
                """

                fragmented = session.execute(query).fetchall()

                rebuilt_count = 0
                for row in fragmented:
                    schema, table, index, frag = row
                    try:
                        rebuild_query = f"ALTER INDEX [{index}] ON [{schema}].[{table}] REBUILD"
                        session.execute(rebuild_query)
                        rebuilt_count += 1
                        logger.info(
                            f"Rebuilt index {index} on {schema}.{table} ({frag:.1f}% fragmented)"
                        )
                    except Exception as e:
                        logger.error(f"Failed to rebuild {index}: {e}")

                self._log_maintenance(
                    "rebuild_indexes", "success", f"Rebuilt {rebuilt_count} indexes"
                )
                return f"Rebuilt {rebuilt_count} fragmented indexes"

            except Exception as e:
                self._log_maintenance("rebuild_indexes", "failed", str(e))
                raise

    async def clean_old_backups(self):
        """Clean up old backup files"""
        try:
            # This would clean up local backup files
            backup_dir = Path("backups")
            if backup_dir.exists():
                cutoff_date = datetime.now() - timedelta(days=30)
                deleted_count = 0

                for backup_file in backup_dir.rglob("*.bak"):
                    if datetime.fromtimestamp(backup_file.stat().st_mtime) < cutoff_date:
                        backup_file.unlink()
                        deleted_count += 1

                self._log_maintenance(
                    "clean_backups", "success", f"Deleted {deleted_count} old backups"
                )
                return f"Cleaned {deleted_count} old backup files"

            return "No backups to clean"

        except Exception as e:
            self._log_maintenance("clean_backups", "failed", str(e))
            raise

    async def analyze_query_performance(self):
        """Analyze query performance and log slow queries"""
        with self.db_manager.get_session() as session:
            try:
                query = """
                    SELECT TOP 10
                        qs.total_elapsed_time / qs.execution_count / 1000 as avg_elapsed_ms,
                        qs.execution_count,
                        SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
                            ((CASE qs.statement_end_offset
                                WHEN -1 THEN DATALENGTH(st.text)
                                ELSE qs.statement_end_offset
                            END - qs.statement_start_offset)/2) + 1) AS query_text
                    FROM sys.dm_exec_query_stats qs
                    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
                    WHERE qs.total_elapsed_time / qs.execution_count > 1000000  -- > 1 second
                    ORDER BY avg_elapsed_ms DESC
                """

                slow_queries = session.execute(query).fetchall()

                # Log slow queries
                for row in slow_queries:
                    logger.warning(f"Slow query detected: {row[0]:.2f}ms avg, {row[1]} executions")

                self._log_maintenance(
                    "analyze_queries", "success", f"Found {len(slow_queries)} slow queries"
                )
                return f"Analyzed query performance, found {len(slow_queries)} slow queries"

            except Exception as e:
                self._log_maintenance("analyze_queries", "failed", str(e))
                raise

    def _log_maintenance(self, task: str, status: str, details: str = ""):
        """Log maintenance task execution"""
        self.maintenance_log.append(
            {
                "task": task,
                "status": status,
                "details": details,
                "timestamp": datetime.now().isoformat(),
            }
        )

        # Save to file
        log_file = Path("logs/maintenance.jsonl")
        log_file.parent.mkdir(parents=True, exist_ok=True)

        with open(log_file, "a") as f:
            f.write(json.dumps(self.maintenance_log[-1]) + "\n")


# FastAPI integration example
# """
# from fastapi import FastAPI, BackgroundTasks

app = FastAPI()

# Initialize monitor
health_monitor = DatabaseHealthMonitor(
    db_manager=db_manager,
    alert_config={
        "email_enabled": True,
        "smtp": {
            "host": "smtp.gmail.com",
            "port": 587,
            "username": "your-email@gmail.com",
            "password": "your-password",
        },
        "alert_recipients": ["admin@yourdomain.com"],
        "webhook_url": "https://hooks.slack.com/services/YOUR/WEBHOOK/URL",
    },
)


@app.on_event("startup")
async def startup_event():
    # Start monitoring in background
    asyncio.create_task(health_monitor.monitor_continuously(interval_seconds=60))


@app.get("/health/database")
async def database_health():
    metrics = await health_monitor.collect_metrics()
    return metrics


@app.get("/health/summary")
async def health_summary():
    summary = health_monitor.get_metrics_summary(hours=24)
    return summary


@app.post("/maintenance/run")
async def run_maintenance(background_tasks: BackgroundTasks):
    scheduler = DatabaseMaintenanceScheduler(db_manager)
    background_tasks.add_task(scheduler.run_maintenance)
    return {"message": "Maintenance tasks scheduled"}

    async def check_alerts(self, metrics: Dict):
        """Check metrics against thresholds and trigger alerts"""
        alerts = []

        # Check connection pool
        conn_metrics = metrics.get("connections", {})
        if conn_metrics.get("checked_out", 0) > self.thresholds["connection_percent"]:
            alerts.append(
                {
                    "severity": "warning",
                    "type": "connection_pool",
                    "message": f"Connection pool usage high: {conn_metrics['checked_out']}%",
                    "value": conn_metrics["checked_out"],
                }
            )
