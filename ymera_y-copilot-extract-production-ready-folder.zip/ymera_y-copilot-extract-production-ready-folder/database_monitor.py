"""
YMERA Database Monitoring and Health Check System
Real-time monitoring, alerts, and performance tracking
"""

import asyncio
import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List

from sqlalchemy import text

from database_core_integrated import DatabaseConfig, get_database_manager


@dataclass
class HealthCheckResult:
    """Health check result"""

    timestamp: datetime
    status: str  # healthy, degraded, unhealthy
    checks: Dict[str, Any]
    metrics: Dict[str, Any]
    alerts: List[str]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["timestamp"] = self.timestamp.isoformat()
        return data


@dataclass
class PerformanceMetrics:
    """Performance metrics"""

    timestamp: datetime
    query_count: int
    avg_query_time_ms: float
    slow_queries: int
    active_connections: int
    pool_size: int
    pool_overflow: int
    cache_hit_rate: float

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["timestamp"] = self.timestamp.isoformat()
        return data


class DatabaseMonitor:
    """Database monitoring and health checks"""

    def __init__(self):
        self.config = DatabaseConfig()
        self.metrics_history: List[PerformanceMetrics] = []
        self.health_history: List[HealthCheckResult] = []

        # Alert thresholds
        self.thresholds = {
            "slow_query_ms": 1000,
            "pool_usage_percent": 80,
            "connection_errors_percent": 10,
            "response_time_ms": 500,
        }

    async def comprehensive_health_check(self) -> HealthCheckResult:
        """Perform comprehensive health check"""
        checks = {}
        alerts = []

        db_manager = await get_database_manager()

        # 1. Database connectivity
        checks["database_connectivity"] = await self._check_connectivity(db_manager)
        if not checks["database_connectivity"]["healthy"]:
            alerts.append("Database connectivity failed")

        # 2. Connection pool status
        checks["connection_pool"] = await self._check_connection_pool(db_manager)
        if (
            checks["connection_pool"].get("usage_percent", 0)
            > self.thresholds["pool_usage_percent"]
        ):
            alerts.append(
                f"Connection pool usage high: {checks['connection_pool']['usage_percent']:.1f}%"
            )

        # 3. Query performance
        checks["query_performance"] = await self._check_query_performance(db_manager)
        if checks["query_performance"].get("slow_queries", 0) > 0:
            alerts.append(f"Slow queries detected: {checks['query_performance']['slow_queries']}")

        # 4. Table statistics
        checks["table_statistics"] = await self._check_table_statistics(db_manager)

        # 5. Disk space (if applicable)
        checks["disk_space"] = await self._check_disk_space()
        if checks["disk_space"].get("usage_percent", 0) > 90:
            alerts.append(f"Disk space critical: {checks['disk_space']['usage_percent']:.1f}% used")

        # 6. Replication status (if applicable)
        checks["replication"] = await self._check_replication(db_manager)

        # Determine overall status
        if any(not check.get("healthy", True) for check in checks.values()):
            status = "unhealthy"
        elif alerts:
            status = "degraded"
        else:
            status = "healthy"

        # Collect metrics
        metrics = await db_manager.get_statistics()

        result = HealthCheckResult(
            timestamp=datetime.utcnow(),
            status=status,
            checks=checks,
            metrics=metrics,
            alerts=alerts,
        )

        self.health_history.append(result)

        return result

    async def _check_connectivity(self, db_manager) -> Dict[str, Any]:
        """Check database connectivity"""
        try:
            start_time = time.time()
            health = await db_manager.health_check()
            response_time_ms = (time.time() - start_time) * 1000

            return {
                "healthy": health.get("healthy", False),
                "response_time_ms": response_time_ms,
                "database_type": health.get("database_type"),
                "timestamp": datetime.utcnow().isoformat(),
            }
        except Exception as e:
            return {"healthy": False, "error": str(e), "timestamp": datetime.utcnow().isoformat()}

    async def _check_connection_pool(self, db_manager) -> Dict[str, Any]:
        """Check connection pool status"""
        try:
            health = await db_manager.health_check()
            pool_stats = health.get("pool_stats", {})

            if pool_stats:
                pool_size = pool_stats.get("pool_size", 0)
                checked_out = pool_stats.get("checked_out", 0)
                usage_percent = (checked_out / pool_size * 100) if pool_size > 0 else 0

                return {
                    "healthy": usage_percent < self.thresholds["pool_usage_percent"],
                    "pool_size": pool_size,
                    "checked_in": pool_stats.get("checked_in", 0),
                    "checked_out": checked_out,
                    "overflow": pool_stats.get("overflow", 0),
                    "usage_percent": usage_percent,
                }
            else:
                return {"healthy": True, "message": "Pool statistics not available (SQLite)"}
        except Exception as e:
            return {"healthy": False, "error": str(e)}

    async def _check_query_performance(self, db_manager) -> Dict[str, Any]:
        """Check query performance"""
        try:
            async with db_manager.get_session() as session:
                # Test query performance
                queries = [
                    ("SELECT COUNT(*) FROM users", "users_count"),
                    ("SELECT COUNT(*) FROM projects", "projects_count"),
                    ("SELECT COUNT(*) FROM tasks", "tasks_count"),
                ]

                query_times = []
                slow_queries = 0

                for query, name in queries:
                    start_time = time.time()
                    await session.execute(text(query))
                    query_time_ms = (time.time() - start_time) * 1000
                    query_times.append(query_time_ms)

                    if query_time_ms > self.thresholds["slow_query_ms"]:
                        slow_queries += 1

                avg_query_time_ms = sum(query_times) / len(query_times) if query_times else 0

                return {
                    "healthy": slow_queries == 0,
                    "avg_query_time_ms": avg_query_time_ms,
                    "max_query_time_ms": max(query_times) if query_times else 0,
                    "slow_queries": slow_queries,
                    "queries_tested": len(queries),
                }
        except Exception as e:
            return {"healthy": False, "error": str(e)}

    async def _check_table_statistics(self, db_manager) -> Dict[str, Any]:
        """Check table statistics"""
        try:
            stats = await db_manager.get_statistics()

            return {
                "healthy": True,
                "users_count": stats.get("users_count", 0),
                "projects_count": stats.get("projects_count", 0),
                "agents_count": stats.get("agents_count", 0),
                "tasks_count": stats.get("tasks_count", 0),
                "files_count": stats.get("files_count", 0),
                "audit_logs_count": stats.get("audit_logs_count", 0),
                "recent_activity_24h": stats.get("recent_activity_24h", 0),
            }
        except Exception as e:
            return {"healthy": False, "error": str(e)}

    async def _check_disk_space(self) -> Dict[str, Any]:
        """Check disk space"""
        try:
            if self.config.is_sqlite:
                # Check SQLite database file size
                db_path = self.config.database_url.replace("sqlite+aiosqlite:///", "").replace(
                    "./", ""
                )
                file_path = Path(db_path)

                if file_path.exists():
                    import psutil

                    disk_usage = psutil.disk_usage(file_path.parent)

                    return {
                        "healthy": disk_usage.percent < 90,
                        "total_gb": disk_usage.total / (1024**3),
                        "used_gb": disk_usage.used / (1024**3),
                        "free_gb": disk_usage.free / (1024**3),
                        "usage_percent": disk_usage.percent,
                        "database_size_mb": file_path.stat().st_size / (1024**2),
                    }

            return {"healthy": True, "message": "Disk space check not applicable"}
        except Exception as e:
            return {"healthy": True, "error": str(e), "message": "Could not check disk space"}

    async def _check_replication(self, db_manager) -> Dict[str, Any]:
        """Check replication status (PostgreSQL)"""
        try:
            if self.config.is_postgres:
                async with db_manager.get_session() as session:
                    result = await session.execute(text("SELECT count(*) FROM pg_stat_replication"))
                    replicas = result.scalar()

                    return {"healthy": True, "replicas_count": replicas, "enabled": replicas > 0}

            return {"healthy": True, "enabled": False, "message": "Replication not applicable"}
        except Exception as e:
            return {"healthy": True, "enabled": False, "error": str(e)}

    async def collect_performance_metrics(self) -> PerformanceMetrics:
        """Collect performance metrics"""
        db_manager = await get_database_manager()

        async with db_manager.get_session() as session:
            # Simulate metrics collection (in production, use actual query stats)
            health = await db_manager.health_check()
            pool_stats = health.get("pool_stats", {})

            metrics = PerformanceMetrics(
                timestamp=datetime.utcnow(),
                query_count=0,  # Would come from query log
                avg_query_time_ms=0.0,  # Would come from query log
                slow_queries=0,  # Would come from query log
                active_connections=pool_stats.get("checked_out", 0),
                pool_size=pool_stats.get("pool_size", 0),
                pool_overflow=pool_stats.get("overflow", 0),
                cache_hit_rate=0.0,  # Would come from cache stats
            )

            self.metrics_history.append(metrics)

            return metrics

    async def generate_report(self, hours: int = 24) -> Dict[str, Any]:
        """Generate monitoring report"""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)

        # Filter recent health checks
        recent_health = [h for h in self.health_history if h.timestamp > cutoff_time]

        # Calculate health statistics
        if recent_health:
            healthy_count = sum(1 for h in recent_health if h.status == "healthy")
            degraded_count = sum(1 for h in recent_health if h.status == "degraded")
            unhealthy_count = sum(1 for h in recent_health if h.status == "unhealthy")

            uptime_percent = (healthy_count / len(recent_health)) * 100
        else:
            healthy_count = degraded_count = unhealthy_count = 0
            uptime_percent = 0.0

        # Get current statistics
        db_manager = await get_database_manager()
        current_stats = await db_manager.get_statistics()

        report = {
            "report_period_hours": hours,
            "generated_at": datetime.utcnow().isoformat(),
            "health_summary": {
                "total_checks": len(recent_health),
                "healthy_count": healthy_count,
                "degraded_count": degraded_count,
                "unhealthy_count": unhealthy_count,
                "uptime_percent": uptime_percent,
            },
            "current_statistics": current_stats,
            "alerts": [
                alert for health in recent_health[-10:] for alert in health.alerts  # Last 10 checks
            ],
            "recommendations": self._generate_recommendations(recent_health),
        }

        return report

    def _generate_recommendations(self, health_checks: List[HealthCheckResult]) -> List[str]:
        """Generate recommendations based on health checks"""
        recommendations = []

        if not health_checks:
            return recommendations

        # Check for recurring issues
        pool_warnings = sum(
            1 for h in health_checks if any("Connection pool" in alert for alert in h.alerts)
        )

        if pool_warnings > len(health_checks) * 0.3:
            recommendations.append(
                "Consider increasing connection pool size (DB_POOL_SIZE environment variable)"
            )

        slow_query_warnings = sum(
            1 for h in health_checks if any("Slow queries" in alert for alert in h.alerts)
        )

        if slow_query_warnings > 0:
            recommendations.append("Review and optimize slow queries, consider adding indexes")

        disk_warnings = sum(
            1 for h in health_checks if any("Disk space" in alert for alert in h.alerts)
        )

        if disk_warnings > 0:
            recommendations.append("Disk space running low - consider cleanup or expanding storage")

        return recommendations

    async def export_metrics(self, output_path: Path) -> None:
        """Export metrics to JSON file"""
        data = {
            "exported_at": datetime.utcnow().isoformat(),
            "health_checks": [h.to_dict() for h in self.health_history],
            "performance_metrics": [m.to_dict() for m in self.metrics_history],
        }

        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

        print(f"✓ Metrics exported to {output_path}")


async def main():
    """CLI for database monitor"""
    import argparse

    parser = argparse.ArgumentParser(description="YMERA Database Monitor")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # health command
    subparsers.add_parser("health", help="Run comprehensive health check")

    # metrics command
    subparsers.add_parser("metrics", help="Collect performance metrics")

    # report command
    report_parser = subparsers.add_parser("report", help="Generate monitoring report")
    report_parser.add_argument("--hours", type=int, default=24, help="Report period in hours")

    # monitor command
    monitor_parser = subparsers.add_parser("monitor", help="Continuous monitoring")
    monitor_parser.add_argument(
        "--interval", type=int, default=60, help="Check interval in seconds"
    )
    monitor_parser.add_argument("--duration", type=int, help="Monitoring duration in minutes")

    # export command
    export_parser = subparsers.add_parser("export", help="Export metrics to file")
    export_parser.add_argument("output_file", help="Output file path")

    args = parser.parse_args()

    monitor = DatabaseMonitor()

    if args.command == "health":
        result = await monitor.comprehensive_health_check()

        print("\n" + "=" * 80)
        print("DATABASE HEALTH CHECK REPORT")
        print("=" * 80)
        print(f"\nStatus: {result.status.upper()}")
        print(f"Timestamp: {result.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")

        print("\nChecks:")
        for check_name, check_data in result.checks.items():
            status = "✓" if check_data.get("healthy", True) else "✗"
            print(f"  {status} {check_name.replace('_', ' ').title()}")

        if result.alerts:
            print("\nAlerts:")
            for alert in result.alerts:
                print(f"  ⚠ {alert}")

        print("\nKey Metrics:")
        for key, value in result.metrics.items():
            print(f"  {key}: {value}")

        print("\n" + "=" * 80 + "\n")

    elif args.command == "metrics":
        metrics = await monitor.collect_performance_metrics()

        print("\nPerformance Metrics:")
        print("=" * 60)
        print(f"Timestamp: {metrics.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Active Connections: {metrics.active_connections}")
        print(f"Pool Size: {metrics.pool_size}")
        print(f"Pool Overflow: {metrics.pool_overflow}")
        print(f"Avg Query Time: {metrics.avg_query_time_ms:.2f}ms")
        print("=" * 60 + "\n")

    elif args.command == "report":
        report = await monitor.generate_report(args.hours)

        print("\n" + "=" * 80)
        print(f"MONITORING REPORT - Last {args.hours} hours")
        print("=" * 80)

        print("\nHealth Summary:")
        for key, value in report["health_summary"].items():
            print(f"  {key}: {value}")

        print("\nCurrent Statistics:")
        for key, value in report["current_statistics"].items():
            print(f"  {key}: {value}")

        if report["alerts"]:
            print("\nRecent Alerts:")
            for alert in report["alerts"][:10]:  # Show last 10
                print(f"  ⚠ {alert}")

        if report["recommendations"]:
            print("\nRecommendations:")
            for rec in report["recommendations"]:
                print(f"  💡 {rec}")

        print("\n" + "=" * 80 + "\n")

    elif args.command == "monitor":
        print(f"\nStarting continuous monitoring (interval: {args.interval}s)")
        print("Press Ctrl+C to stop\n")

        try:
            start_time = time.time()

            while True:
                result = await monitor.comprehensive_health_check()

                timestamp = result.timestamp.strftime("%H:%M:%S")
                status_icon = (
                    "✓"
                    if result.status == "healthy"
                    else "⚠" if result.status == "degraded" else "✗"
                )

                print(f"[{timestamp}] {status_icon} Status: {result.status.upper()}", end="")

                if result.alerts:
                    print(f" - Alerts: {len(result.alerts)}")
                else:
                    print()

                # Check duration
                if args.duration:
                    elapsed_minutes = (time.time() - start_time) / 60
                    if elapsed_minutes >= args.duration:
                        break

                await asyncio.sleep(args.interval)

        except KeyboardInterrupt:
            print("\n\nMonitoring stopped")

            # Generate final report
            report = await monitor.generate_report(hours=24)
            print(f"\nTotal checks performed: {report['health_summary']['total_checks']}")
            print(f"Uptime: {report['health_summary']['uptime_percent']:.2f}%\n")

    elif args.command == "export":
        await monitor.export_metrics(Path(args.output_file))

    else:
        parser.print_help()


if __name__ == "__main__":
    asyncio.run(main())
