-- Enhanced audit logs table with partitioning
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id VARCHAR(100) NOT NULL,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    status VARCHAR(20) DEFAULT 'success',
    details JSONB,
    -- Indexes for performance
    CONSTRAINT valid_status CHECK (status IN ('success', 'failure', 'warning'))
) PARTITION BY RANGE (timestamp);

-- Create monthly partitions
CREATE TABLE audit_logs_y2024m01 PARTITION OF audit_logs 
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
CREATE TABLE audit_logs_y2024m02 PARTITION OF audit_logs 
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');

-- Indexes for performance
CREATE INDEX CONCURRENTLY idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX CONCURRENTLY idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX CONCURRENTLY idx_audit_logs_action ON audit_logs(action);
CREATE INDEX CONCURRENTLY idx_audit_logs_resource ON audit_logs(resource_type, resource_id);

-- Full-text search index
CREATE INDEX CONCURRENTLY idx_audit_logs_details_gin ON audit_logs USING GIN (details);

-- Enhanced users table with security fields
ALTER TABLE users 
    ADD COLUMN IF NOT EXISTS risk_score FLOAT DEFAULT 0.0,
    ADD COLUMN IF NOT EXISTS last_risk_assessment TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS mfa_method VARCHAR(20) DEFAULT 'totp',
    ADD COLUMN IF NOT EXISTS webauthn_credentials JSONB DEFAULT '[]',
    ADD COLUMN IF NOT EXISTS adaptive_auth_factors JSONB DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS permissions JSONB DEFAULT '[]';

-- Encrypted fields table for sensitive data
CREATE TABLE encrypted_fields (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name VARCHAR(100) NOT NULL,
    record_id UUID NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    encrypted_value BYTEA NOT NULL,
    key_id VARCHAR(100) NOT NULL,
    encryption_algorithm VARCHAR(50) DEFAULT 'AES-256-GCM',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    -- Indexes
    INDEX idx_encrypted_fields_record (table_name, record_id, field_name)
);

-- Security events table for SIEM integration
CREATE TABLE security_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type VARCHAR(100) NOT NULL,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    source VARCHAR(100) DEFAULT 'ymera_enterprise',
    details JSONB NOT NULL,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE,
    -- Indexes
    INDEX idx_security_events_timestamp ON security_events(timestamp),
    INDEX idx_security_events_type ON security_events(event_type),
    INDEX idx_security_events_severity ON security_events(severity)
) PARTITION BY RANGE (timestamp);