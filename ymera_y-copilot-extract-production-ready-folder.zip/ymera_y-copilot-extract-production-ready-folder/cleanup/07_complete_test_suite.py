#!/usr/bin/env python3
"""
Complete Test Suite
Tests all agents after cleanup
"""

import importlib
import json
import sys
from datetime import datetime
from pathlib import Path

# Add agents to path
sys.path.insert(0, str(Path(__file__).parent.parent / "agents"))

from agent_base import Priority, TaskRequest


class CompleteTester:
    def __init__(self, root_path: Path):
        self.root = root_path
        self.results = []

    def test_all(self):
        """Test all agents."""
        print("=" * 80)
        print("COMPLETE AGENT TEST SUITE")
        print("=" * 80)

        # Find all agent files
        agents_dir = self.root / "agents"
        agent_files = sorted(agents_dir.glob("*_agent.py"))

        print(f"\nFound {len(agent_files)} agent files")
        print("\nTesting agents...")

        for agent_file in agent_files:
            self._test_agent(agent_file)

        # Generate report
        self._generate_report()

        # Summary
        passed = sum(1 for r in self.results if r["status"] == "PASS")
        failed = sum(1 for r in self.results if r["status"] == "FAIL")

        print("\n" + "=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        print(f"Total: {len(self.results)}")
        print(f"Passed: {passed} ({passed/len(self.results)*100:.1f}%)")
        print(f"Failed: {failed} ({failed/len(self.results)*100:.1f}%)")
        print("=" * 80)

    def _test_agent(self, agent_file: Path):
        """Test a single agent."""
        print(f"\n{agent_file.name}...", end=" ")

        result = {"file": agent_file.name, "status": "UNKNOWN", "tests": {}, "errors": []}

        try:
            # Import agent module
            module_name = agent_file.stem
            module = importlib.import_module(module_name)

            # Find agent class
            agent_class = None
            for item_name in dir(module):
                item = getattr(module, item_name)
                if (
                    isinstance(item, type)
                    and item_name.endswith("Agent")
                    and item_name != "BaseAgent"
                ):
                    agent_class = item
                    break

            if not agent_class:
                result["status"] = "FAIL"
                result["errors"].append("No agent class found")
                print("❌ FAIL (No agent class)")
                self.results.append(result)
                return

            # Test 1: Instantiation
            try:
                agent = agent_class()
                result["tests"]["instantiation"] = "PASS"
            except Exception as e:
                result["tests"]["instantiation"] = "FAIL"
                result["errors"].append(f"Instantiation failed: {e}")
                result["status"] = "FAIL"
                print("❌ FAIL (Instantiation)")
                self.results.append(result)
                return

            # Test 2: Health check
            try:
                health = agent.health_check()
                if "status" in health and health["status"] == "healthy":
                    result["tests"]["health_check"] = "PASS"
                else:
                    result["tests"]["health_check"] = "FAIL"
                    result["errors"].append("Health check returned unhealthy")
            except Exception as e:
                result["tests"]["health_check"] = "FAIL"
                result["errors"].append(f"Health check failed: {e}")

            # Test 3: Get info
            try:
                info = agent.get_info()
                if "agent_id" in info and "name" in info:
                    result["tests"]["get_info"] = "PASS"
                else:
                    result["tests"]["get_info"] = "FAIL"
                    result["errors"].append("get_info missing required fields")
            except Exception as e:
                result["tests"]["get_info"] = "FAIL"
                result["errors"].append(f"get_info failed: {e}")

            # Test 4: Task processing (basic)
            try:
                task_types = agent.get_supported_task_types()
                if task_types:
                    task = TaskRequest(task_type=task_types[0], priority=Priority.LOW, payload={})
                    agent.process_task(task)
                    result["tests"]["task_processing"] = "PASS"
                else:
                    result["tests"]["task_processing"] = "SKIP"
            except Exception as e:
                result["tests"]["task_processing"] = "FAIL"
                result["errors"].append(f"Task processing failed: {e}")

            # Overall status
            if all(v == "PASS" for v in result["tests"].values() if v != "SKIP"):
                result["status"] = "PASS"
                print("✅ PASS")
            else:
                result["status"] = "FAIL"
                print("❌ FAIL")

        except Exception as e:
            result["status"] = "FAIL"
            result["errors"].append(f"Unexpected error: {e}")
            print(f"❌ FAIL ({e})")

        self.results.append(result)

    def _generate_report(self):
        """Generate test report."""
        report_path = self.root / "cleanup" / "07_test_results.json"

        with open(report_path, "w") as f:
            json.dump(
                {
                    "timestamp": datetime.now().isoformat(),
                    "total": len(self.results),
                    "passed": sum(1 for r in self.results if r["status"] == "PASS"),
                    "failed": sum(1 for r in self.results if r["status"] == "FAIL"),
                    "results": self.results,
                },
                f,
                indent=2,
            )

        print(f"\nReport saved: {report_path}")


if __name__ == "__main__":
    tester = CompleteTester(Path.cwd())
    tester.test_all()
