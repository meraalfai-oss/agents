#!/usr/bin/env python3
"""
Configuration Unification
Consolidates all config files into single source of truth
"""

from pathlib import Path
from typing import Any, Dict


class ConfigUnifier:
    def __init__(self, root_path: Path):
        self.root = root_path
        self.configs = []

    def unify(self):
        """Unify all configuration files."""
        print("=" * 80)
        print("CONFIGURATION UNIFICATION")
        print("=" * 80)

        # Step 1: Find all config files
        print("\n1. Finding configuration files...")
        self._find_configs()

        # Step 2: Parse and merge
        print("\n2. Merging configurations...")
        unified = self._merge_configs()

        # Step 3: Create unified config
        print("\n3. Creating unified configuration...")
        self._create_unified_config(unified)

        # Step 4: Create .env template
        print("\n4. Creating .env template...")
        self._create_env_template(unified)

        print("\n" + "=" * 80)
        print("✅ Configuration Unified!")
        print("=" * 80)

    def _find_configs(self):
        """Find all configuration files."""
        config_patterns = ["config", "setting", ".env"]

        for py_file in self.root.rglob("*.py"):
            if any(part.startswith(".") or part == "venv" for part in py_file.parts):
                continue

            if any(pattern in py_file.name.lower() for pattern in config_patterns):
                self.configs.append(py_file)
                print(f"   Found: {py_file.relative_to(self.root)}")

        print(f"\n   Total: {len(self.configs)} config files")

    def _merge_configs(self) -> Dict[str, Any]:
        """Merge all configs into one."""
        unified = {
            "database": {},
            "api": {},
            "agents": {},
            "security": {},
            "logging": {},
            "performance": {},
            "integrations": {},
            "other": {},
        }

        for config_file in self.configs:
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    content = f.read()

                # Extract configuration values
                # This is simplified - you may need more sophisticated parsing
                if "DATABASE_URL" in content or "DB_" in content:
                    print(f"   Database config in: {config_file.name}")
                if "API_KEY" in content or "SECRET" in content:
                    print(f"   Security config in: {config_file.name}")
                if "LOG_" in content:
                    print(f"   Logging config in: {config_file.name}")

            except Exception as e:
                print(f"   ⚠️  Failed to read {config_file.name}: {e}")

        return unified

    def _create_unified_config(self, unified: Dict[str, Any]):
        """Create unified configuration file."""
        config_path = self.root / "core" / "config.py"
        config_path.parent.mkdir(exist_ok=True)

        config_content = '''"""
YMERA Unified Configuration
Single source of truth for all configuration
"""

import os
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """Database configuration."""
    url: str = Field(default="postgresql://localhost/ymera", env="DATABASE_URL")
    pool_size: int = Field(default=20, env="DB_POOL_SIZE")
    max_overflow: int = Field(default=10, env="DB_MAX_OVERFLOW")
    echo: bool = Field(default=False, env="DB_ECHO")


class RedisSettings(BaseSettings):
    """Redis cache configuration."""
    url: str = Field(default="redis://localhost:6379/0", env="REDIS_URL")
    max_connections: int = Field(default=50, env="REDIS_MAX_CONNECTIONS")
    socket_timeout: int = Field(default=5, env="REDIS_SOCKET_TIMEOUT")


class APISettings(BaseSettings):
    """API configuration."""
    host: str = Field(default="0.0.0.0", env="API_HOST")
    port: int = Field(default=8000, env="API_PORT")
    workers: int = Field(default=4, env="API_WORKERS")
    reload: bool = Field(default=False, env="API_RELOAD")
    cors_origins: list = Field(default=["*"], env="CORS_ORIGINS")


class SecuritySettings(BaseSettings):
    """Security configuration."""
    secret_key: str = Field(env="SECRET_KEY")
    algorithm: str = Field(default="HS256", env="JWT_ALGORITHM")
    access_token_expire_minutes: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE")
    refresh_token_expire_days: int = Field(default=7, env="REFRESH_TOKEN_EXPIRE")


class AISettings(BaseSettings):
    """AI/LLM configuration."""
    openai_api_key: Optional[str] = Field(default=None, env="OPENAI_API_KEY")
    anthropic_api_key: Optional[str] = Field(default=None, env="ANTHROPIC_API_KEY")
    google_api_key: Optional[str] = Field(default=None, env="GOOGLE_API_KEY")
    default_model: str = Field(default="gpt-4", env="DEFAULT_AI_MODEL")
    max_tokens: int = Field(default=2000, env="MAX_TOKENS")
    temperature: float = Field(default=0.7, env="TEMPERATURE")


class LoggingSettings(BaseSettings):
    """Logging configuration."""
    level: str = Field(default="INFO", env="LOG_LEVEL")
    format: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        env="LOG_FORMAT"
    )
    file: Optional[str] = Field(default=None, env="LOG_FILE")
    max_bytes: int = Field(default=10485760, env="LOG_MAX_BYTES")  # 10MB
    backup_count: int = Field(default=5, env="LOG_BACKUP_COUNT")


class AgentSettings(BaseSettings):
    """Agent system configuration."""
    max_concurrent: int = Field(default=10, env="MAX_CONCURRENT_AGENTS")
    task_timeout: int = Field(default=300, env="AGENT_TASK_TIMEOUT")
    retry_attempts: int = Field(default=3, env="AGENT_RETRY_ATTEMPTS")
    registry_enabled: bool = Field(default=True, env="AGENT_REGISTRY_ENABLED")


class PerformanceSettings(BaseSettings):
    """Performance tuning configuration."""
    enable_caching: bool = Field(default=True, env="ENABLE_CACHING")
    cache_ttl: int = Field(default=3600, env="CACHE_TTL")
    rate_limit_enabled: bool = Field(default=True, env="RATE_LIMIT_ENABLED")
    rate_limit_requests: int = Field(default=100, env="RATE_LIMIT_REQUESTS")
    rate_limit_window: int = Field(default=60, env="RATE_LIMIT_WINDOW")


class Settings(BaseSettings):
    """Main settings class combining all configurations."""

    # Environment
    environment: str = Field(default="development", env="ENVIRONMENT")
    debug: bool = Field(default=False, env="DEBUG")

    # Sub-settings
    database: DatabaseSettings = DatabaseSettings()
    redis: RedisSettings = RedisSettings()
    api: APISettings = APISettings()
    security: SecuritySettings = SecuritySettings()
    ai: AISettings = AISettings()
    logging: LoggingSettings = LoggingSettings()
    agents: AgentSettings = AgentSettings()
    performance: PerformanceSettings = PerformanceSettings()

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Global settings instance
settings = Settings()


def get_settings() -> Settings:
    """Get global settings instance."""
    return settings


def reload_settings():
    """Reload settings from environment."""
    global settings
    settings = Settings()
    return settings
'''

        with open(config_path, "w") as f:
            f.write(config_content)

        print(f"   Created: {config_path.relative_to(self.root)}")

    def _create_env_template(self, unified: Dict[str, Any]):
        """Create .env.example template."""
        env_path = self.root / ".env.example.unified"

        env_content = """# YMERA Environment Configuration
# Copy this file to .env and fill in your values

# Environment
ENVIRONMENT=development
DEBUG=false

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/ymera
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=10
DB_ECHO=false

# Redis Cache
REDIS_URL=redis://localhost:6379/0
REDIS_MAX_CONNECTIONS=50
REDIS_SOCKET_TIMEOUT=5

# API
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4
API_RELOAD=false
CORS_ORIGINS=["http://localhost:3000"]

# Security
SECRET_KEY=your-secret-key-here-change-in-production
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE=30
REFRESH_TOKEN_EXPIRE=7

# AI/LLM Keys
OPENAI_API_KEY=your-openai-key
ANTHROPIC_API_KEY=your-anthropic-key
GOOGLE_API_KEY=your-google-key
DEFAULT_AI_MODEL=gpt-4
MAX_TOKENS=2000
TEMPERATURE=0.7

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=%(asctime)s - %(name)s - %(levelname)s - %(message)s
LOG_FILE=logs/ymera.log
LOG_MAX_BYTES=10485760
LOG_BACKUP_COUNT=5

# Agents
MAX_CONCURRENT_AGENTS=10
AGENT_TASK_TIMEOUT=300
AGENT_RETRY_ATTEMPTS=3
AGENT_REGISTRY_ENABLED=true

# Performance
ENABLE_CACHING=true
CACHE_TTL=3600
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60
"""

        with open(env_path, "w") as f:
            f.write(env_content)

        print(f"   Created: {env_path.relative_to(self.root)}")


if __name__ == "__main__":
    unifier = ConfigUnifier(Path.cwd())
    unifier.unify()
