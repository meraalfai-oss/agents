# Migration Guide: Adopting Unified Components

## Overview

This guide helps teams migrate from the existing configuration, requirements, and agent base patterns to the new unified components created in Phase 3.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Migration Strategy](#migration-strategy)
3. [Configuration Migration](#configuration-migration)
4. [Requirements Migration](#requirements-migration)
5. [Agent Base Migration](#agent-base-migration)
6. [Testing & Validation](#testing--validation)
7. [Rollback Plan](#rollback-plan)

## Prerequisites

Before starting the migration:

- [ ] Review `cleanup/PHASE3_COMPLETION_REPORT.md`
- [ ] Understand current configuration patterns in your codebase
- [ ] Have a backup of current state (automated by scripts)
- [ ] Set up a testing environment

## Migration Strategy

### Phased Approach (Recommended)

**Phase 1: Parallel Running (Weeks 1-2)**
- Keep both old and new systems running
- Test unified components in development
- No production changes

**Phase 2: Gradual Adoption (Weeks 3-4)**
- New features use unified components
- Existing features remain on old system
- Monitor for issues

**Phase 3: Complete Migration (Weeks 5-6)**
- Migrate remaining features
- Remove old configuration files
- Update all documentation

### Big Bang Approach (Advanced Teams Only)

For teams with comprehensive test coverage:
- Replace all at once in a single deployment
- Requires extensive testing beforehand
- Not recommended for production systems

## Configuration Migration

### Step 1: Review Unified Configuration

```python
# New unified configuration structure
from core.config import get_settings

settings = get_settings()

# Access configuration
database_url = settings.database.url
redis_url = settings.redis.url
api_port = settings.api.port
secret_key = settings.security.secret_key
```

### Step 2: Update Environment Variables

Create or update your `.env` file based on `.env.example.unified`:

```bash
# Copy template
cp .env.example.unified .env

# Edit with your values
nano .env
```

### Step 3: Migrate Configuration Imports

**Before:**
```python
from config import settings
from settings import Settings

# Usage
db_url = settings.database_url
port = settings.api_port
```

**After:**
```python
from core.config import get_settings

settings = get_settings()

# Usage
db_url = settings.database.url
port = settings.api.port
```

### Step 4: Test Configuration

```python
# Test script
from core.config import get_settings

settings = get_settings()
print(f"Database: {settings.database.url}")
print(f"Redis: {settings.redis.url}")
print(f"API: {settings.api.host}:{settings.api.port}")
```

## Requirements Migration

### Step 1: Review Unified Requirements

```bash
# View unified requirements
cat requirements.unified.txt

# Compare with current
diff requirements.txt requirements.unified.txt
```

### Step 2: Test in Development

```bash
# Create new virtual environment
python -m venv venv-unified
source venv-unified/bin/activate  # On Windows: venv-unified\Scripts\activate

# Install unified requirements
pip install -r requirements.unified.txt

# Run tests
pytest tests/
```

### Step 3: Update CI/CD Pipelines

**Before:**
```yaml
# .github/workflows/ci.yml
- name: Install dependencies
  run: pip install -r requirements.txt
```

**After:**
```yaml
# .github/workflows/ci.yml
- name: Install dependencies
  run: pip install -r requirements.unified.txt
```

### Step 4: Deploy to Production

```bash
# On production server
pip install -r requirements.unified.txt --upgrade

# Verify installation
pip list
```

## Agent Base Migration

### Step 1: Create Agent Using Unified Base

**Before:**
```python
from agents.agent_base import BaseAgent, AgentConfig

class MyAgent(BaseAgent):
    def __init__(self):
        super().__init__(AgentConfig(name="MyAgent"))
    
    def execute(self, task):
        # Custom logic
        pass
```

**After:**
```python
from agents.agent_base_unified import (
    BaseAgent, 
    AgentConfig, 
    AgentCapability,
    TaskRequest,
    TaskResponse
)

class MyAgent(BaseAgent):
    def __init__(self):
        config = AgentConfig(
            name="MyAgent",
            description="My agent description",
            capabilities=[
                AgentCapability(
                    name="processing",
                    description="Process data",
                    task_types=["process_data"]
                )
            ]
        )
        super().__init__(config)
    
    def _execute_task(self, task: TaskRequest):
        # Custom logic
        return {"status": "success"}
```

### Step 2: Use Agent Registry

```python
from agents.agent_registry_unified import get_registry

# Get global registry
registry = get_registry()

# Register agent
agent = MyAgent()
registry.register(agent)

# Find agent
found_agent = registry.get_by_name("MyAgent")

# Health check all agents
health = registry.health_check_all()
```

### Step 3: Use Shared Utilities

```python
from agents.shared_utils_unified import (
    load_config,
    save_config,
    validate_payload,
    DataCache
)

# Load configuration
config = load_config("path/to/config.json")

# Validate payload
valid, error = validate_payload(
    payload={"key": "value"},
    required_keys=["key"]
)

# Use cache
cache = DataCache()
cache.set("key", "value")
value = cache.get("key")
```

### Step 4: Migrate Existing Agents

Create a migration checklist for each agent:

- [ ] Import unified base classes
- [ ] Update agent initialization
- [ ] Implement `_execute_task()` method
- [ ] Define capabilities
- [ ] Register with unified registry
- [ ] Update tests
- [ ] Verify health checks work

## Testing & Validation

### Unit Tests

```python
import pytest
from agents.agent_base_unified import BaseAgent, AgentConfig, TaskRequest

def test_agent_creation():
    agent = MyAgent()
    assert agent.name == "MyAgent"
    
def test_agent_task_processing():
    agent = MyAgent()
    task = TaskRequest(task_type="process_data")
    response = agent.process_task(task)
    assert response.status == TaskStatus.SUCCESS

def test_agent_health():
    agent = MyAgent()
    health = agent.health_check()
    assert health['status'] == 'healthy'
```

### Integration Tests

```python
def test_configuration_integration():
    from core.config import get_settings
    settings = get_settings()
    assert settings.database.url
    assert settings.api.port > 0

def test_agent_registry_integration():
    from agents.agent_registry_unified import get_registry
    registry = get_registry()
    agent = MyAgent()
    registry.register(agent)
    found = registry.get_by_name("MyAgent")
    assert found is not None
```

### Verification Script

Run the automated verification:

```bash
python cleanup/07_test_unified_components.py
```

## Rollback Plan

If issues occur during migration:

### Configuration Rollback

```bash
# Restore old config imports
# The old config.py and settings.py still exist
# Simply revert import changes in your code
```

### Requirements Rollback

```bash
# Restore from backup
cp cleanup/backup/requirements.txt.backup requirements.txt

# Reinstall
pip install -r requirements.txt
```

### Agent Base Rollback

```bash
# Agents with _unified suffix don't affect old agents
# Simply continue using agents/agent_base.py
```

### Complete Rollback

```bash
# Git revert
git revert <commit-hash>

# Or restore from backup
git checkout HEAD~1 -- core/config.py
git checkout HEAD~1 -- requirements.txt
git checkout HEAD~1 -- agents/
```

## Common Issues & Solutions

### Issue 1: Import Errors

**Problem:**
```python
ModuleNotFoundError: No module named 'core.config'
```

**Solution:**
```bash
# Ensure core/ has __init__.py
touch core/__init__.py

# Or use absolute imports
from core.config import get_settings
```

### Issue 2: Missing Environment Variables

**Problem:**
```python
ValidationError: SECRET_KEY is required
```

**Solution:**
```bash
# Check .env file exists
ls -la .env

# Copy from template if missing
cp .env.example.unified .env

# Set required values
export SECRET_KEY="your-secret-key-here"
```

### Issue 3: Package Version Conflicts

**Problem:**
```
ERROR: Package has conflicting dependencies
```

**Solution:**
```bash
# Clear cache and reinstall
pip cache purge
pip install -r requirements.unified.txt --force-reinstall
```

### Issue 4: Agent Registration Fails

**Problem:**
```python
AttributeError: 'MyAgent' object has no attribute 'capabilities'
```

**Solution:**
```python
# Ensure AgentConfig includes capabilities
config = AgentConfig(
    name="MyAgent",
    capabilities=[...]  # Don't forget this!
)
```

## Best Practices

### DO:
- ✅ Test in development first
- ✅ Migrate one module at a time
- ✅ Keep old files during transition
- ✅ Update documentation as you go
- ✅ Monitor logs for errors
- ✅ Use version control

### DON'T:
- ❌ Migrate everything at once in production
- ❌ Delete old files immediately
- ❌ Skip testing
- ❌ Ignore warnings
- ❌ Mix old and new patterns in same file

## Migration Checklist

### Pre-Migration
- [ ] Read PHASE3_COMPLETION_REPORT.md
- [ ] Review this migration guide
- [ ] Backup current state
- [ ] Set up test environment
- [ ] Identify all modules to migrate

### Configuration Migration
- [ ] Copy .env.example.unified to .env
- [ ] Set all environment variables
- [ ] Update configuration imports
- [ ] Test configuration access
- [ ] Update CI/CD pipelines

### Requirements Migration
- [ ] Review requirements.unified.txt
- [ ] Test in development environment
- [ ] Update CI/CD requirements
- [ ] Deploy to staging
- [ ] Deploy to production

### Agent Base Migration
- [ ] Identify all agents to migrate
- [ ] Update one agent as pilot
- [ ] Test pilot agent thoroughly
- [ ] Migrate remaining agents
- [ ] Update agent tests
- [ ] Register all agents

### Post-Migration
- [ ] Run all tests
- [ ] Monitor production logs
- [ ] Update documentation
- [ ] Train team members
- [ ] Remove old files (after validation period)
- [ ] Celebrate success! 🎉

## Support

For questions or issues:

1. Check `cleanup/PHASE3_COMPLETION_REPORT.md`
2. Review test script: `cleanup/07_test_unified_components.py`
3. Check existing examples in `agents/` directory
4. Contact development team

## Timeline Example

**Week 1: Preparation**
- Day 1-2: Read documentation
- Day 3-4: Set up test environment
- Day 5: Test unified components

**Week 2: Development Migration**
- Day 1-2: Migrate configuration
- Day 3-4: Migrate requirements
- Day 5: Migrate pilot agent

**Week 3: Extended Testing**
- Day 1-3: Full integration testing
- Day 4-5: Performance testing

**Week 4: Staging Deployment**
- Day 1-2: Deploy to staging
- Day 3-5: Staging validation

**Week 5: Production Migration**
- Day 1: Production deployment
- Day 2-5: Monitoring & support

**Week 6: Cleanup**
- Day 1-3: Remove old files
- Day 4-5: Update final documentation

---

*Phase 3: Unification & Standardization Migration Guide*
*Version 1.0 - 2025-10-21*
