#!/usr/bin/env python3
"""
Test Unified Components
Verify that unified components work correctly and don't conflict with existing modules
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_unified_config():
    """Test unified configuration."""
    print("=" * 80)
    print("Testing Unified Configuration")
    print("=" * 80)

    try:
        # Note: This will fail without pydantic installed, but validates syntax
        with open("core/config.py", "r") as f:
            config_code = f.read()

        # Check that all required classes are present
        required_classes = [
            "DatabaseSettings",
            "RedisSettings",
            "APISettings",
            "SecuritySettings",
            "AISettings",
            "LoggingSettings",
            "AgentSettings",
            "PerformanceSettings",
            "Settings",
        ]

        for cls in required_classes:
            if f"class {cls}" in config_code:
                print(f"   ✅ {cls} found")
            else:
                print(f"   ❌ {cls} missing")
                return False

        # Check for required functions
        if "def get_settings" in config_code:
            print("   ✅ get_settings() found")
        else:
            print("   ❌ get_settings() missing")
            return False

        if "def reload_settings" in config_code:
            print("   ✅ reload_settings() found")
        else:
            print("   ❌ reload_settings() missing")
            return False

        print("\n✅ Unified configuration is valid")
        return True

    except Exception as e:
        print(f"\n❌ Error testing configuration: {e}")
        return False


def test_unified_requirements():
    """Test unified requirements."""
    print("\n" + "=" * 80)
    print("Testing Unified Requirements")
    print("=" * 80)

    try:
        with open("requirements.unified.txt", "r") as f:
            lines = f.readlines()

        # Count packages
        packages = [
            line.strip() for line in lines if line.strip() and not line.strip().startswith("#")
        ]
        print(f"   Total packages: {len(packages)}")

        # Check for critical packages
        critical_packages = [
            "fastapi",
            "uvicorn",
            "pydantic",
            "sqlalchemy",
            "asyncpg",
            "redis",
            "pytest",
        ]

        content = " ".join(lines)
        for pkg in critical_packages:
            if pkg in content.lower():
                print(f"   ✅ {pkg} found")
            else:
                print(f"   ⚠️  {pkg} not found")

        print("\n✅ Unified requirements is valid")
        return True

    except Exception as e:
        print(f"\n❌ Error testing requirements: {e}")
        return False


def test_unified_agents():
    """Test unified agent base."""
    print("\n" + "=" * 80)
    print("Testing Unified Agent Base")
    print("=" * 80)

    try:
        # Check agent_base_unified.py
        with open("agents/agent_base_unified.py", "r") as f:
            agent_code = f.read()

        required_classes = [
            "Priority",
            "TaskStatus",
            "TaskRequest",
            "TaskResponse",
            "AgentCapability",
            "AgentConfig",
            "BaseAgent",
        ]

        for cls in required_classes:
            if f"class {cls}" in agent_code or f"{cls} = " in agent_code:
                print(f"   ✅ {cls} found")
            else:
                print(f"   ❌ {cls} missing")
                return False

        # Check for required methods in BaseAgent
        required_methods = [
            "process_task",
            "health_check",
            "get_info",
            "reset_stats",
            "_validate_task",
            "_execute_task",
        ]

        for method in required_methods:
            if f"def {method}" in agent_code:
                print(f"   ✅ {method}() found")
            else:
                print(f"   ❌ {method}() missing")
                return False

        # Check shared_utils_unified.py
        with open("agents/shared_utils_unified.py", "r") as f:
            utils_code = f.read()

        required_utils = [
            "load_config",
            "save_config",
            "get_env_var",
            "validate_payload",
            "DataCache",
        ]

        for util in required_utils:
            if f"def {util}" in utils_code or f"class {util}" in utils_code:
                print(f"   ✅ {util} found in shared_utils")
            else:
                print(f"   ❌ {util} missing from shared_utils")
                return False

        # Check agent_registry_unified.py
        with open("agents/agent_registry_unified.py", "r") as f:
            registry_code = f.read()

        if "class AgentRegistry" in registry_code:
            print("   ✅ AgentRegistry found")
        else:
            print("   ❌ AgentRegistry missing")
            return False

        print("\n✅ Unified agent base is valid")
        return True

    except Exception as e:
        print(f"\n❌ Error testing agent base: {e}")
        return False


def test_no_conflicts():
    """Test that unified components don't conflict with existing modules."""
    print("\n" + "=" * 80)
    print("Testing for Conflicts")
    print("=" * 80)

    try:
        # Check that existing files are not overwritten
        existing_files = [
            "config.py",
            "settings.py",
            "agents/agent_base.py",
            "agents/shared_utils.py",
            "requirements.txt",
        ]

        for file in existing_files:
            if Path(file).exists():
                print(f"   ✅ Original {file} preserved")
            else:
                print(f"   ⚠️  Original {file} not found (may have been in different location)")

        # Check that new files use _unified suffix
        unified_files = [
            "agents/agent_base_unified.py",
            "agents/shared_utils_unified.py",
            "agents/agent_registry_unified.py",
            "agents/__init___unified.py",
        ]

        for file in unified_files:
            if Path(file).exists():
                print(f"   ✅ Unified {file} created")
            else:
                print(f"   ❌ Unified {file} missing")
                return False

        print("\n✅ No conflicts detected")
        return True

    except Exception as e:
        print(f"\n❌ Error checking conflicts: {e}")
        return False


def main():
    """Run all tests."""
    print("\n" + "=" * 80)
    print("UNIFIED COMPONENTS VERIFICATION")
    print("=" * 80)

    results = {
        "Configuration": test_unified_config(),
        "Requirements": test_unified_requirements(),
        "Agent Base": test_unified_agents(),
        "No Conflicts": test_no_conflicts(),
    }

    print("\n" + "=" * 80)
    print("VERIFICATION SUMMARY")
    print("=" * 80)

    for component, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{component:.<40} {status}")

    all_passed = all(results.values())

    print("\n" + "=" * 80)
    if all_passed:
        print("✅ ALL TESTS PASSED - Unified components are ready!")
    else:
        print("❌ SOME TESTS FAILED - Review issues above")
    print("=" * 80)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
