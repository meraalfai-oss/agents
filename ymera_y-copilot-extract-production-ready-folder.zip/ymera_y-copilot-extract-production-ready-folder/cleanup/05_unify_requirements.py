#!/usr/bin/env python3
"""
Requirements Unification
Consolidates all requirements files into single requirements.txt
"""

import re
from pathlib import Path
from typing import Dict


class RequirementsUnifier:
    def __init__(self, root_path: Path):
        self.root = root_path
        self.requirements_files = []
        self.all_packages = {}

    def unify(self):
        """Unify all requirements files."""
        print("=" * 80)
        print("REQUIREMENTS UNIFICATION")
        print("=" * 80)

        # Step 1: Find all requirements files
        print("\n1. Finding requirements files...")
        self._find_requirements()

        # Step 2: Parse all files
        print("\n2. Parsing requirements...")
        self._parse_requirements()

        # Step 3: Resolve conflicts
        print("\n3. Resolving version conflicts...")
        unified = self._resolve_conflicts()

        # Step 4: Create unified file
        print("\n4. Creating unified requirements.txt...")
        self._create_unified(unified)

        print("\n" + "=" * 80)
        print("✅ Requirements Unified!")
        print("=" * 80)

    def _find_requirements(self):
        """Find all requirements files."""
        patterns = ["requirements*.txt", "requirements*.in"]

        for pattern in patterns:
            for req_file in self.root.glob(pattern):
                if "venv" not in str(req_file) and ".git" not in str(req_file):
                    self.requirements_files.append(req_file)
                    print(f"   Found: {req_file.relative_to(self.root)}")

        print(f"\n   Total: {len(self.requirements_files)} requirements files")

    def _parse_requirements(self):
        """Parse all requirements files."""
        for req_file in self.requirements_files:
            try:
                with open(req_file, "r") as f:
                    for line in f:
                        line = line.strip()

                        # Skip comments and empty lines
                        if not line or line.startswith("#"):
                            continue

                        # Parse package and version
                        match = re.match(r"([a-zA-Z0-9\-_.]+)([>=<~!]+)?(.+)?", line)
                        if match:
                            package = match.group(1).lower()
                            operator = match.group(2) or "=="
                            version = match.group(3) or ""

                            if package not in self.all_packages:
                                self.all_packages[package] = []

                            self.all_packages[package].append(
                                {
                                    "file": req_file.name,
                                    "operator": operator,
                                    "version": version.strip(),
                                    "original": line,
                                }
                            )
            except Exception as e:
                print(f"   ⚠️  Failed to parse {req_file.name}: {e}")

        print(f"   Found {len(self.all_packages)} unique packages")

    def _resolve_conflicts(self) -> Dict[str, str]:
        """Resolve version conflicts."""
        unified = {}
        conflicts = []

        for package, versions in self.all_packages.items():
            if len(versions) == 1:
                # No conflict
                unified[package] = versions[0]["original"]
            else:
                # Multiple versions - choose the highest/most recent
                print(f"\n   Conflict: {package}")
                for v in versions:
                    print(f"      - {v['file']}: {v['original']}")

                # Simple resolution: choose newest version
                best = self._choose_best_version(versions)
                unified[package] = best["original"]
                print(f"      ✅ Resolved: {best['original']}")

                conflicts.append({"package": package, "versions": versions, "chosen": best})

        if conflicts:
            print(f"\n   Resolved {len(conflicts)} version conflicts")

        return unified

    def _choose_best_version(self, versions):
        """Choose the best version from multiple options."""
        # Prefer pinned versions (==)
        pinned = [v for v in versions if v["operator"] == "=="]
        if pinned:
            # Choose highest version number
            return max(pinned, key=lambda v: self._version_tuple(v["version"]))

        # Otherwise, choose >= with highest version
        gte = [v for v in versions if v["operator"] in [">=", ">"]]
        if gte:
            return max(gte, key=lambda v: self._version_tuple(v["version"]))

        # Fallback to first one
        return versions[0]

    def _version_tuple(self, version_str):
        """Convert version string to tuple for comparison."""
        try:
            return tuple(map(int, version_str.split(".")))
        except:
            return (0, 0, 0)

    def _create_unified(self, unified: Dict[str, str]):
        """Create unified requirements.txt."""
        req_path = self.root / "requirements.unified.txt"

        # Backup existing if it exists
        if (self.root / "requirements.txt").exists():
            backup_path = self.root / "cleanup" / "backup" / "requirements.txt.backup"
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            import shutil

            shutil.copy2(self.root / "requirements.txt", backup_path)
            print(f"   Backed up existing: {backup_path.relative_to(self.root)}")

        # Write unified requirements
        with open(req_path, "w") as f:
            f.write("# YMERA Unified Requirements\n")
            f.write("# Generated by cleanup/05_unify_requirements.py\n")
            f.write(f"# {len(unified)} packages\n\n")

            # Group by category
            categories = {
                "Core": ["fastapi", "uvicorn", "pydantic", "sqlalchemy"],
                "AI/LLM": ["anthropic", "openai", "langchain", "transformers"],
                "Database": ["psycopg2", "redis", "pymongo", "asyncpg"],
                "Utilities": ["python-dotenv", "pyyaml", "requests"],
            }

            categorized = {cat: [] for cat in categories}
            categorized["Other"] = []

            for package, requirement in sorted(unified.items()):
                placed = False
                for category, keywords in categories.items():
                    if any(keyword in package for keyword in keywords):
                        categorized[category].append(requirement)
                        placed = True
                        break
                if not placed:
                    categorized["Other"].append(requirement)

            # Write by category
            for category, reqs in categorized.items():
                if reqs:
                    f.write(f"\n# {category}\n")
                    for req in sorted(reqs):
                        f.write(f"{req}\n")

        print(f"   Created: {req_path.relative_to(self.root)}")
        print(f"   Total packages: {len(unified)}")


if __name__ == "__main__":
    unifier = RequirementsUnifier(Path.cwd())
    unifier.unify()
