# Phase 2: Cleanup & Consolidation - Quick Start Guide

This guide will walk you through using the Phase 2 cleanup and consolidation scripts.

## Prerequisites

1. Python 3.11+ installed
2. Repository cloned locally
3. Phase 1 analysis completed (or run it first)

## Step-by-Step Workflow

### 1. Run Analysis (Phase 1)

First, analyze the repository to identify duplicates and versions:

```bash
cd /home/runner/work/ymera_y/ymera_y
python3 cleanup/01_analyze_repository.py
```

**Expected Output:**
```
================================================================================
YMERA REPOSITORY ANALYSIS
================================================================================

1. Cataloging all files...
   Found 429 Python files
   ...

✅ Analysis Complete!
```

**Generated Files:**
- `cleanup/01_analysis_report.json` - Machine-readable data
- `cleanup/01_ANALYSIS_REPORT.md` - Human-readable report

### 2. Review Analysis Report

Open and review the analysis report:

```bash
cat cleanup/01_ANALYSIS_REPORT.md
# Or open in your editor
```

Look for:
- How many duplicate files exist
- How many files have multiple versions
- Recommendations for cleanup

### 3. Run Automated Cleanup (Phase 2a)

Remove duplicates and old versions automatically:

```bash
python3 cleanup/02_automated_cleanup.py
```

**Interactive Prompt:**
```
================================================================================
AUTOMATED CLEANUP
================================================================================

⚠️  This will:
   - Remove duplicate files
   - Remove old versions
   - Backup all removed files

Proceed? (yes/no):
```

Type `yes` and press Enter to proceed.

**What Happens:**
1. Duplicate files are identified
2. Old versions are identified
3. For each group, the best file is kept
4. Other files are backed up to `cleanup/backup/`
5. Other files are removed from the repository
6. A log is saved to `cleanup/02_cleanup_log.json`

**Generated Files:**
- `cleanup/backup/` - All removed files (for safety)
- `cleanup/02_cleanup_log.json` - Detailed removal log

### 4. Run Version Consolidation (Phase 2b)

Analyze remaining versions and get consolidation recommendations:

```bash
python3 cleanup/03_version_consolidation.py
```

**Output:**
```
================================================================================
VERSION CONSOLIDATION
================================================================================

1. Scanning for remaining versions...
   Found 21 files with versions

2. Consolidating versions...
   ...

✅ Consolidation Complete!
```

**Generated Files:**
- `cleanup/03_consolidation_log.json` - Machine-readable consolidation data
- `cleanup/03_CONSOLIDATION_REPORT.md` - Human-readable recommendations

### 5. Review Consolidation Report

Open the consolidation report:

```bash
cat cleanup/03_CONSOLIDATION_REPORT.md
# Or open in your editor
```

For each file group, you'll see:
- **Best Version** - Recommended file to keep
- **Other Versions** - Files that can be removed
- **Unique Features** - Functions/classes unique to each version
- **Recommendation** - Action items

### 6. Manual Review and Merge

For files with unique features:

1. Open the best version and other versions side-by-side
2. Review unique functions/classes in other versions
3. If needed, copy unique features to the best version
4. Update any imports pointing to old versions
5. Test that everything still works
6. Remove the old versions manually

### 7. Verify Changes

After cleanup, verify everything works:

```bash
# Run tests (if available)
python3 -m pytest

# Or verify imports
python3 -c "import core.config; print('✅ Imports OK')"

# Check for broken imports
grep -r "from old_file import" . --include="*.py"
```

## Recovery and Rollback

### Restore a Backed Up File

If you need to restore a file that was removed:

```bash
# Find the file in backup
ls cleanup/backup/path/to/file.py

# Copy it back
cp cleanup/backup/path/to/file.py path/to/file.py
```

### View Removal Log

To see what was removed and why:

```bash
cat cleanup/02_cleanup_log.json | python3 -m json.tool
```

### View Consolidation Analysis

To see version analysis details:

```bash
cat cleanup/03_consolidation_log.json | python3 -m json.tool
```

## Common Issues and Solutions

### Issue: "Analysis report not found"

**Solution:** Run Phase 1 analysis first:
```bash
python3 cleanup/01_analyze_repository.py
```

### Issue: Script removes a file I wanted to keep

**Solution:** Restore from backup:
```bash
cp cleanup/backup/path/to/file.py path/to/file.py
```

### Issue: Imports are broken after cleanup

**Solution:** 
1. Check `02_cleanup_log.json` to see what was removed
2. Find files importing the removed file
3. Update imports to use the kept version
4. Or restore the removed file from backup

### Issue: Want to see what will be removed without removing

**Solution:** Run analysis and review reports:
```bash
python3 cleanup/01_analyze_repository.py
cat cleanup/01_ANALYSIS_REPORT.md
```

The automated cleanup script requires explicit "yes" confirmation.

## Best Practices

1. **Always run analysis first** - Understand what will be cleaned up
2. **Review reports** - Check recommendations before running cleanup
3. **Commit before cleanup** - Ensure you can revert via git if needed
4. **Run tests after** - Verify nothing broke
5. **Keep backups** - Don't delete the `cleanup/backup/` directory immediately
6. **Review unique features** - Before removing versions with unique code

## Command Reference

```bash
# Phase 1: Analysis
python3 cleanup/01_analyze_repository.py

# Phase 2a: Automated Cleanup
python3 cleanup/02_automated_cleanup.py

# Phase 2b: Version Consolidation
python3 cleanup/03_version_consolidation.py

# View reports
cat cleanup/01_ANALYSIS_REPORT.md
cat cleanup/03_CONSOLIDATION_REPORT.md

# View logs
cat cleanup/02_cleanup_log.json | python3 -m json.tool
cat cleanup/03_consolidation_log.json | python3 -m json.tool

# Check backup directory
ls -R cleanup/backup/
```

## Next Steps

After Phase 2 completion:

1. **Verify** - Run tests to ensure nothing broke
2. **Commit** - Commit the cleaned up repository
3. **Document** - Update any documentation referencing removed files
4. **Monitor** - Watch for any issues in the next few commits

## Support

For issues or questions:
1. Check the main README: `cleanup/README.md`
2. Review the logs in `cleanup/` directory
3. Open an issue in the repository with:
   - The script you were running
   - The error message
   - Relevant log files
