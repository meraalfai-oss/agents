#!/usr/bin/env python3
"""
Version Consolidation Script
Helps consolidate files with multiple versions
"""

import json
from datetime import datetime
from pathlib import Path

# Version consolidation recommendations from analysis
VERSION_CONSOLIDATION_PLAN = {
    "metrics.py": {
        "keep": "core/metrics.py",  # 399 lines - most complete
        "remove": [
            "metrics.py",  # 123 lines
            # Other locations to be identified
        ],
        "priority": "HIGH",
        "reason": "Critical for monitoring",
    },
    "editing_agent": {
        "keep": "editing_agent_v2 (1).py",  # 1367 lines - most complete
        "remove": [
            "editing_agent.py",  # 913 lines
            "editing_agent_testing (1).py",  # 680 lines
        ],
        "priority": "HIGH",
        "reason": "V2 most feature-complete",
    },
    "enhancement_agent": {
        "keep": "enhancement_agent_v3.py",  # 2159 lines - most complete
        "remove": [
            "enhancement_agent.py",  # 908 lines
        ],
        "priority": "HIGH",
        "reason": "V3 significantly more complete",
    },
    "encryption.py": {
        "keep": None,  # Manual review needed - security critical
        "remove": [],
        "priority": "HIGH",
        "reason": "Security critical - needs manual audit",
    },
    "connection_pool.py": {
        "keep": None,  # Largest version, needs verification
        "remove": [],
        "priority": "MEDIUM",
        "reason": "Verify production readiness",
    },
}


def generate_consolidation_report():
    """Generate detailed consolidation report"""
    report_path = Path("cleanup/VERSION_CONSOLIDATION_PLAN.json")

    report = {
        "timestamp": datetime.now().isoformat(),
        "total_consolidations": len(VERSION_CONSOLIDATION_PLAN),
        "high_priority": sum(
            1 for v in VERSION_CONSOLIDATION_PLAN.values() if v["priority"] == "HIGH"
        ),
        "plans": VERSION_CONSOLIDATION_PLAN,
    }

    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"✅ Consolidation plan saved: {report_path}")


def print_consolidation_summary():
    """Print consolidation summary"""
    print("=" * 80)
    print("VERSION CONSOLIDATION SUMMARY")
    print("=" * 80)

    for file_base, plan in VERSION_CONSOLIDATION_PLAN.items():
        print(f"\n📄 {file_base}")
        print(f"   Priority: {plan['priority']}")
        print(f"   Reason: {plan['reason']}")

        if plan["keep"]:
            print(f"   ✅ Keep: {plan['keep']}")
        else:
            print(f"   ⚠️  MANUAL REVIEW NEEDED")

        if plan["remove"]:
            print(f"   🗑️  Remove: {len(plan['remove'])} file(s)")
            for remove_file in plan["remove"]:
                print(f"      - {remove_file}")
        else:
            print(f"   ⚠️  Remove list needs to be determined")


def main():
    print_consolidation_summary()
    print("\n")
    generate_consolidation_report()

    print("\n" + "=" * 80)
    print("NEXT STEPS:")
    print("=" * 80)
    print("\nHIGH PRIORITY CONSOLIDATIONS:")
    print("1. metrics.py - Audit all 4 versions, keep most complete (399 lines)")
    print("2. editing_agent - Keep V2, remove others after testing")
    print("3. enhancement_agent - Keep V3, remove V1 after verification")
    print("4. encryption.py - CRITICAL: Manual security audit required")

    print("\nMANUAL ACTIONS REQUIRED:")
    print("1. Review each 'keep' file for completeness")
    print("2. Test functionality before removing old versions")
    print("3. Update any imports pointing to old versions")
    print("4. For encryption.py: Full security audit before consolidation")

    print("\nAutomation available:")
    print("   Implement actual file operations after manual review")


if __name__ == "__main__":
    main()
