#!/usr/bin/env python3
"""
Create Unified Base Agent
Consolidates all base agent patterns into single standard
"""

from pathlib import Path


class BaseAgentCreator:
    def __init__(self, root_path: Path):
        self.root = root_path

    def create(self):
        """Create unified base agent."""
        print("=" * 80)
        print("CREATING UNIFIED BASE AGENT")
        print("=" * 80)

        # Create agents directory if not exists
        agents_dir = self.root / "agents"
        agents_dir.mkdir(exist_ok=True)

        # Create agent_base.py
        print("\n1. Creating agents/agent_base.py...")
        self._create_base_agent()

        # Create shared_utils.py
        print("\n2. Creating agents/shared_utils.py...")
        self._create_shared_utils()

        # Create agent_registry.py
        print("\n3. Creating agents/agent_registry.py...")
        self._create_registry()

        # Create __init__.py
        print("\n4. Creating agents/__init__.py...")
        self._create_init()

        print("\n" + "=" * 80)
        print("✅ Base Agent Created!")
        print("=" * 80)

    def _create_base_agent(self):
        """Create base agent file."""
        content = '''"""
YMERA Base Agent
Standard base class for all agents
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
import logging
import uuid
import json

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


class Priority(Enum):
    """Task priority levels."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class TaskStatus(Enum):
    """Task execution status."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"


@dataclass
class TaskRequest:
    """Standardized task request format."""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_type: str = ""
    priority: Priority = Priority.MEDIUM
    payload: Dict[str, Any] = field(default_factory=dict)
    timeout: int = 300  # seconds
    created_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'task_id': self.task_id,
            'task_type': self.task_type,
            'priority': self.priority.name,
            'payload': self.payload,
            'timeout': self.timeout,
            'created_at': self.created_at.isoformat(),
            'metadata': self.metadata
        }


@dataclass
class TaskResponse:
    """Standardized task response format."""
    task_id: str
    status: TaskStatus
    result: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'task_id': self.task_id,
            'status': self.status.value,
            'result': self.result,
            'error': self.error,
            'execution_time': self.execution_time,
            'completed_at': self.completed_at.isoformat(),
            'metadata': self.metadata
        }


class AgentCapability:
    """Agent capability descriptor."""

    def __init__(
        self,
        name: str,
        description: str,
        task_types: List[str],
        required_params: List[str] = None
    ):
        self.name = name
        self.description = description
        self.task_types = task_types
        self.required_params = required_params or []

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'description': self.description,
            'task_types': self.task_types,
            'required_params': self.required_params
        }


@dataclass
class AgentConfig:
    """Agent configuration."""
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "UnnamedAgent"
    description: str = ""
    capabilities: List[AgentCapability] = field(default_factory=list)
    max_concurrent_tasks: int = 10
    task_timeout: int = 300
    retry_attempts: int = 3
    log_level: str = "INFO"


class BaseAgent:
    """Base Agent class - all agents inherit from this."""

    def __init__(self, config: AgentConfig = None):
        self.config = config or AgentConfig()
        self.agent_id = self.config.agent_id
        self.name = self.config.name
        self.capabilities = self.config.capabilities

        # Setup logging
        self.logger = logging.getLogger(f"Agent.{self.name}")
        self.logger.setLevel(getattr(logging, self.config.log_level))

        # Statistics
        self.stats = {
            'tasks_processed': 0,
            'tasks_succeeded': 0,
            'tasks_failed': 0,
            'total_execution_time': 0.0
        }

        self.logger.info(f"Agent initialized: {self.name} ({self.agent_id})")

    def process_task(self, task: TaskRequest) -> TaskResponse:
        """Process a task request."""
        start_time = datetime.now()
        self.logger.info(f"Processing task {task.task_id} of type {task.task_type}")

        try:
            self._validate_task(task)
            result = self._execute_task(task)
            execution_time = (datetime.now() - start_time).total_seconds()

            self.stats['tasks_processed'] += 1
            self.stats['tasks_succeeded'] += 1
            self.stats['total_execution_time'] += execution_time

            self.logger.info(f"Task {task.task_id} completed in {execution_time:.2f}s")

            return TaskResponse(
                task_id=task.task_id,
                status=TaskStatus.SUCCESS,
                result=result,
                execution_time=execution_time
            )
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self.stats['tasks_processed'] += 1
            self.stats['tasks_failed'] += 1

            self.logger.error(f"Task {task.task_id} failed: {str(e)}")

            return TaskResponse(
                task_id=task.task_id,
                status=TaskStatus.ERROR,
                error=str(e),
                execution_time=execution_time
            )

    def _validate_task(self, task: TaskRequest):
        """Validate task request."""
        if not task.task_type:
            raise ValueError("Task type is required")

        if task.task_type not in self.get_supported_task_types():
            raise ValueError(
                f"Unsupported task type: {task.task_type}. "
                f"Supported types: {self.get_supported_task_types()}"
            )

    def _execute_task(self, task: TaskRequest) -> Any:
        """Execute the task. Override in subclasses."""
        raise NotImplementedError("Subclasses must implement _execute_task")

    def get_supported_task_types(self) -> List[str]:
        """Get list of supported task types."""
        task_types = []
        for cap in self.capabilities:
            task_types.extend(cap.task_types)
        return task_types

    def health_check(self) -> Dict[str, Any]:
        """Check agent health."""
        return {
            'agent_id': self.agent_id,
            'name': self.name,
            'status': 'healthy',
            'capabilities': [cap.name for cap in self.capabilities],
            'supported_task_types': self.get_supported_task_types(),
            'statistics': self.stats.copy(),
            'timestamp': datetime.now().isoformat()
        }

    def get_info(self) -> Dict[str, Any]:
        """Get agent information."""
        return {
            'agent_id': self.agent_id,
            'name': self.name,
            'description': self.config.description,
            'capabilities': [cap.to_dict() for cap in self.capabilities],
            'config': {
                'max_concurrent_tasks': self.config.max_concurrent_tasks,
                'task_timeout': self.config.task_timeout,
                'retry_attempts': self.config.retry_attempts
            }
        }

    def reset_stats(self):
        """Reset statistics."""
        self.stats = {
            'tasks_processed': 0,
            'tasks_succeeded': 0,
            'tasks_failed': 0,
            'total_execution_time': 0.0
        }
        self.logger.info("Statistics reset")


__all__ = [
    'BaseAgent',
    'AgentConfig',
    'AgentCapability',
    'TaskRequest',
    'TaskResponse',
    'Priority',
    'TaskStatus'
]
'''

        path = self.root / "agents" / "agent_base_unified.py"
        with open(path, "w") as f:
            f.write(content)
        print(f"   ✅ Created: {path.relative_to(self.root)}")

    def _create_shared_utils(self):
        """Create shared utilities."""
        content = '''"""
Shared Agent Utilities
Common utility functions for all agents
"""

import os
import json
from typing import Any, Dict, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


def load_config(config_path: str) -> Dict[str, Any]:
    """Load configuration from JSON file."""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load config from {config_path}: {e}")
        return {}


def save_config(config: Dict[str, Any], config_path: str):
    """Save configuration to JSON file."""
    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save config to {config_path}: {e}")


def get_env_var(key: str, default: Any = None) -> Any:
    """Get environment variable with default."""
    return os.getenv(key, default)


def validate_payload(
    payload: Dict[str, Any],
    required_keys: list
) -> tuple[bool, Optional[str]]:
    """Validate payload has required keys."""
    missing = [key for key in required_keys if key not in payload]
    if missing:
        return False, f"Missing required keys: {missing}"
    return True, None


class DataCache:
    """Simple in-memory cache for agents."""

    def __init__(self):
        self._cache: Dict[str, Any] = {}

    def get(self, key: str, default: Any = None) -> Any:
        return self._cache.get(key, default)

    def set(self, key: str, value: Any):
        self._cache[key] = value

    def delete(self, key: str):
        if key in self._cache:
            del self._cache[key]

    def clear(self):
        self._cache.clear()

    def keys(self) -> list:
        return list(self._cache.keys())


__all__ = [
    'load_config',
    'save_config',
    'get_env_var',
    'validate_payload',
    'DataCache'
]
'''

        path = self.root / "agents" / "shared_utils_unified.py"
        with open(path, "w") as f:
            f.write(content)
        print(f"   ✅ Created: {path.relative_to(self.root)}")

    def _create_registry(self):
        """Create agent registry."""
        content = '''"""
Agent Registry
Manages all agent instances
"""

from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Registry to track and manage agent instances."""

    def __init__(self):
        self._agents: Dict[str, Any] = {}

    def register(self, agent):
        """Register an agent."""
        if agent.agent_id in self._agents:
            logger.warning(f"Agent {agent.agent_id} already registered, overwriting")

        self._agents[agent.agent_id] = agent
        logger.info(f"Registered agent: {agent.name} ({agent.agent_id})")

    def unregister(self, agent_id: str) -> bool:
        """Unregister an agent."""
        if agent_id in self._agents:
            agent = self._agents.pop(agent_id)
            logger.info(f"Unregistered agent: {agent.name} ({agent_id})")
            return True
        return False

    def get(self, agent_id: str):
        """Get agent by ID."""
        return self._agents.get(agent_id)

    def get_by_name(self, name: str):
        """Get agent by name."""
        for agent in self._agents.values():
            if agent.name == name:
                return agent
        return None

    def list_all(self) -> List:
        """List all registered agents."""
        return list(self._agents.values())

    def list_by_capability(self, capability_name: str) -> List:
        """List agents with specific capability."""
        result = []
        for agent in self._agents.values():
            for cap in agent.capabilities:
                if cap.name == capability_name:
                    result.append(agent)
                    break
        return result

    def health_check_all(self) -> Dict[str, Dict]:
        """Run health check on all agents."""
        results = {}
        for agent_id, agent in self._agents.items():
            try:
                results[agent_id] = agent.health_check()
            except Exception as e:
                results[agent_id] = {
                    'status': 'unhealthy',
                    'error': str(e)
                }
        return results

    def clear(self):
        """Clear all agents from registry."""
        self._agents.clear()
        logger.info("Agent registry cleared")


# Global registry instance
_global_registry = AgentRegistry()


def get_registry() -> AgentRegistry:
    """Get global registry instance."""
    return _global_registry


__all__ = ['AgentRegistry', 'get_registry']
'''

        path = self.root / "agents" / "agent_registry_unified.py"
        with open(path, "w") as f:
            f.write(content)
        print(f"   ✅ Created: {path.relative_to(self.root)}")

    def _create_init(self):
        """Create __init__.py for agents package."""
        content = '''"""
YMERA Unified Agent System
"""

from .agent_base_unified import (
    BaseAgent,
    AgentConfig,
    AgentCapability,
    TaskRequest,
    TaskResponse,
    Priority,
    TaskStatus
)
from .shared_utils_unified import (
    load_config,
    save_config,
    get_env_var,
    validate_payload,
    DataCache
)
from .agent_registry_unified import AgentRegistry, get_registry

__all__ = [
    'BaseAgent',
    'AgentConfig',
    'AgentCapability',
    'TaskRequest',
    'TaskResponse',
    'Priority',
    'TaskStatus',
    'load_config',
    'save_config',
    'get_env_var',
    'validate_payload',
    'DataCache',
    'AgentRegistry',
    'get_registry'
]
'''

        path = self.root / "agents" / "__init___unified.py"
        with open(path, "w") as f:
            f.write(content)
        print(f"   ✅ Created: {path.relative_to(self.root)}")


if __name__ == "__main__":
    creator = BaseAgentCreator(Path.cwd())
    creator.create()
