#!/usr/bin/env python3
"""
Duplicate Files Removal Script
Safely removes duplicate files identified by the analysis
"""

import shutil
from datetime import datetime
from pathlib import Path

# Duplicates to remove (keeping the better-named version)
DUPLICATES_TO_REMOVE = [
    # Group 1: Extensions
    "extensions.py",  # Keep api_extensions.py
    # Group 2: Gateway
    "gateway.py",  # Keep api.gateway.py
    # Group 3: Migrations
    "deployment_package/migrations/versions/001_add_indexes.py",  # Keep migrations/versions/001_add_indexes.py
    # Group 4: Empty init files (need manual review)
    # 'shared/utils/helpers.py',  # Commented out - needs review
]


def backup_file(file_path: Path):
    """Create backup of file before deletion"""
    backup_dir = Path("cleanup/backups")
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"{file_path.name}.{timestamp}.backup"
    backup_path = backup_dir / backup_name

    shutil.copy2(file_path, backup_path)
    print(f"   📦 Backed up to: {backup_path}")


def remove_duplicate(file_path: str):
    """Remove a duplicate file with backup"""
    path = Path(file_path)

    if not path.exists():
        print(f"⚠️  File not found (already removed?): {file_path}")
        return False

    print(f"\n🗑️  Removing duplicate: {file_path}")

    # Create backup
    backup_file(path)

    # Remove file
    path.unlink()
    print(f"   ✅ Removed: {file_path}")

    return True


def main():
    print("=" * 80)
    print("DUPLICATE FILES REMOVAL SCRIPT")
    print("=" * 80)

    print(f"\nFiles to remove: {len(DUPLICATES_TO_REMOVE)}")
    print("\nStarting removal process...\n")

    removed_count = 0
    for file_path in DUPLICATES_TO_REMOVE:
        if remove_duplicate(file_path):
            removed_count += 1

    print("\n" + "=" * 80)
    print(f"✅ Removal complete!")
    print(f"   Files removed: {removed_count}/{len(DUPLICATES_TO_REMOVE)}")
    print(f"   Backups saved in: cleanup/backups/")
    print("=" * 80)

    print("\n📋 Next steps:")
    print("   1. Run tests to verify nothing broke")
    print("   2. Check if any imports need updating")
    print("   3. Review cleanup/backups/ if rollback needed")


if __name__ == "__main__":
    main()
