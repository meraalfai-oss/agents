#!/usr/bin/env python3
"""
Quick Fix Script for Remaining Integration Issues
Addresses code_editor_agent_api.py indentation and class definition issues
"""

from pathlib import Path


def fix_code_editor_agent_api():
    """Fix indentation issues in code_editor_agent_api.py"""
    file_path = Path("code_editor_agent_api.py")

    if not file_path.exists():
        print(f"❌ File not found: {file_path}")
        return False

    with open(file_path, "r") as f:
        lines = f.readlines()

    fixed_lines = []
    i = 0
    fixes_applied = 0

    while i < len(lines):
        line = lines[i]

        # Check if this is a class definition
        if line.strip().startswith("class ") and line.strip().endswith(":"):
            fixed_lines.append(line)
            i += 1

            # Check if next line is a docstring that needs indentation
            if i < len(lines):
                next_line = lines[i]
                if (
                    next_line.strip().startswith('"""')
                    and len(next_line) - len(next_line.lstrip()) == 0
                ):
                    # Docstring needs indentation
                    fixed_lines.append("    " + next_line)
                    fixes_applied += 1
                    i += 1
                    continue

        fixed_lines.append(line)
        i += 1

    # Write fixed content
    with open(file_path, "w") as f:
        f.writelines(fixed_lines)

    print(f"✅ Fixed {fixes_applied} indentation issues in {file_path}")
    return True


def validate_syntax(file_path):
    """Validate Python syntax for a file"""
    import py_compile

    try:
        py_compile.compile(str(file_path), doraise=True)
        print(f"✅ {file_path}: Syntax OK")
        return True
    except py_compile.PyCompileError as e:
        print(f"❌ {file_path}: {e}")
        return False


if __name__ == "__main__":
    print("=" * 80)
    print("YMERA QUICK FIX SCRIPT")
    print("=" * 80)

    print("\n1. Fixing code_editor_agent_api.py...")
    fix_code_editor_agent_api()

    print("\n2. Validating fixed file...")
    validate_syntax(Path("code_editor_agent_api.py"))

    print("\n" + "=" * 80)
    print("✅ Quick fixes applied!")
    print("=" * 80)
