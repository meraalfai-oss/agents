#!/usr/bin/env python3
"""
Version Consolidation Script
Intelligently merges features from multiple versions
"""

import ast
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set


class VersionConsolidator:
    def __init__(self, root_path: Path):
        self.root = root_path
        self.consolidation_log = []

    def consolidate(self):
        """Consolidate all remaining versions."""
        print("=" * 80)
        print("VERSION CONSOLIDATION")
        print("=" * 80)

        # Re-analyze to find remaining versions
        print("\n1. Scanning for remaining versions...")
        versions = self._find_versions()

        if not versions:
            print("   ✅ No versions found to consolidate")
            return

        print(f"   Found {len(versions)} files with versions")

        # Consolidate each group
        print("\n2. Consolidating versions...")
        for base_name, files in versions.items():
            self._consolidate_group(base_name, files)

        # Save log
        print("\n3. Saving consolidation log...")
        self._save_log()

        print("\n" + "=" * 80)
        print("✅ Consolidation Complete!")
        print("=" * 80)

    def _find_versions(self) -> Dict[str, List[Path]]:
        """Find files with version indicators."""
        version_groups = {}

        for py_file in self.root.rglob("*.py"):
            if any(part.startswith('.') or part == 'venv' for part in py_file.parts):
                continue

            name = py_file.stem

            # Check for version indicators
            version_indicators = ['_v', '_old', '_new', '_backup', '_copy', '_2', '_final', '_temp']

            base_name = name
            for indicator in version_indicators:
                if indicator in name.lower():
                    base_name = name.lower().split(indicator)[0]
                    break

            if base_name not in version_groups:
                version_groups[base_name] = []

            version_groups[base_name].append(py_file)

        # Filter to only groups with multiple files
        return {name: files for name, files in version_groups.items() if len(files) > 1}

    def _consolidate_group(self, base_name: str, files: List[Path]):
        """Consolidate a group of versioned files."""
        print(f"\n   Consolidating: {base_name} ({len(files)} versions)")

        # Parse all versions
        versions_data = []
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    tree = ast.parse(content)

                # Extract metadata
                functions = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
                classes = [node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]

                versions_data.append({
                    'path': file_path,
                    'content': content,
                    'tree': tree,
                    'functions': set(functions),
                    'classes': set(classes),
                    'lines': len(content.split('\n'))
                })
            except Exception as e:
                print(f"      ⚠️  Failed to parse {file_path.name}: {e}")
                print(f"      ⚠️  Failed to parse {file_path.name}, skipping: {e}")
                continue

        if not versions_data:
            print(f"      ❌ No parseable versions")
            return

        # Find the most complete version
        best_version = max(versions_data, key=lambda v: (
            len(v['functions']) * 2 +  # Functions weighted higher
            len(v['classes']) * 3 +     # Classes weighted highest
            v['lines']                   # Lines as tiebreaker
            len(v['classes']) * 3,      # Classes weighted highest (primary)
            len(v['functions']) * 2,    # Functions weighted next
            v['lines']                  # Lines as tiebreaker
        ))

        print(f"      ✅ Best version: {best_version['path'].name}")
        print(f"         - {len(best_version['functions'])} functions")
        print(f"         - {len(best_version['classes'])} classes")
        print(f"         - {best_version['lines']} lines")

        # Identify unique features in other versions
        unique_features = {}
        for version in versions_data:
            if version['path'] == best_version['path']:
                continue

            unique_funcs = version['functions'] - best_version['functions']
            unique_classes = version['classes'] - best_version['classes']

            if unique_funcs or unique_classes:
                unique_features[version['path'].name] = {
                    'functions': list(unique_funcs),
                    'classes': list(unique_classes)
                }
                print(f"      📋 Unique in {version['path'].name}:")
                if unique_funcs:
                    print(f"         - Functions: {', '.join(unique_funcs)}")
                if unique_classes:
                    print(f"         - Classes: {', '.join(unique_classes)}")

        # Save consolidation info
        self.consolidation_log.append({
            'base_name': base_name,
            'best_version': str(best_version['path']),
            'other_versions': [str(v['path']) for v in versions_data if v['path'] != best_version['path']],
            'unique_features': unique_features,
            'recommendation': 'Review unique features and merge if needed'
        })

    def _save_log(self):
        """Save consolidation log."""
        log_path = self.root / 'cleanup' / '03_consolidation_log.json'

        with open(log_path, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'consolidations': self.consolidation_log
            }, f, indent=2)

        print(f"   Log saved: {log_path}")

        # Also create markdown report
        md_path = self.root / 'cleanup' / '03_CONSOLIDATION_REPORT.md'
        with open(md_path, 'w') as f:
            f.write(self._generate_markdown())

        print(f"   Report saved: {md_path}")

    def _generate_markdown(self) -> str:
        """Generate markdown report."""
        md = f"""# Version Consolidation Report

**Generated:** {datetime.now().isoformat()}

---
Generated: {datetime.now().isoformat()}

## Summary

Consolidated {len(self.consolidation_log)} file groups.

---

"""

        for i, item in enumerate(self.consolidation_log, 1):
            md += f"""
## {i}. {item['base_name']}

**Best Version:** `{item['best_version']}`

**Other Versions:**
"""
            for version in item['other_versions']:
                md += f"- `{version}`\n"
**Best Version:** {item['best_version']}

**Other Versions:**

"""
            for version in item['other_versions']:
                md += f"- {version}\n"

            if item['unique_features']:
                md += "\n**Unique Features Found:**\n\n"
                for version, features in item['unique_features'].items():
                    md += f"\n### {version}\n"
                    if features['functions']:
                        md += "\nFunctions:\n"
                        for func in features['functions']:
                            md += f"- `{func}()`\n"
                    if features['classes']:
                        md += "\nClasses:\n"
                        for cls in features['classes']:
                            md += f"- `{cls}`\n"

                md += f"\n**Recommendation:** {item['recommendation']}\n"

            md += "\n---\n"

        return md


if __name__ == "__main__":
    consolidator = VersionConsolidator(Path.cwd())
    consolidator.consolidate()
