# Unified Components Documentation

## Overview

This document provides comprehensive documentation for the unified components created in Phase 3: Unification & Standardization.

## Table of Contents

1. [Unified Configuration](#unified-configuration)
2. [Unified Requirements](#unified-requirements)
3. [Unified Agent Base](#unified-agent-base)
4. [API Reference](#api-reference)
5. [Examples](#examples)

## Unified Configuration

### Location
`core/config.py`

### Description
Single source of truth for all application configuration using Pydantic settings with environment variable support.

### Architecture

```
Settings (Main)
├── environment: str
├── debug: bool
├── database: DatabaseSettings
│   ├── url: str
│   ├── pool_size: int
│   ├── max_overflow: int
│   └── echo: bool
├── redis: RedisSettings
│   ├── url: str
│   ├── max_connections: int
│   └── socket_timeout: int
├── api: APISettings
│   ├── host: str
│   ├── port: int
│   ├── workers: int
│   ├── reload: bool
│   └── cors_origins: list
├── security: SecuritySettings
│   ├── secret_key: str
│   ├── algorithm: str
│   ├── access_token_expire_minutes: int
│   └── refresh_token_expire_days: int
├── ai: AISettings
│   ├── openai_api_key: Optional[str]
│   ├── anthropic_api_key: Optional[str]
│   ├── google_api_key: Optional[str]
│   ├── default_model: str
│   ├── max_tokens: int
│   └── temperature: float
├── logging: LoggingSettings
│   ├── level: str
│   ├── format: str
│   ├── file: Optional[str]
│   ├── max_bytes: int
│   └── backup_count: int
├── agents: AgentSettings
│   ├── max_concurrent: int
│   ├── task_timeout: int
│   ├── retry_attempts: int
│   └── registry_enabled: bool
└── performance: PerformanceSettings
    ├── enable_caching: bool
    ├── cache_ttl: int
    ├── rate_limit_enabled: bool
    ├── rate_limit_requests: int
    └── rate_limit_window: int
```

### Usage

#### Basic Usage

```python
from core.config import get_settings

# Get global settings instance
settings = get_settings()

# Access configuration
print(f"Database: {settings.database.url}")
print(f"API Port: {settings.api.port}")
print(f"Debug Mode: {settings.debug}")
```

#### Environment-Based Configuration

```python
# Settings automatically load from .env file
# or from environment variables

import os

# Set in environment
os.environ['DATABASE_URL'] = 'postgresql://localhost/mydb'
os.environ['API_PORT'] = '8080'

# Automatically picked up
settings = get_settings()
print(settings.database.url)  # postgresql://localhost/mydb
print(settings.api.port)  # 8080
```

#### Reload Settings

```python
from core.config import reload_settings

# Reload from environment (useful for testing)
settings = reload_settings()
```

#### Type Safety

```python
# Pydantic provides type hints and validation
settings = get_settings()

# IDE autocomplete works
settings.database.  # Shows: url, pool_size, max_overflow, echo

# Type checking works
port: int = settings.api.port  # OK
port: str = settings.api.port  # Type error caught by mypy
```

### Environment Variables

See `.env.example.unified` for complete list. Key variables:

```bash
# Core
ENVIRONMENT=development
DEBUG=false

# Database
DATABASE_URL=postgresql://localhost/ymera
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=10

# API
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4

# Security (REQUIRED)
SECRET_KEY=your-secret-key-here

# AI/LLM (Optional)
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
```

## Unified Requirements

### Location
`requirements.unified.txt`

### Description
Consolidated and conflict-resolved dependency list from all requirements files.

### Statistics
- **Total Packages:** 141
- **Sources Merged:** 5 files
- **Conflicts Resolved:** 61

### Categories

#### Core Framework
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.5.2
pydantic-settings==2.1.0
```

#### Database
```
asyncpg==0.29.0
sqlalchemy==2.0.23
alembic==1.13.0
psycopg2-binary==2.9.9
aiosqlite==0.19.0
```

#### AI/LLM
```
openai==1.3.5
anthropic==0.40.0
langchain==0.3.0
transformers==4.45.0
sentence-transformers==3.3.0
```

#### Caching
```
redis==5.0.1
```

#### Testing
```
pytest==7.4.3
pytest-asyncio==0.21.1
pytest-cov==4.1.0
pytest-mock==3.12.0
```

### Installation

```bash
# Standard installation
pip install -r requirements.unified.txt

# With upgrade
pip install -r requirements.unified.txt --upgrade

# In virtual environment
python -m venv venv
source venv/bin/activate
pip install -r requirements.unified.txt
```

## Unified Agent Base

### Location
- `agents/agent_base_unified.py` - Core base agent
- `agents/shared_utils_unified.py` - Shared utilities
- `agents/agent_registry_unified.py` - Agent registry
- `agents/__init___unified.py` - Package initialization

### Architecture

#### Core Classes

**BaseAgent**
- Standard base class for all agents
- Built-in task processing
- Health monitoring
- Statistics tracking

**TaskRequest**
- Standardized request format
- Priority levels
- Timeout support
- Metadata support

**TaskResponse**
- Standardized response format
- Status tracking
- Execution time
- Error handling

**AgentConfig**
- Agent configuration
- Capabilities definition
- Resource limits

**AgentCapability**
- Capability descriptor
- Task type mapping
- Required parameters

**AgentRegistry**
- Centralized agent management
- Health checking
- Agent discovery

### Usage

#### Creating an Agent

```python
from agents.agent_base_unified import (
    BaseAgent,
    AgentConfig,
    AgentCapability,
    TaskRequest,
    TaskResponse,
    TaskStatus
)

class MyAgent(BaseAgent):
    """Example agent implementation."""
    
    def __init__(self):
        # Define capabilities
        capabilities = [
            AgentCapability(
                name="data_processing",
                description="Process data files",
                task_types=["process_csv", "process_json"],
                required_params=["file_path"]
            )
        ]
        
        # Create configuration
        config = AgentConfig(
            name="MyAgent",
            description="Processes data files",
            capabilities=capabilities,
            max_concurrent_tasks=5,
            task_timeout=300,
            retry_attempts=3,
            log_level="INFO"
        )
        
        # Initialize base class
        super().__init__(config)
    
    def _execute_task(self, task: TaskRequest):
        """Execute task logic."""
        # Access task data
        file_path = task.payload.get('file_path')
        
        # Process task
        result = self._process_file(file_path)
        
        # Return result
        return {
            'status': 'completed',
            'processed_records': len(result)
        }
    
    def _process_file(self, file_path):
        """Custom processing logic."""
        # Your logic here
        pass
```

#### Using an Agent

```python
# Create agent instance
agent = MyAgent()

# Create task request
task = TaskRequest(
    task_type="process_csv",
    priority=Priority.HIGH,
    payload={
        'file_path': '/data/file.csv'
    },
    timeout=300
)

# Process task
response = agent.process_task(task)

# Check response
if response.status == TaskStatus.SUCCESS:
    print(f"Success: {response.result}")
    print(f"Time: {response.execution_time:.2f}s")
else:
    print(f"Error: {response.error}")
```

#### Health Checks

```python
# Check agent health
health = agent.health_check()
print(health)
# Output:
# {
#     'agent_id': '...',
#     'name': 'MyAgent',
#     'status': 'healthy',
#     'capabilities': ['data_processing'],
#     'supported_task_types': ['process_csv', 'process_json'],
#     'statistics': {
#         'tasks_processed': 42,
#         'tasks_succeeded': 40,
#         'tasks_failed': 2,
#         'total_execution_time': 125.5
#     },
#     'timestamp': '2025-10-21T12:00:00'
# }
```

#### Agent Registry

```python
from agents.agent_registry_unified import get_registry

# Get global registry
registry = get_registry()

# Register agents
agent1 = MyAgent()
agent2 = AnotherAgent()
registry.register(agent1)
registry.register(agent2)

# Find agents
found = registry.get_by_name("MyAgent")

# List all agents
all_agents = registry.list_all()

# Find by capability
processors = registry.list_by_capability("data_processing")

# Health check all
health_status = registry.health_check_all()
for agent_id, health in health_status.items():
    print(f"{health['name']}: {health['status']}")
```

#### Shared Utilities

```python
from agents.shared_utils_unified import (
    load_config,
    save_config,
    get_env_var,
    validate_payload,
    DataCache
)

# Load configuration
config = load_config("config.json")

# Environment variables
api_key = get_env_var("API_KEY", default="default-key")

# Validate payload
valid, error = validate_payload(
    payload={'name': 'test'},
    required_keys=['name', 'type']
)
if not valid:
    print(f"Validation error: {error}")

# Use cache
cache = DataCache()
cache.set("key", {"data": "value"})
value = cache.get("key")
```

## API Reference

### Settings Class

```python
class Settings(BaseSettings):
    """Main settings class."""
    
    environment: str  # development, staging, production
    debug: bool
    database: DatabaseSettings
    redis: RedisSettings
    api: APISettings
    security: SecuritySettings
    ai: AISettings
    logging: LoggingSettings
    agents: AgentSettings
    performance: PerformanceSettings
```

### Functions

```python
def get_settings() -> Settings:
    """Get global settings instance."""
    
def reload_settings() -> Settings:
    """Reload settings from environment."""
```

### BaseAgent Class

```python
class BaseAgent:
    """Base agent class."""
    
    def __init__(self, config: AgentConfig):
        """Initialize agent."""
    
    def process_task(self, task: TaskRequest) -> TaskResponse:
        """Process a task request."""
    
    def health_check(self) -> Dict[str, Any]:
        """Check agent health."""
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information."""
    
    def reset_stats(self):
        """Reset statistics."""
    
    def get_supported_task_types(self) -> List[str]:
        """Get supported task types."""
    
    def _validate_task(self, task: TaskRequest):
        """Validate task request."""
    
    def _execute_task(self, task: TaskRequest) -> Any:
        """Execute task (override in subclass)."""
```

### AgentRegistry Class

```python
class AgentRegistry:
    """Agent registry."""
    
    def register(self, agent: BaseAgent):
        """Register an agent."""
    
    def unregister(self, agent_id: str) -> bool:
        """Unregister an agent."""
    
    def get(self, agent_id: str) -> Optional[BaseAgent]:
        """Get agent by ID."""
    
    def get_by_name(self, name: str) -> Optional[BaseAgent]:
        """Get agent by name."""
    
    def list_all(self) -> List[BaseAgent]:
        """List all agents."""
    
    def list_by_capability(self, capability_name: str) -> List[BaseAgent]:
        """List agents with capability."""
    
    def health_check_all(self) -> Dict[str, Dict]:
        """Health check all agents."""
    
    def clear(self):
        """Clear registry."""
```

## Examples

### Example 1: Simple Agent

```python
from agents.agent_base_unified import *

class CalculatorAgent(BaseAgent):
    def __init__(self):
        config = AgentConfig(
            name="Calculator",
            description="Performs calculations",
            capabilities=[
                AgentCapability(
                    name="arithmetic",
                    description="Basic arithmetic",
                    task_types=["add", "subtract"],
                    required_params=["a", "b"]
                )
            ]
        )
        super().__init__(config)
    
    def _execute_task(self, task: TaskRequest):
        a = task.payload['a']
        b = task.payload['b']
        
        if task.task_type == "add":
            return {'result': a + b}
        elif task.task_type == "subtract":
            return {'result': a - b}

# Usage
agent = CalculatorAgent()
task = TaskRequest(task_type="add", payload={'a': 5, 'b': 3})
response = agent.process_task(task)
print(response.result)  # {'result': 8}
```

### Example 2: Async Agent with External API

```python
import aiohttp
from agents.agent_base_unified import *

class APIAgent(BaseAgent):
    def __init__(self):
        config = AgentConfig(
            name="APIAgent",
            description="Calls external APIs",
            capabilities=[
                AgentCapability(
                    name="api_call",
                    description="Make HTTP requests",
                    task_types=["get", "post"],
                    required_params=["url"]
                )
            ]
        )
        super().__init__(config)
    
    def _execute_task(self, task: TaskRequest):
        # For async, you'd need to modify BaseAgent
        # This is a simplified sync example
        url = task.payload['url']
        # Make API call
        result = self._make_request(url)
        return result
```

### Example 3: Configuration in Different Environments

```python
from core.config import get_settings

# Development
settings = get_settings()
if settings.debug:
    print("Running in debug mode")
    print(f"Database: {settings.database.url}")

# Production
if settings.environment == "production":
    assert settings.debug == False
    assert len(settings.security.secret_key) >= 32
```

---

*Unified Components Documentation*
*Version 1.0 - 2025-10-21*
