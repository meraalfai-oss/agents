# Phase 2 Commands - Quick Reference

## Essential Commands

### 1. Run Full Workflow
```bash
# Step 1: Analyze
python3 cleanup/01_analyze_repository.py

# Step 2: Review
cat cleanup/01_ANALYSIS_REPORT.md

# Step 3: Cleanup
python3 cleanup/02_automated_cleanup.py
# Type 'yes' when prompted

# Step 4: Consolidate
python3 cleanup/03_version_consolidation.py

# Step 5: Review
cat cleanup/03_CONSOLIDATION_REPORT.md
```

### 2. View Reports
```bash
# Analysis report (Phase 1)
cat cleanup/01_ANALYSIS_REPORT.md

# Consolidation report (Phase 2)
cat cleanup/03_CONSOLIDATION_REPORT.md
```

### 3. View Logs (JSON)
```bash
# Cleanup log
cat cleanup/02_cleanup_log.json | python3 -m json.tool

# Consolidation log
cat cleanup/03_consolidation_log.json | python3 -m json.tool
```

### 4. Check Backups
```bash
# List all backed up files
ls -R cleanup/backup/

# View specific backup
cat cleanup/backup/path/to/file.py
```

### 5. Restore Files
```bash
# Restore a single file
cp cleanup/backup/path/to/file.py path/to/file.py

# Restore entire directory
cp -r cleanup/backup/agents/ agents/
```

## One-Liners

### Quick Analysis
```bash
python3 cleanup/01_analyze_repository.py && cat cleanup/01_ANALYSIS_REPORT.md
```

### Check Duplicates Count
```bash
python3 -c "import json; print(f\"Duplicates: {json.load(open('cleanup/01_analysis_report.json'))['summary']['duplicate_files']}\")"
```

### Check Versions Count
```bash
python3 -c "import json; print(f\"Versioned files: {json.load(open('cleanup/01_analysis_report.json'))['summary']['versioned_files']}\")"
```

### List Removed Files
```bash
python3 -c "import json; [print(f['path']) for f in json.load(open('cleanup/02_cleanup_log.json'))['files']]"
```

### Count Removed Files
```bash
python3 -c "import json; print(json.load(open('cleanup/02_cleanup_log.json'))['total_removed'])"
```

## Safety Commands

### Verify Before Cleanup
```bash
# Check what exists
python3 cleanup/01_analyze_repository.py
grep "duplicate_files" cleanup/01_analysis_report.json
```

### Backup Current State
```bash
# Create manual backup before cleanup
tar -czf backup_before_cleanup.tar.gz $(git ls-files)
```

### Check Git Status
```bash
# See what changed
git status

# See diff
git diff --stat

# Revert all changes if needed
git checkout .
```

## Troubleshooting Commands

### Check for Broken Imports
```bash
# Find imports to removed files (replace FILENAME)
grep -r "from FILENAME import" . --include="*.py"
grep -r "import FILENAME" . --include="*.py"
```

### Syntax Check All Files
```bash
# Check all Python files
find . -name "*.py" -not -path "*/venv/*" -not -path "*/.git/*" -exec python3 -m py_compile {} \;
```

### Verify Imports Work
```bash
# Test critical imports
python3 -c "from core.config import Settings; print('✅ Config OK')"
python3 -c "from core.database import DatabaseManager; print('✅ Database OK')"
python3 -c "from middleware import RateLimitMiddleware; print('✅ Middleware OK')"
```

## Report Queries

### List All Duplicates
```bash
python3 -c "
import json
data = json.load(open('cleanup/01_analysis_report.json'))
for h, files in data['duplicates'].items():
    print(f'\\nGroup ({len(files)} files):')
    for f in files: print(f\"  - {f['path']}\")
"
```

### List All Versions
```bash
python3 -c "
import json
data = json.load(open('cleanup/01_analysis_report.json'))
for name, versions in data['versions'].items():
    print(f'\\n{name} ({len(versions)} versions):')
    for v in versions: print(f\"  - {v['name']}\")
"
```

### List Files to Consolidate
```bash
python3 -c "
import json
data = json.load(open('cleanup/03_consolidation_log.json'))
for item in data['consolidations']:
    print(f\"\\n{item['base_name']}:\")
    print(f\"  Keep: {item['best_version']}\")
    for v in item['other_versions']: print(f\"  Remove: {v}\")
"
```

## Automation Scripts

### Auto-Accept Cleanup (USE WITH CAUTION)
```bash
# Automatically answer 'yes' to cleanup prompt
echo "yes" | python3 cleanup/02_automated_cleanup.py
```

### Run All and Generate Summary
```bash
#!/bin/bash
python3 cleanup/01_analyze_repository.py
python3 cleanup/03_version_consolidation.py
echo "=== Summary ==="
python3 -c "
import json
analysis = json.load(open('cleanup/01_analysis_report.json'))
consol = json.load(open('cleanup/03_consolidation_log.json'))
print(f\"Total files: {analysis['summary']['total_files']}\")
print(f\"Duplicates: {analysis['summary']['duplicate_files']}\")
print(f\"Versioned: {analysis['summary']['versioned_files']}\")
print(f\"Consolidations: {len(consol['consolidations'])}\")
"
```

## File Locations

```
cleanup/
├── 01_analyze_repository.py       # Phase 1: Analysis
├── 02_automated_cleanup.py        # Phase 2: Cleanup
├── 03_version_consolidation.py   # Phase 2: Consolidation
├── 01_analysis_report.json        # Analysis data (generated)
├── 01_ANALYSIS_REPORT.md          # Analysis report (generated)
├── 02_cleanup_log.json            # Cleanup log (generated)
├── 03_consolidation_log.json      # Consolidation data (generated)
├── 03_CONSOLIDATION_REPORT.md     # Consolidation report (generated)
├── backup/                        # Backed up files (generated)
├── README.md                      # Full documentation
├── PHASE2_QUICKSTART.md           # Quick start guide
└── PHASE2_COMMANDS.md             # This file
```

## Environment Variables

### Optional: Disable Confirmation
```bash
# WARNING: Skips safety confirmation
export YMERA_AUTO_CLEANUP=1
python3 cleanup/02_automated_cleanup.py
```

### Optional: Custom Backup Directory
```bash
export YMERA_BACKUP_DIR="/path/to/custom/backup"
python3 cleanup/02_automated_cleanup.py
```

## Exit Codes

- `0` - Success
- `1` - Analysis report not found (need to run Phase 1)
- `2` - User aborted (typed 'no')

## Tips

1. **Dry run**: Review reports before running cleanup
2. **Git commit**: Commit before cleanup so you can revert
3. **Backup check**: Verify backup directory exists after cleanup
4. **Test imports**: Run your app/tests after cleanup
5. **Keep logs**: Don't delete logs/backups immediately

## Help

For detailed help on any script:
```bash
python3 cleanup/01_analyze_repository.py --help  # (if implemented)
# Or just read the docstring
head -20 cleanup/01_analyze_repository.py
```
