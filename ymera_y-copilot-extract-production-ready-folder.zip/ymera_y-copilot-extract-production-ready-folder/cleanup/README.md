# YMERA Cleanup & Repository Management

This directory contains automated cleanup, testing, and validation scripts for the YMERA repository.

## 📋 Overview

The cleanup process is organized into phases for systematic repository management:

1. **Phase 1**: Discovery & Analysis
2. **Phase 2**: Automated Cleanup & Consolidation  
3. **Phase 3**: Testing & Validation
4. **Phase 4**: Documentation Generation

## 🚀 Quick Start

### Complete Cleanup Workflow

```bash
# 1. Analyze repository structure
python3 cleanup/01_analyze_repository.py

# 2. Automated cleanup (removes duplicates/old versions)
python3 cleanup/02_automated_cleanup.py

# 3. Consolidate remaining versions
python3 cleanup/03_version_consolidation.py

# 4. Run comprehensive tests
python3 cleanup/07_complete_test_suite.py

# 5. Generate documentation
python3 cleanup/08_create_documentation.py

# 6. Validate implementation
python3 cleanup/validate_implementation.py
```

## 🔍 Phase 1: Discovery & Analysis

### 01_analyze_repository.py

**Purpose:** Complete repository analysis and cataloging

**Features:**

- Catalogs all Python files by type (agents, engines, utilities, core, shared, configs)
- Identifies duplicate files using MD5 hashing
- Finds files with version indicators (_v2, _old, _backup, etc.)
- Generates comprehensive analysis reports

**Usage:**

```bash
python3 cleanup/01_analyze_repository.py
```

**Output:**

- `01_analysis_report.json` - Machine-readable analysis data
- `01_ANALYSIS_REPORT.md` - Human-readable summary with recommendations

# YMERA Cleanup Scripts - Phase 2

This directory contains automated cleanup and consolidation scripts for the YMERA repository.

## Scripts

### 02_automated_cleanup.py

**Purpose:** Automatically removes duplicate files and old versions based on an analysis report.

**Features:**
- Removes duplicate files (keeping the best version)
- Removes old versions (keeping the most recent/complete)
- Creates backups of all removed files
- Generates a cleanup log

**Usage:**
# YMERA Repository Cleanup

This directory contains scripts and reports for the comprehensive repository cleanup process.

## Overview

The cleanup process is divided into phases:

1. **Phase 1**: Complete Analysis & Discovery
2. **Phase 2**: Automated Cleanup & Consolidation
3. **Phase 3**: Manual Review & Final Integration (if needed)

## Phase 1: Complete Analysis & Discovery

### Quick Start

Run the analysis script:

```bash
cd /home/runner/work/ymera_y/ymera_y
python3 cleanup/01_analyze_repository.py
```

### What Gets Analyzed

The analysis script examines:

1. **File Catalog** - All Python files categorized by type
1. **File Catalog** - All Python files categorized by type (agents, engines, utilities, core, shared, configs, other)
2. **Duplicates** - Files with identical content (by MD5 hash)
3. **Versions** - Files with version indicators (_v2, _old, _backup, etc.)
4. **Agents** - All agent files, checking for BaseAgent inheritance
5. **Engines** - All engine files and their structure
6. **Utilities** - Utility and helper files
7. **Configurations** - Config files, requirements files, environment files

### Generated Reports

After running the analysis, two reports are generated:

- `01_analysis_report.json` - Complete analysis data in JSON format
- `01_ANALYSIS_REPORT.md` - Human-readable markdown report

**Note**: These reports are generated each time the script runs and are not committed to git (see `.gitignore`).

### Report Contents

#### Executive Summary

- Total Python files found
- Number of duplicate files
- Files with multiple versions
- Configuration files count

#### File Breakdown

Categorization of all files by:
- Agents
- Engines
- Utilities
- Core
- Shared
- Other

#### Duplicate Files

Lists all groups of duplicate files (identical content).

#### Files with Multiple Versions

Lists files that appear to have version indicators in their names.

#### Recommendations

Lists all groups of duplicate files (identical content).

#### Files with Multiple Versions
Lists files that appear to have version indicators in their names.

#### Recommendations
Actionable HIGH, MEDIUM, and LOW priority recommendations for:
- Removing duplicates
- Consolidating versions
- Unifying configurations
- Standardizing dependencies
- Refactoring agents to use BaseAgent

## 🧹 Phase 2: Automated Cleanup & Consolidation

### 02_automated_cleanup.py

**Purpose:** Automatically removes duplicate files and old versions based on an analysis report.

**Features:**

- Removes duplicate files (keeping the best version)
- Removes old versions (keeping the most recent/complete)
- Creates backups of all removed files
- Generates a cleanup log
- Interactive confirmation before removal

**Usage:**
### Next Steps

After reviewing the analysis report:

1. Review `01_ANALYSIS_REPORT.md` for insights
2. Examine duplicate files to determine which to keep
3. Identify versioned files that need consolidation
4. Proceed to Phase 2 for automated cleanup

## Phase 2: Automated Cleanup & Consolidation

Phase 2 consists of two main scripts that automate the cleanup process based on the analysis from Phase 1.

### Script 1: Automated Cleanup (02_automated_cleanup.py)

This script automatically removes duplicate files and old versions with proper backup.

#### Usage

```bash
python3 cleanup/02_automated_cleanup.py
```

**Prerequisites:**

- Requires `cleanup/01_analysis_report.json` from Phase 1 analysis

#### What It Does

1. **Loads Analysis Data** - Reads the analysis report from Phase 1
2. **Removes Duplicates** - Identifies and removes duplicate files, keeping the best version
3. **Removes Old Versions** - Removes old versions of files, keeping the newest/best
4. **Creates Backups** - All removed files are backed up to `cleanup/backup/`
5. **Generates Log** - Creates `02_cleanup_log.json` with all actions taken

#### Selection Strategy

The script uses a scoring system to choose which file to keep:

**For Duplicates:**
- Prefers files in main directories (`agents/`, `engines/`)
- Avoids test/backup/temp directories
- Prefers larger files (usually more complete)

**For Versions:**
- Prefers main version over versioned files
- Penalizes old/backup versions
- Prefers newer version numbers (e.g., `_v2` over `_v1`)
- Prefers larger files

#### Safety Features

- **User Confirmation** - Requires explicit "yes" to proceed
- **Automatic Backup** - All removed files are backed up before deletion
- **Detailed Logging** - Every action is logged with timestamp and reason

#### Generated Files

- `cleanup/backup/` - Directory containing all backed up files
- `cleanup/02_cleanup_log.json` - Detailed log of all removals

### 03_version_consolidation.py

**Purpose:** Intelligent version analysis and consolidation recommendations

**Features:**

- Scans repository for files with version indicators
- Parses Python files using AST to identify functions and classes
- Determines most complete version based on content analysis
- Identifies unique features in other versions
- Generates consolidation reports

**Usage:**
### Script 2: Version Consolidation (03_version_consolidation.py)

This script intelligently analyzes multiple versions and provides consolidation recommendations.

#### Usage

```bash
python3 cleanup/03_version_consolidation.py
```

**No prerequisites required** - automatically scans repository for versions

#### What It Does

1. **Scans for Versions** - Finds all files with version indicators
2. **Parses Code** - Uses Python AST to analyze each version
3. **Identifies Best Version** - Determines the most complete version
4. **Finds Unique Features** - Identifies functions/classes unique to each version
5. **Generates Reports** - Creates detailed consolidation recommendations

#### Analysis Method

The script performs AST (Abstract Syntax Tree) analysis to:
- Count functions and classes in each version
- Identify unique features in each version
- Score versions based on completeness

**Scoring System:**
- Classes are weighted highest (×3)
- Functions are weighted second (×2)
- Line count is used as a tiebreaker

#### Generated Files

- `cleanup/03_consolidation_log.json` - Machine-readable consolidation data
- `cleanup/03_CONSOLIDATION_REPORT.md` - Human-readable consolidation report

#### Report Contents

For each file group, the report shows:
- **Best Version** - The recommended version to keep
- **Other Versions** - Files that can be removed after merging unique features
- **Unique Features** - Functions and classes that exist only in specific versions
- **Recommendation** - Action items for manual review

## 🧪 Phase 3: Testing & Validation

### 07_complete_test_suite.py

**Purpose:** Comprehensive agent testing framework

**Features:**

- Discovers all agent files in `agents/` directory
- Tests each agent for proper instantiation, health checks, and task processing
- Generates detailed JSON reports

**Usage:**

```bash
python3 cleanup/07_complete_test_suite.py
```

**Output:**

- Console: Test results with ✅/❌ indicators
- File: `cleanup/07_test_results.json` with detailed results

### validate_implementation.py

**Purpose:** Validate complete system implementation

**Features:**

- Checks file structure existence
- Validates agent framework imports
- Runs complete test suite
- Provides comprehensive validation report

**Usage:**

```bash
python3 cleanup/validate_implementation.py
```

**Output:**

- Console: Detailed validation results
- Exit code: 0 (success) or 1 (failure)

## 📚 Phase 4: Documentation

### 08_create_documentation.py

**Purpose:** Generate complete project documentation

**Features:**

- Creates comprehensive documentation files
- Generates from templates with current timestamps
- Updates existing documentation files
### Workflow

#### Step 1: Run Analysis

```bash
python3 cleanup/01_analyze_repository.py
```

Review `01_ANALYSIS_REPORT.md` to understand the scope of cleanup needed.

#### Step 2: Run Automated Cleanup

```bash
python3 cleanup/02_automated_cleanup.py
```

This will:
- Remove obvious duplicates
- Remove clearly outdated versions
- Back up everything removed

Type "yes" when prompted to proceed.

#### Step 3: Run Consolidation Analysis

```bash
python3 cleanup/03_version_consolidation.py
```

This generates a report identifying:
- Files with multiple versions remaining
- Which version is most complete
- Unique features in each version

#### Step 4: Manual Review

Review `03_CONSOLIDATION_REPORT.md` and:
- Verify the "best version" choice makes sense
- Manually merge any unique features if needed
- Update imports pointing to old versions
- Remove consolidated files manually (after verification)

### Safety and Recovery

#### Backup Location

All removed files are backed up to:
```
cleanup/backup/
```

The backup preserves the original directory structure.

#### Rollback

To restore a backed up file:

```bash
cp cleanup/backup/path/to/file.py path/to/file.py
```

#### Logs

All actions are logged in:
- `02_cleanup_log.json` - Lists all removed files with reasons and backup locations
- `03_consolidation_log.json` - Details all version consolidation analysis

### Example Output

#### Automated Cleanup

```
AUTOMATED CLEANUP

⚠️  This will:
   - Remove duplicate files
   - Remove old versions
   - Backup all removed files

Proceed? (yes/no): yes

1. Removing duplicates...

   Duplicate group (2 files):
   ✅ Keeping: api_extensions.py
   ❌ Removed: extensions.py (duplicate)

2. Removing old versions...

   Version group: enhancement_agent (2 versions):
   ✅ Keeping: enhancement_agent_v3.py
   ❌ Removed: enhancement_agent.py (old_version)

3. Saving cleanup log...
   Log saved: cleanup/02_cleanup_log.json

✅ Cleanup Complete!
   Removed: 15 files
   Backup: /path/to/cleanup/backup
```

#### Version Consolidation

```
VERSION CONSOLIDATION

1. Scanning for remaining versions...
   Found 21 files with versions

2. Consolidating versions...

   Consolidating: editing_agent (2 versions)
      ✅ Best version: editing_agent_v2.py
         - 4 functions
         - 7 classes
         - 1367 lines
      📋 Unique in editing_agent.py:
         - Functions: _load_chicago_style, _load_apa_style
         
3. Saving consolidation log...
   Log saved: cleanup/03_consolidation_log.json
   Report saved: cleanup/03_CONSOLIDATION_REPORT.md

✅ Consolidation Complete!
```

## Phase 2: Automated Cleanup

### 02_automated_cleanup.py

Automated cleanup script that removes duplicate files and old versions with intelligent selection.

**Features:**
- Automatic duplicate file removal with scoring system
- Old version cleanup (keeps best version based on multiple criteria)
- Automatic backup of all removed files
- Detailed cleanup logging
- Interactive confirmation before removal

**Usage:**

```bash
python3 cleanup/08_create_documentation.py
```

**Output:**

- Creates/updates documentation files in root directory
- Each file is generated from templates with current timestamp

## 🛡️ Safety Features

### Backup & Recovery

- **Automatic Backups:** All removed files backed up before deletion
- **Original Structure:** Backup preserves original directory structure
- **Recovery:** Easy restoration with `cp cleanup/backup/path/to/file.py path/to/file.py`

### Confirmation & Logging

- **Interactive Confirmation:** Cleanup script requires explicit "yes" confirmation
- **Detailed Logging:** Every action logged with timestamp and reason
- **Non-destructive Analysis:** Analysis scripts only read, never modify

## 🔧 Technical Requirements

- **Python:** 3.11+
- **Dependencies:** Standard library only (no additional packages required)
- **Modules Used:** pathlib, hashlib, ast, json, collections.defaultdict

## 📋 Best Practices

### Development Workflow

```bash
# 1. Before making changes
python3 cleanup/07_complete_test_suite.py

# 2. Make your changes
vim agents/my_agent.py

# 3. Test changes
python3 cleanup/07_complete_test_suite.py

# 4. Update documentation
python3 cleanup/08_create_documentation.py

# 5. Final validation
python3 cleanup/validate_implementation.py
```

## 📊 Summary

This cleanup directory provides essential tools for:

- ✅ **Repository Analysis** - Complete file cataloging and duplicate detection
- ✅ **Automated Cleanup** - Safe removal of duplicates and old versions
- ✅ **Version Consolidation** - Intelligent analysis of multiple file versions
- ✅ **Comprehensive Testing** - Complete agent testing framework
- ✅ **Documentation Generation** - Automated documentation creation
- ✅ **System Validation** - Complete implementation validation

Use these scripts regularly to maintain YMERA in a clean, production-ready state.

---

**Last Updated:** October 2025  
**Status:** All scripts tested and production-ready
python3 cleanup/02_automated_cleanup.py
```

**Prerequisites:**
- Requires `cleanup/01_analysis_report.json` from Phase 1 analysis

**Output:**
- `cleanup/02_cleanup_log.json` - Detailed log of removed files
- `cleanup/backup/` - Backup directory containing all removed files

### 03_consolidate_versions.py

**Purpose:** Intelligently analyzes and consolidates multiple versions of the same files.

**Features:**
- Scans repository for files with version indicators (_v, _old, _new, _backup, _copy, _2, _final, _temp)
- Parses Python files using AST to identify functions and classes
- Identifies the most complete version based on content analysis
- Reports unique features in other versions
- Generates consolidation reports

**Usage:**
```bash
python3 cleanup/03_consolidate_versions.py
```

**Output:**
- `cleanup/03_consolidation_log.json` - JSON log of all consolidations
- `cleanup/03_CONSOLIDATION_REPORT.md` - Human-readable markdown report

## Analysis Report Format

The `01_analysis_report.json` file should have the following structure:

```json
{
  "timestamp": "2025-10-21T00:00:00.000000",
  "summary": {
    "total_files": 0,
    "duplicates": 0,
    "versions": 0
  },
  "duplicates": {
    "file_hash": [
      {
        "path": "path/to/file.py",
        "lines": 100,
        "name": "file.py"
      }
    ]
  },
  "versions": {
    "base_name": [
      {
        "path": "path/to/file.py",
        "lines": 100,
        "name": "file.py",
        "version": "main"
      }
    ]
  }
}
```

## Safety Features

Both scripts include safety mechanisms:
- **Backups:** All removed files are backed up before deletion
- **Confirmation:** Cleanup script requires explicit confirmation
- **Logging:** Detailed logs of all actions
- **Non-destructive analysis:** Consolidation script only analyzes and reports

## Example Workflow

1. Run Phase 1 analysis (creates `01_analysis_report.json`)
2. Review the analysis report
3. Run `02_automated_cleanup.py` to remove duplicates and old versions
4. Run `03_consolidate_versions.py` to analyze remaining versions
5. Review the consolidation report
6. Manually merge unique features as needed

## Generated Files

- `01_analysis_report.json` - Input for cleanup (from Phase 1)
- `02_cleanup_log.json` - Cleanup operation log
- `03_consolidation_log.json` - Version consolidation log
- `03_CONSOLIDATION_REPORT.md` - Human-readable consolidation report
- `backup/` - Directory containing backups of removed files

## Notes

- All scripts are designed to be idempotent
- Scripts can be run multiple times safely
- Always review logs before performing manual actions
- Keep backups until consolidation is complete and verified
**Requirements:**
- Must run `01_analyze_repository.py` first to generate analysis report
- Interactive prompt for confirmation before removal

**Scoring System:**
The script uses an intelligent scoring system to choose the best file:
- Prefers files in main directories (agents/, engines/)
- Avoids test/backup/temp directories
- Prefers larger files (usually more complete)
- Prefers main/production versions over old/backup versions
- For versioned files, prefers higher version numbers

**Output:**
- Creates backups in `cleanup/backup/`
- Generates `02_cleanup_log.json` with removal details

## Phase 3: Version Consolidation

### 03_version_consolidation.py

Intelligent version consolidation script that analyzes multiple versions of files and identifies the best version.

**Features:**
- AST-based analysis of Python files
- Identifies functions and classes in each version
- Determines most complete version based on:
  - Number of classes (weighted highest)
  - Number of functions (weighted high)
  - Line count (tiebreaker)
- Identifies unique features in other versions
- Generates detailed consolidation reports

**Usage:**

```bash
python3 cleanup/03_version_consolidation.py
```

**No prerequisites required** - automatically scans repository for versions

**Output:**
- `03_consolidation_log.json` - Complete consolidation data
- `03_CONSOLIDATION_REPORT.md` - Human-readable report with recommendations

**Example Output:**
```
Consolidating: metrics (4 versions)
  ✅ Best version: metrics.py
     - 12 functions
     - 1 class
     - 400 lines
  📋 Unique in metrics_agent.py:
     - Functions: increment, record_metric
```

### Analysis Output Example

```
YMERA REPOSITORY ANALYSIS

1. Cataloging all files...
   Found 424 Python files
   - other: 368 files
   - configs: 12 files
   - core: 15 files
   - agents: 13 files
   ...

2. Finding duplicate files...
   Found 4 groups of duplicate files
   Total duplicate files: 9
   ...

✅ Analysis Complete!
```

## Technical Details

### Script Requirements

- Python 3.11+
- Standard library only (no additional dependencies required)

### Modules Used

- `pathlib` - File path handling
- `hashlib` - MD5 hashing for duplicate detection
- `ast` - Python AST parsing for code analysis
- `json` - JSON report generation
- `collections.defaultdict` - Data aggregation

### Exclusions

The analyzer automatically excludes:
- Hidden directories (starting with `.`)
- `venv` directories
- Git directories

### Hash Algorithm

Uses MD5 for content comparison. While MD5 is not cryptographically secure, it's sufficient for duplicate file detection.

## Support

For questions or issues with the analysis script, please open an issue in the repository.
