#!/usr/bin/env python3
"""
Automated Cleanup Script
Removes duplicates and old versions automatically
"""

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List


class AutomatedCleaner:
    def __init__(self, analysis_file: Path):
        with open(analysis_file, encoding='utf-8') as f:
            self.analysis = json.load(f)

        self.root = Path.cwd()
        self.backup_dir = self.root / 'cleanup' / 'backup'
        self.backup_dir.mkdir(parents=True, exist_ok=True)

        self.actions = []
        self.removed_files = []

    def clean(self):
        """Run automated cleanup."""
        print("=" * 80)
        print("AUTOMATED CLEANUP")
        print("=" * 80)

        print("\n⚠️  This will:")
        print("   - Remove duplicate files")
        print("   - Remove old versions")
        print("   - Backup all removed files")

        response = input("\nProceed? (yes/no): ")
        if response.lower() != 'yes':
            print("Aborted")
            return

        # Step 1: Remove duplicates
        print("\n1. Removing duplicates...")
        self._remove_duplicates()

        # Step 2: Remove old versions
        print("\n2. Removing old versions...")
        self._remove_old_versions()

        # Step 3: Save cleanup log
        print("\n3. Saving cleanup log...")
        self._save_log()

        print("\n" + "=" * 80)
        print(f"✅ Cleanup Complete!")
        print(f"   Removed: {len(self.removed_files)} files")
        print(f"   Backup: {self.backup_dir}")
        print("=" * 80)

    def _remove_duplicates(self):
        """Remove duplicate files, keeping the best version."""
        duplicates = self.analysis.get('duplicates', {})

        for hash_val, files in duplicates.items():
            # Choose best file (prefer main locations, newer files)
            best_file = self._choose_best_file(files)

            print(f"\n   Duplicate group ({len(files)} files):")
            print(f"   ✅ Keeping: {best_file['path']}")

            for file_info in files:
                if file_info['path'] != best_file['path']:
                    self._remove_file(file_info['path'], "duplicate")

    def _remove_old_versions(self):
        """Remove old versions, keeping the newest/best."""
        versions = self.analysis.get('versions', {})

        for base_name, version_files in versions.items():
            # Choose best version
            best_file = self._choose_best_version(version_files)

            print(f"\n   Version group: {base_name} ({len(version_files)} versions):")
            print(f"   ✅ Keeping: {best_file['name']}")

            for file_info in version_files:
                if file_info['path'] != best_file['path']:
                    self._remove_file(file_info['path'], "old_version")

    def _choose_best_file(self, files: List[Dict]) -> Dict:
        """Choose the best file from duplicates."""
        # Scoring system
        scores = []

        for file_info in files:
            score = 0
            path = file_info['path']

            # Prefer main directories
            if 'agents/' in path and path.count('/') == 1:
                score += 10
            if 'engines/' in path and path.count('/') == 1:
                score += 10

            # Avoid test/backup/temp directories
            if any(x in path.lower() for x in ['test', 'backup', 'temp', 'old', 'deprecated']):
                score -= 20

            # Prefer larger files (usually more complete)
            score += file_info['lines'] / 100

            scores.append((score, file_info))

        # Return highest scoring file
        return max(scores, key=lambda x: x[0])[1]

    def _choose_best_version(self, versions: List[Dict]) -> Dict:
        """Choose the best version from multiple versions."""
        # Scoring system
        scores = []

        for file_info in versions:
            score = 0
            version = file_info.get('version', 'main')

            # Prefer main version
            if version == 'main':
                score += 20

            # Penalize old/backup versions
            if any(x in version for x in ['old', 'backup', 'bak', 'temp']):
                score -= 30

            # Prefer newer versions
            if '_v' in version:
                try:
                    v_num = int(version.split('_v')[1][0])
                    score += v_num * 5
                except:
                except (IndexError, ValueError):
                except (ValueError, IndexError):
                    pass

            # Prefer larger files
            score += file_info['lines'] / 100

            scores.append((score, file_info))

        # Return highest scoring version
        return max(scores, key=lambda x: x[0])[1]

    def _remove_file(self, file_path: str, reason: str):
        """Remove a file (with backup)."""
        full_path = self.root / file_path

        if not full_path.exists():
            return

        # Create backup
        backup_path = self.backup_dir / file_path
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(full_path, backup_path)

        # Remove original
        full_path.unlink()

        print(f"   ❌ Removed: {file_path} ({reason})")

        self.removed_files.append({
            'path': file_path,
            'reason': reason,
            'backup': str(backup_path),
            'timestamp': datetime.now().isoformat()
        })

    def _save_log(self):
        """Save cleanup log."""
        log_path = self.root / 'cleanup' / '02_cleanup_log.json'

        with open(log_path, 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'total_removed': len(self.removed_files),
                'files': self.removed_files
            }, f, indent=2)

        print(f"   Log saved: {log_path}")


if __name__ == "__main__":
    analysis_file = Path('cleanup/01_analysis_report.json')

    if not analysis_file.exists():
        print("❌ Analysis report not found!")
        print("   Run: python3 cleanup/01_analyze_repository.py first")
        exit(1)

    cleaner = AutomatedCleaner(analysis_file)
    cleaner.clean()
