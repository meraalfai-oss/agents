#!/usr/bin/env python3
"""
Dependency Checker and Installer
Checks for missing dependencies and optionally installs them
"""

import importlib
import subprocess
import sys
from typing import Dict, List, Tuple

# Define critical dependencies by priority
DEPENDENCIES = {
    "Priority 1: Core AI/ML": [
        ("openai", "openai"),
        ("anthropic", "anthropic"),
        ("torch", "torch --index-url https://download.pytorch.org/whl/cpu"),
        ("transformers", "transformers"),
        ("sentence_transformers", "sentence-transformers"),
        ("langchain", "langchain"),
    ],
    "Priority 2: NLP & Documents": [
        ("textblob", "textblob"),
        ("fitz", "pymupdf"),  # PyMuPDF imports as 'fitz'
        ("docx", "python-docx"),
        ("markdown", "markdown"),
        ("bs4", "beautifulsoup4"),
        ("lxml", "lxml"),
    ],
    "Priority 3: Vector & Cloud": [
        ("qdrant_client", "qdrant-client"),
        ("faiss", "faiss-cpu"),
        ("chromadb", "chromadb"),
        ("google.generativeai", "google-generativeai"),
    ],
    "Priority 4: Integration Tools": [
        ("qrcode", "qrcode"),
        ("atlassian", "atlassian-python-api"),
        ("gitlab", "python-gitlab"),
        ("github", "PyGithub"),
    ],
}


def check_package(import_name: str) -> bool:
    """Check if a package is installed"""
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        return False


def check_dependencies() -> Dict[str, List[Tuple[str, str, bool]]]:
    """
    Check all dependencies and return their status

    Returns:
        Dict with priority levels as keys and list of (import_name, install_name, is_installed) tuples
    """
    results = {}

    for priority, packages in DEPENDENCIES.items():
        priority_results = []
        for import_name, install_name in packages:
            is_installed = check_package(import_name)
            priority_results.append((import_name, install_name, is_installed))
        results[priority] = priority_results

    return results


def print_status(results: Dict[str, List[Tuple[str, str, bool]]]):
    """Print dependency status"""
    print("=" * 70)
    print("DEPENDENCY STATUS CHECK")
    print("=" * 70)
    print()

    total_packages = 0
    total_installed = 0
    total_missing = 0

    for priority, packages in results.items():
        print(f"\n{priority}")
        print("-" * 70)

        for import_name, install_name, is_installed in packages:
            total_packages += 1
            if is_installed:
                total_installed += 1
                print(f"  ✅ {import_name:30s} (installed)")
            else:
                total_missing += 1
                print(f"  ❌ {import_name:30s} (MISSING - pip install {install_name})")

    print()
    print("=" * 70)
    print(f"Summary: {total_installed}/{total_packages} installed, {total_missing} missing")
    print("=" * 70)

    return total_missing


def install_missing(priority: str = None, dry_run: bool = False):
    """
    Install missing dependencies

    Args:
        priority: Specific priority level to install (e.g., "Priority 1: Core AI/ML")
        dry_run: If True, only show what would be installed
    """
    results = check_dependencies()

    priorities_to_install = [priority] if priority else DEPENDENCIES.keys()

    install_commands = []

    for pri in priorities_to_install:
        if pri not in results:
            print(f"Warning: Unknown priority '{pri}'")
            continue

        packages = results[pri]
        missing_packages = [
            (import_name, install_name)
            for import_name, install_name, is_installed in packages
            if not is_installed
        ]

        if missing_packages:
            print(f"\n{pri}")
            print("-" * 70)

            for import_name, install_name in missing_packages:
                cmd = f"pip install {install_name}"
                install_commands.append(cmd)

                if dry_run:
                    print(f"  Would run: {cmd}")
                else:
                    print(f"  Installing: {import_name}...")
                    try:
                        subprocess.run(cmd.split(), check=True, capture_output=True, text=True)
                        print(f"    ✅ Installed successfully")
                    except subprocess.CalledProcessError as e:
                        print(f"    ❌ Failed: {e.stderr[:100]}")

    if dry_run:
        print("\n" + "=" * 70)
        print(f"DRY RUN: Would install {len(install_commands)} packages")
        print("Run without --dry-run to install")
        print("=" * 70)
    elif install_commands:
        print("\n" + "=" * 70)
        print(f"Installation complete: {len(install_commands)} packages processed")
        print("Re-run check to verify installation")
        print("=" * 70)
    else:
        print("\n" + "=" * 70)
        print("All dependencies are already installed!")
        print("=" * 70)


def generate_install_script():
    """Generate a shell script to install all dependencies"""
    results = check_dependencies()

    script = "#!/bin/bash\n"
    script += "# Auto-generated dependency installation script\n"
    script += "# Generated by dependency_checker.py\n\n"
    script += "set -e  # Exit on error\n\n"

    for priority, packages in results.items():
        missing_packages = [
            (import_name, install_name)
            for import_name, install_name, is_installed in packages
            if not is_installed
        ]

        if missing_packages:
            script += f"\n# {priority}\n"
            script += f"echo 'Installing {priority}...'\n"

            for import_name, install_name in missing_packages:
                script += f"pip install {install_name}\n"

    script += "\necho 'All dependencies installed!'\n"

    filename = "install_dependencies.sh"
    with open(filename, "w") as f:
        f.write(script)

    import os

    os.chmod(filename, 0o755)

    print(f"✅ Installation script saved to: {filename}")
    print(f"   Run with: ./{filename}")


def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Check and install missing dependencies for agent benchmarking"
    )
    parser.add_argument(
        "action",
        choices=["check", "install", "generate"],
        help="Action to perform: check status, install missing, or generate install script",
    )
    parser.add_argument(
        "--priority",
        choices=[p for p in DEPENDENCIES.keys()],
        help="Specific priority level to install (for install action)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be installed without actually installing",
    )

    args = parser.parse_args()

    if args.action == "check":
        results = check_dependencies()
        missing_count = print_status(results)
        sys.exit(0 if missing_count == 0 else 1)

    elif args.action == "install":
        install_missing(priority=args.priority, dry_run=args.dry_run)

    elif args.action == "generate":
        generate_install_script()


if __name__ == "__main__":
    main()
