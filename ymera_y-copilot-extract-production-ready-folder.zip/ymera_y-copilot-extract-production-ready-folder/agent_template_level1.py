"""
agent_communicator - Agent for agent communicator

Status: FIXED
Last Modified: 2025-10-21
Dependencies: base_agent.py (Level 1)
Internal Dependencies: 2
"""

import json
import logging
import uuid
from datetime import datetime

# Standard library imports
from typing import Any, Dict, List

# Local imports (from same directory or parent)
try:
    from base_agent import AgentStatus, BaseAgent, Priority, TaskStatus

    HAS_BASE_AGENT = True
except ImportError:
    # Fallback for testing without base_agent
    BaseAgent = object
    AgentStatus = None
    Priority = None
    TaskStatus = None
    HAS_BASE_AGENT = False

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AgentCommunicator(BaseAgent if HAS_BASE_AGENT else object):
    """
    agent_communicator

    Capabilities:
    - Process various task types
    - Health monitoring
    - Metrics tracking

    Dependencies:
    - base_agent.py (BaseAgent) - Level 1

    Supported Task Types:
    - general: General task processing
    - specific: Agent-specific tasks
    """

    def __init__(self, agent_id: str = None, config: Dict[str, Any] = None):
        """Initialize AgentCommunicator"""
        self.agent_id = agent_id or str(uuid.uuid4())
        self.name = "AgentCommunicator"
        self.config = config or {}
        self.logger = logging.getLogger(f"Agent.{self.name}")
        self.metrics = {"tasks_processed": 0, "tasks_succeeded": 0, "tasks_failed": 0}

        if HAS_BASE_AGENT:
            # Initialize BaseAgent if available
            super().__init__(agent_id=self.agent_id, name=self.name, config=self.config)

        self.logger.info(f"{self.name} initialized (agent_id: {self.agent_id})")

    async def process_task(self, task_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a task.

        Args:
            task_type: Type of task to process
            payload: Task payload data

        Returns:
            Result dictionary
        """
        try:
            self.logger.info(f"Processing task: {task_type}")

            # Validate input
            if not payload:
                raise ValueError("Empty payload")

            # Process based on task type
            if task_type == "general":
                result = await self._process_general(payload)
            elif task_type == "specific":
                result = await self._process_specific(payload)
            else:
                result = await self._process_default(payload)

            self.metrics["tasks_processed"] += 1
            self.metrics["tasks_succeeded"] += 1
            self.logger.info(f"Task completed: {task_type}")

            return {"status": "success", "result": result, "task_type": task_type}

        except Exception as e:
            self.metrics["tasks_processed"] += 1
            self.metrics["tasks_failed"] += 1
            self.logger.error(f"Task failed: {str(e)}")

            return {"status": "error", "error": str(e), "task_type": task_type}

    async def _process_general(self, payload: Dict[str, Any]) -> Any:
        """Process general tasks"""
        return {"processed": True, "data": payload}

    async def _process_specific(self, payload: Dict[str, Any]) -> Any:
        """Process specific tasks"""
        return {"processed": True, "type": "specific", "data": payload}

    async def _process_default(self, payload: Dict[str, Any]) -> Any:
        """Default task processing"""
        return {"processed": True, "default": True, "data": payload}

    def health_check(self) -> Dict[str, Any]:
        """Check agent health"""
        success_rate = (
            self.metrics["tasks_succeeded"] / self.metrics["tasks_processed"] * 100
            if self.metrics["tasks_processed"] > 0
            else 0
        )

        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "status": "healthy",
            "has_base_agent": HAS_BASE_AGENT,
            "metrics": self.metrics,
            "success_rate": f"{success_rate:.1f}%",
            "timestamp": datetime.now().isoformat(),
        }

    def get_capabilities(self) -> List[str]:
        """Get agent capabilities"""
        return [
            "general_processing",
            "specific_processing",
            "health_monitoring",
            "metrics_tracking",
        ]


# Standalone functionality for testing
if __name__ == "__main__":
    import asyncio

    print("=" * 70)
    print("AgentCommunicator Testing")
    print("=" * 70)
    print()

    async def test_agent():
        # Create agent
        agent = AgentCommunicator()

        # Test health check
        print("1. Health Check:")
        health = agent.health_check()
        print(json.dumps(health, indent=2))
        print()

        # Test capabilities
        print("2. Capabilities:")
        capabilities = agent.get_capabilities()
        for cap in capabilities:
            print(f"   - {cap}")
        print()

        # Test task processing
        print("3. Task Processing:")
        result1 = await agent.process_task("general", {"test": "data", "value": 123})
        print(f"   General task: {result1['status']}")

        result2 = await agent.process_task("specific", {"key": "value"})
        print(f"   Specific task: {result2['status']}")
        print()

        # Test metrics
        print("4. Final Metrics:")
        final_health = agent.health_check()
        print(f"   Tasks Processed: {final_health['metrics']['tasks_processed']}")
        print(f"   Success Rate: {final_health['success_rate']}")
        print()

    asyncio.run(test_agent())

    print("=" * 70)
    print("✅ All tests completed")
    print("=" * 70)
