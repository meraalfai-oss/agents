#!/bin/bash

echo "🧹 Running automated code cleanup for Phase 3..."
echo "=================================================="

# Exit on error
set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Track changes
CHANGES_MADE=0

echo ""
echo -e "${YELLOW}Step 1: Removing trailing whitespace${NC}"
echo "----------------------------------------"
find . -name "*.py" -type f \
    ! -path "./.git/*" \
    ! -path "./.venv/*" \
    ! -path "./venv/*" \
    ! -path "./__pycache__/*" \
    ! -path "*/dist/*" \
    ! -path "*/build/*" \
    -exec sed -i 's/[[:space:]]*$//' {} + 2>/dev/null && echo "✅ Trailing whitespace removed" || echo "⚠️  Trailing whitespace removal failed"

echo ""
echo -e "${YELLOW}Step 2: Removing unused imports${NC}"
echo "----------------------------------------"
autoflake --in-place --remove-all-unused-imports --remove-unused-variables \
    --recursive \
    --exclude='.git,.venv,venv,__pycache__,dist,build' \
    . && echo "✅ Unused imports removed" || echo "⚠️  Unused imports removal failed"

echo ""
echo -e "${YELLOW}Step 3: Sorting imports${NC}"
echo "----------------------------------------"
isort . \
    --skip .git \
    --skip .venv \
    --skip venv \
    --skip __pycache__ \
    --skip dist \
    --skip build \
    --profile black \
    --line-length 100 && echo "✅ Imports sorted" || echo "⚠️  Import sorting failed"

echo ""
echo -e "${YELLOW}Step 4: Formatting code with Black${NC}"
echo "----------------------------------------"
black . \
    --line-length 100 \
    --target-version py39 \
    --exclude '/(\.git|\.venv|venv|__pycache__|dist|build)/' && echo "✅ Code formatted with Black" || echo "⚠️  Black formatting failed"

echo ""
echo -e "${YELLOW}Step 5: Checking results${NC}"
echo "----------------------------------------"

# Count critical errors only
CRITICAL_ERRORS=$(flake8 . \
    --count \
    --select=E9,F63,F7,F82 \
    --exclude=.git,__pycache__,.venv,venv,*.egg-info,dist,build \
    --show-source \
    --statistics 2>&1 | tail -1 || echo "0")

echo "Critical errors remaining: $CRITICAL_ERRORS"

# Get total issue count
TOTAL_ISSUES=$(flake8 . \
    --count \
    --statistics \
    --max-line-length=100 \
    --extend-ignore=E203,W503 \
    --exclude=.git,__pycache__,.venv,venv,*.egg-info,dist,build 2>&1 | tail -1 || echo "0")

echo "Total flake8 issues remaining: $TOTAL_ISSUES"

echo ""
echo -e "${GREEN}✅ Cleanup complete!${NC}"
echo "=================================================="
echo ""
echo "Summary:"
echo "  - Trailing whitespace: REMOVED"
echo "  - Unused imports: REMOVED"
echo "  - Imports: SORTED"
echo "  - Code: FORMATTED"
echo "  - Critical errors: $CRITICAL_ERRORS"
echo "  - Total issues: $TOTAL_ISSUES"
echo ""
echo "Next steps:"
echo "  1. Review changes with: git diff"
echo "  2. Run tests: pytest tests/"
echo "  3. Generate coverage report: pytest --cov=. --cov-report=html"
echo ""
