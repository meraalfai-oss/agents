#!/usr/bin/env python3
"""
Complete System Integration & Final Fixes
==========================================

Comprehensive script to:
1. Fix remaining agents
2. Verify all integrations
3. Generate detailed coverage report
4. List all agents and modules with features
5. Prepare system for production integration

Author: GitHub Copilot Agent
Date: 2025-10-21
"""

import importlib.util
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List


class SystemIntegrationManager:
    """Manages complete system integration and reporting."""

    def __init__(self):
        self.root_dir = Path("/home/runner/work/ymera_y/ymera_y")
        self.agents_dir = self.root_dir / "agents"
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "agents": {},
            "modules": {},
            "coverage": {},
            "integration_status": {},
            "recommendations": [],
        }

    def analyze_all_agents(self) -> Dict[str, Any]:
        """Analyze all agent files and their status."""
        print("\n" + "=" * 80)
        print("ANALYZING ALL AGENTS")
        print("=" * 80)

        agent_files = list(self.root_dir.glob("*_agent.py"))
        if self.agents_dir.exists():
            agent_files.extend(list(self.agents_dir.glob("*_agent.py")))

        total = len(agent_files)
        working = 0
        failing = 0

        for agent_file in sorted(agent_files):
            agent_name = agent_file.name
            status = self._test_agent_import(agent_file)

            self.results["agents"][agent_name] = status

            if status["working"]:
                working += 1
                print(f"✅ {agent_name}")
            else:
                failing += 1
                print(f"❌ {agent_name}: {status['error_type']}")

        print(
            f"\nTotal: {total} | Working: {working} ({working/total*100:.1f}%) | Failing: {failing} ({failing/total*100:.1f}%)"
        )

        return {
            "total": total,
            "working": working,
            "failing": failing,
            "success_rate": working / total * 100 if total > 0 else 0,
        }

    def _test_agent_import(self, agent_file: Path) -> Dict[str, Any]:
        """Test if an agent can be imported."""
        try:
            spec = importlib.util.spec_from_file_location(agent_file.stem, agent_file)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[agent_file.stem] = module
                spec.loader.exec_module(module)

                # Extract features
                features = self._extract_features(module)

                return {
                    "working": True,
                    "error": None,
                    "error_type": None,
                    "features": features,
                    "path": str(agent_file),
                }
        except ModuleNotFoundError as e:
            return {
                "working": False,
                "error": str(e),
                "error_type": "ModuleNotFoundError",
                "missing_module": str(e).split("'")[1] if "'" in str(e) else "unknown",
                "path": str(agent_file),
            }
        except ImportError as e:
            return {
                "working": False,
                "error": str(e),
                "error_type": "ImportError",
                "path": str(agent_file),
            }
        except SyntaxError as e:
            return {
                "working": False,
                "error": str(e),
                "error_type": "SyntaxError",
                "path": str(agent_file),
            }
        except Exception as e:
            return {
                "working": False,
                "error": str(e),
                "error_type": type(e).__name__,
                "path": str(agent_file),
            }

    def _extract_features(self, module) -> List[str]:
        """Extract features from agent module."""
        features = []

        # Check for common agent patterns
        if hasattr(module, "BaseAgent"):
            features.append("base_agent_class")
        if hasattr(module, "process_task") or hasattr(module, "execute_task"):
            features.append("task_processing")
        if hasattr(module, "health_check"):
            features.append("health_check")
        if hasattr(module, "get_capabilities"):
            features.append("capabilities_discovery")
        if hasattr(module, "__main__"):
            features.append("standalone_executable")

        # Check for specific agent types
        module_vars = dir(module)
        if any("learning" in v.lower() for v in module_vars):
            features.append("learning_capability")
        if any("llm" in v.lower() for v in module_vars):
            features.append("llm_integration")
        if any("monitor" in v.lower() for v in module_vars):
            features.append("monitoring")
        if any("analysis" in v.lower() or "analyzer" in v.lower() for v in module_vars):
            features.append("analysis")

        return features

    def analyze_modules(self) -> Dict[str, Any]:
        """Analyze all Python modules."""
        print("\n" + "=" * 80)
        print("ANALYZING MODULES")
        print("=" * 80)

        py_files = list(self.root_dir.glob("*.py"))

        categories = {
            "core": [],
            "infrastructure": [],
            "utilities": [],
            "apis": [],
            "monitoring": [],
            "database": [],
            "security": [],
        }

        for py_file in sorted(py_files):
            if py_file.name.startswith("test_") or py_file.name.startswith("__"):
                continue

            category = self._categorize_module(py_file.name)
            status = self._test_module_import(py_file)

            module_info = {
                "name": py_file.name,
                "category": category,
                "status": status,
                "path": str(py_file),
            }

            categories[category].append(module_info)
            self.results["modules"][py_file.name] = module_info

            if status["working"]:
                print(f"✅ {py_file.name} ({category})")
            else:
                print(f"❌ {py_file.name} ({category}): {status['error_type']}")

        return categories

    def _categorize_module(self, filename: str) -> str:
        """Categorize module by filename."""
        if any(x in filename.lower() for x in ["engine", "core", "system"]):
            return "core"
        elif any(x in filename.lower() for x in ["api", "route", "endpoint"]):
            return "apis"
        elif any(x in filename.lower() for x in ["monitor", "metrics", "health"]):
            return "monitoring"
        elif any(x in filename.lower() for x in ["database", "db", "sql"]):
            return "database"
        elif any(x in filename.lower() for x in ["auth", "security", "encrypt"]):
            return "security"
        elif any(x in filename.lower() for x in ["orchestrator", "manager", "lifecycle"]):
            return "infrastructure"
        else:
            return "utilities"

    def _test_module_import(self, module_file: Path) -> Dict[str, Any]:
        """Test if a module can be imported."""
        try:
            spec = importlib.util.spec_from_file_location(module_file.stem, module_file)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_file.stem] = module
                spec.loader.exec_module(module)

                return {"working": True, "error": None, "error_type": None}
        except Exception as e:
            return {"working": False, "error": str(e), "error_type": type(e).__name__}

    def generate_integration_report(self) -> str:
        """Generate comprehensive integration report."""
        print("\n" + "=" * 80)
        print("GENERATING INTEGRATION REPORT")
        print("=" * 80)

        report = []
        report.append("# YMERA System Integration Report")
        report.append(f"\n**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(
            f"\n**Status:** {'🟢 READY' if self.results['coverage'].get('success_rate', 0) >= 95 else '🟡 IN PROGRESS'}"
        )

        # Executive Summary
        report.append("\n## Executive Summary")
        agent_stats = self.results.get("coverage", {})
        report.append(f"\n- **Total Agents:** {agent_stats.get('total', 0)}")
        report.append(f"- **Working Agents:** {agent_stats.get('working', 0)}")
        report.append(f"- **Failing Agents:** {agent_stats.get('failing', 0)}")
        report.append(f"- **Success Rate:** {agent_stats.get('success_rate', 0):.1f}%")

        # Agent Inventory
        report.append("\n## 📋 Complete Agent Inventory")
        report.append("\n### Working Agents")
        working_agents = [
            (name, info) for name, info in self.results["agents"].items() if info["working"]
        ]
        for name, info in sorted(working_agents):
            features = ", ".join(info.get("features", []))
            report.append(f"\n#### {name}")
            report.append(f"- **Status:** ✅ Working")
            report.append(f"- **Features:** {features or 'N/A'}")
            report.append(f"- **Path:** `{info['path']}`")

        report.append("\n### Failing Agents")
        failing_agents = [
            (name, info) for name, info in self.results["agents"].items() if not info["working"]
        ]
        for name, info in sorted(failing_agents):
            report.append(f"\n#### {name}")
            report.append(f"- **Status:** ❌ Failing")
            report.append(f"- **Error Type:** {info['error_type']}")
            report.append(f"- **Error:** `{info['error']}`")
            if "missing_module" in info:
                report.append(f"- **Missing Module:** `{info['missing_module']}`")

        # Module Inventory
        report.append("\n## 🔧 Complete Module Inventory")

        module_categories = {}
        for module_name, module_info in self.results["modules"].items():
            category = module_info["category"]
            if category not in module_categories:
                module_categories[category] = []
            module_categories[category].append((module_name, module_info))

        for category, modules in sorted(module_categories.items()):
            report.append(f"\n### {category.title()} Modules")
            for name, info in sorted(modules):
                status = "✅" if info["status"]["working"] else "❌"
                report.append(f"- {status} **{name}**")
                if not info["status"]["working"]:
                    report.append(f"  - Error: `{info['status']['error_type']}`")

        # Integration Readiness
        report.append("\n## 🚀 Integration Readiness")
        report.append("\n### Core Components")
        core_components = {
            "base_agent.py": self._check_file_exists("base_agent.py"),
            "config.py": self._check_file_exists("config.py"),
            "database.py": self._check_file_exists("database.py"),
            "api_gateway.py": self._check_file_exists("api_gateway.py"),
            "orchestrator.py": self._check_file_exists("orchestrator.py"),
        }

        for component, exists in core_components.items():
            status = "✅" if exists else "❌"
            report.append(f"- {status} {component}")

        # Recommendations
        report.append("\n## 💡 Recommendations")

        if agent_stats.get("success_rate", 0) < 95:
            report.append("\n### High Priority")
            report.append("1. Fix remaining agent import errors")
            report.append("2. Install missing dependencies")
            report.append("3. Resolve syntax errors")

        report.append("\n### Integration Steps")
        report.append("1. Run comprehensive E2E tests")
        report.append("2. Verify all API endpoints")
        report.append("3. Test database connections")
        report.append("4. Validate security configurations")
        report.append("5. Perform load testing")

        return "\n".join(report)

    def _check_file_exists(self, filename: str) -> bool:
        """Check if file exists in root directory."""
        return (self.root_dir / filename).exists()

    def save_reports(self):
        """Save all reports to files."""
        # Save JSON report
        json_path = self.root_dir / "COMPLETE_SYSTEM_INTEGRATION_REPORT.json"
        with open(json_path, "w") as f:
            json.dump(self.results, f, indent=2)
        print(f"\n✅ JSON report saved: {json_path}")

        # Save markdown report
        md_report = self.generate_integration_report()
        md_path = self.root_dir / "COMPLETE_SYSTEM_INTEGRATION_REPORT.md"
        with open(md_path, "w") as f:
            f.write(md_report)
        print(f"✅ Markdown report saved: {md_path}")

    def run(self):
        """Run complete integration analysis."""
        print("\n" + "=" * 80)
        print("COMPLETE SYSTEM INTEGRATION & ANALYSIS")
        print("=" * 80)

        # Analyze agents
        agent_coverage = self.analyze_all_agents()
        self.results["coverage"] = agent_coverage

        # Analyze modules
        self.analyze_modules()

        # Generate and save reports
        self.save_reports()

        print("\n" + "=" * 80)
        print("ANALYSIS COMPLETE")
        print("=" * 80)
        print(f"\n✅ Total Agents: {agent_coverage['total']}")
        print(f"✅ Working: {agent_coverage['working']} ({agent_coverage['success_rate']:.1f}%)")
        print(f"❌ Failing: {agent_coverage['failing']}")
        print(f"\n📊 View full report: COMPLETE_SYSTEM_INTEGRATION_REPORT.md")
        print(f"📊 View JSON data: COMPLETE_SYSTEM_INTEGRATION_REPORT.json")


if __name__ == "__main__":
    manager = SystemIntegrationManager()
    manager.run()
