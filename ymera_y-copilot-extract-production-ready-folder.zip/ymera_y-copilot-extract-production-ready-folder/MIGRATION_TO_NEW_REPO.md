# Repository Migration Guide

## Objective
Push the complete ymera_y repository to the new location: `https://github.com/meraalfai-oss/agents.git`

## Prerequisites
- Git installed and configured
- Access credentials for the new repository (GitHub token or SSH key)
- Repository permissions: Write access to `meraalfai-oss/agents`

## Migration Steps

### Option 1: Add as New Remote (Recommended)

This approach maintains the original remote while adding the new one.

```bash
# Navigate to repository
cd /path/to/ymera_y

# Add the new remote
git remote add meraalfai https://github.com/meraalfai-oss/agents.git

# Verify remotes
git remote -v

# Push all branches to the new remote
git push meraalfai --all

# Push all tags to the new remote
git push meraalfai --tags

# Verify the push
git ls-remote meraalfai
```

### Option 2: Change Origin Remote

This approach replaces the current origin with the new repository.

```bash
# Navigate to repository
cd /path/to/ymera_y

# Backup current remote URL (optional)
git remote get-url origin > original_remote.txt

# Change origin to new repository
git remote set-url origin https://github.com/meraalfai-oss/agents.git

# Verify the change
git remote -v

# Push all branches
git push origin --all

# Push all tags
git push origin --tags

# Verify the push
git ls-remote origin
```

### Option 3: Mirror Push (Complete Copy)

This creates an exact mirror including all refs.

```bash
# Navigate to repository
cd /path/to/ymera_y

# Add new remote
git remote add meraalfai https://github.com/meraalfai-oss/agents.git

# Push everything as a mirror
git push meraalfai --mirror

# Verify
git ls-remote meraalfai
```

## Authentication Options

### Using HTTPS with Personal Access Token
```bash
# Method 1: Credential helper
git config credential.helper store
# Then git will prompt for username/token on first push

# Method 2: Embedded in URL (less secure, not recommended for scripts)
git remote add meraalfai https://YOUR_TOKEN@github.com/meraalfai-oss/agents.git
```

### Using SSH
```bash
# Use SSH URL instead
git remote add meraalfai git@github.com:meraalfai-oss/agents.git

# Ensure SSH key is configured
ssh -T git@github.com
```

## Repository Statistics

Current repository contains:
- **Total Files:** 1,259
- **Branches:** 
  - `copilot/vscode1761236490170` (current)
- **Commits:** Multiple (see `git log --oneline --all` for full history)
- **Size:** ~26 MB (excluding .git directory)

### Key Components Being Migrated:
- **Agents:** 163 agent files in the `agents/` directory
- **Documentation:** Extensive markdown documentation (100+ files)
- **Tests:** Comprehensive test suites
- **Configuration:** Docker, Kubernetes, CI/CD configs
- **Dependencies:** requirements.txt, pyproject.toml
- **Infrastructure:** Terraform, monitoring configs

## Verification Checklist

After pushing, verify the following:

- [ ] All branches are present: `git branch -r`
- [ ] All tags are present: `git tag -l`
- [ ] Latest commit matches: Compare SHA-1 hashes
- [ ] File count matches: Compare number of files
- [ ] Repository size is similar
- [ ] README.md displays correctly on GitHub
- [ ] .gitignore is working (no unwanted files)
- [ ] GitHub Actions/CI is configured (if needed)

## Post-Migration Steps

### Update README
Consider updating the README.md to reflect the new repository location:

```markdown
## Repository
- **New Location:** https://github.com/meraalfai-oss/agents
- **Previous Location:** https://github.com/ymera-mfm/ymera_y
```

### Update Documentation
Search and replace any hardcoded references to the old repository:

```bash
# Find files with old repository references
grep -r "ymera-mfm/ymera_y" .

# Update references (review each before updating)
find . -type f -name "*.md" -exec sed -i 's|ymera-mfm/ymera_y|meraalfai-oss/agents|g' {} +
```

### GitHub Repository Settings

Configure the new repository on GitHub:
1. **Description:** "YMERA Multi-Agent Intelligence Platform - Production Ready"
2. **Topics/Tags:** python, agents, multi-agent-system, ai, machine-learning
3. **Branch Protection:** Configure for main/master branch
4. **Collaborators:** Add team members
5. **Webhooks:** Configure if needed for CI/CD
6. **GitHub Pages:** Enable if documentation site is needed
7. **Secrets:** Add any required GitHub Actions secrets

## Troubleshooting

### Issue: Authentication Failed
```bash
# Solution: Check credentials
git credential reject
# Then try push again with correct credentials
```

### Issue: Large Files
```bash
# Check for large files
find . -type f -size +50M -not -path "./.git/*"

# If needed, use Git LFS
git lfs install
git lfs track "*.gz"
git lfs track "*.tar.gz"
```

### Issue: Push Rejected
```bash
# Solution: Force push with caution
git push meraalfai --force --all
git push meraalfai --force --tags
```

### Issue: Partial Push
```bash
# Verify what was pushed
git ls-remote meraalfai

# Re-push missing refs
git push meraalfai <branch-name>
```

## Current Repository State

- **Working Tree:** Clean (no uncommitted changes)
- **Current Branch:** copilot/vscode1761236490170
- **Origin Remote:** https://github.com/ymera-mfm/ymera_y
- **Status:** Ready for migration

## Quick Command Summary

For the fastest migration, run these commands in sequence:

```bash
cd /home/runner/work/ymera_y/ymera_y
git remote add meraalfai https://github.com/meraalfai-oss/agents.git
git push meraalfai --all
git push meraalfai --tags
git ls-remote meraalfai
```

## Notes

1. **Backup:** Consider creating a backup before migration:
   ```bash
   tar -czf ymera_y_backup_$(date +%Y%m%d).tar.gz /path/to/ymera_y
   ```

2. **Large Files:** The repository contains `ymera_agents_standalone.tar.gz` (2.4MB) which will be included in the push.

3. **Hidden Files:** The `.env` file is tracked. Ensure it doesn't contain secrets, or add it to .gitignore before pushing.

4. **CI/CD:** Existing `.github/workflows/` files will be migrated. Update them if they reference the old repository.

## Security Considerations

⚠️ **Before pushing, verify:**
- No secrets in `.env` or other config files
- No API keys or tokens in code
- No private credentials in documentation
- Review `.gitignore` is comprehensive

## Support

If you encounter issues during migration:
1. Check GitHub status: https://www.githubstatus.com/
2. Verify network connectivity
3. Ensure correct permissions on target repository
4. Review GitHub documentation: https://docs.github.com/en/repositories

---

**Migration prepared by:** YMERA System Agent
**Date:** 2025-10-23
**Status:** Ready for execution
