# main.py - Production-Ready Agent Management System
"""
Enterprise Agent Management Platform
Focus: Simplicity, Reliability, Performance
"""

import asyncio
import json
import logging
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional

import bcrypt
import redis.asyncio as aioredis
import uvicorn
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from prometheus_client import Counter, Histogram
from pydantic import BaseModel, Field
from sqlalchemy import JSON, Boolean, Column, DateTime, ForeignKey, String, Text, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import declarative_base, relationship

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# =============================================================================
# MODELS & SCHEMAS
# =============================================================================

Base = declarative_base()


class AgentStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    BUSY = "busy"
    ERROR = "error"


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


# Database Models
class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    agents = relationship("Agent", back_populates="owner")
    tasks = relationship("Task", back_populates="user")


class Agent(Base):
    __tablename__ = "agents"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False)
    description = Column(Text)
    capabilities = Column(JSON, default=list)
    status = Column(String(20), default=AgentStatus.INACTIVE)
    owner_id = Column(String, ForeignKey("users.id"), nullable=False)
    config = Column(JSON, default=dict)
    last_heartbeat = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    owner = relationship("User", back_populates="agents")
    tasks = relationship("Task", back_populates="agent")


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(200), nullable=False)
    description = Column(Text)
    task_type = Column(String(50), nullable=False)
    parameters = Column(JSON, default=dict)
    priority = Column(String(20), default=TaskPriority.NORMAL)
    status = Column(String(20), default=TaskStatus.PENDING)
    result = Column(JSON)
    error_message = Column(Text)

    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    agent_id = Column(String, ForeignKey("agents.id"))

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)

    # Relationships
    user = relationship("User", back_populates="tasks")
    agent = relationship("Agent", back_populates="tasks")


# Pydantic Schemas
class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: str = Field(..., regex=r"^[^@]+@[^@]+\.[^@]+$")
    password: str = Field(..., min_length=8)


class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    is_active: bool
    created_at: datetime


class AgentCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    capabilities: List[str] = Field(default_factory=list)
    config: Dict[str, Any] = Field(default_factory=dict)


class AgentResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    capabilities: List[str]
    status: AgentStatus
    last_heartbeat: Optional[datetime]
    created_at: datetime


class TaskCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    task_type: str = Field(..., min_length=1, max_length=50)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    priority: TaskPriority = TaskPriority.NORMAL
    agent_id: Optional[str] = None


class TaskResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    task_type: str
    parameters: Dict[str, Any]
    priority: TaskPriority
    status: TaskStatus
    result: Optional[Dict[str, Any]]
    error_message: Optional[str]
    created_at: datetime
    completed_at: Optional[datetime]


# =============================================================================
# CORE SERVICES
# =============================================================================


class DatabaseManager:
    def __init__(self, database_url: str):
        self.engine = create_async_engine(database_url, echo=False)
        self.async_session = async_sessionmaker(
            self.engine, class_=AsyncSession, expire_on_commit=False
        )

    async def get_session(self) -> AsyncSession:
        async with self.async_session() as session:
            yield session

    async def create_tables(self):
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)


class AuthService:
    def __init__(self, secret_key: str):
        self.secret_key = secret_key
        self.algorithm = "HS256"
        self.access_token_expire_minutes = 30

    def hash_password(self, password: str) -> str:
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    def verify_password(self, password: str, hashed_password: str) -> bool:
        return bcrypt.checkpw(password.encode("utf-8"), hashed_password.encode("utf-8"))

    def create_access_token(self, data: dict) -> str:
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)
        to_encode.update({"exp": expire})
        return jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)

    async def verify_token(self, token: str) -> dict:
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return payload
        except JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
            )


class TaskQueue:
    def __init__(self, redis_client):
        self.redis = redis_client
        self.queue_name = "agent_tasks"

    async def enqueue_task(self, task_data: dict, priority: TaskPriority = TaskPriority.NORMAL):
        priority_score = {
            TaskPriority.CRITICAL: 4,
            TaskPriority.HIGH: 3,
            TaskPriority.NORMAL: 2,
            TaskPriority.LOW: 1,
        }[priority]

        await self.redis.zadd(self.queue_name, {json.dumps(task_data): priority_score})

    async def dequeue_task(self) -> Optional[dict]:
        task_data = await self.redis.zpopmax(self.queue_name)
        if task_data:
            return json.loads(task_data[0][0])
        return None


class AgentManager:
    def __init__(self, db_session_factory, task_queue: TaskQueue):
        self.db_session_factory = db_session_factory
        self.task_queue = task_queue
        self.active_agents = {}

    async def register_agent(self, agent_data: dict) -> str:
        async with self.db_session_factory() as session:
            agent = Agent(**agent_data)
            session.add(agent)
            await session.commit()
            await session.refresh(agent)
            return agent.id

    async def assign_task_to_agent(self, task_id: str, agent_id: Optional[str] = None) -> str:
        async with self.db_session_factory() as session:
            # Get task
            task = await session.get(Task, task_id)
            if not task:
                raise HTTPException(status_code=404, detail="Task not found")

            # Find best agent if not specified
            if not agent_id:
                agent_id = await self._find_best_agent(task, session)

            if not agent_id:
                raise HTTPException(status_code=400, detail="No suitable agent available")

            # Assign task
            task.agent_id = agent_id
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.utcnow()

            await session.commit()

            # Add to task queue
            await self.task_queue.enqueue_task(
                {
                    "task_id": task_id,
                    "agent_id": agent_id,
                    "task_type": task.task_type,
                    "parameters": task.parameters,
                },
                TaskPriority(task.priority),
            )

            return agent_id

    async def _find_best_agent(self, task: Task, session: AsyncSession) -> Optional[str]:
        # Simple agent selection based on availability and capabilities
        result = await session.execute(
            select(Agent).where(
                Agent.status == AgentStatus.ACTIVE, Agent.capabilities.contains([task.task_type])
            )
        )
        agents = result.scalars().all()

        if agents:
            # Return first available agent (can be enhanced with load balancing)
            return agents[0].id
        return None


# =============================================================================
# METRICS & MONITORING
# =============================================================================

# Prometheus Metrics
REQUEST_COUNT = Counter(
    "http_requests_total", "Total HTTP requests", ["method", "endpoint", "status"]
)
REQUEST_DURATION = Histogram("http_request_duration_seconds", "HTTP request duration")
TASK_COUNT = Counter("tasks_total", "Total tasks", ["status", "type"])

# =============================================================================
# APPLICATION SETUP
# =============================================================================

# Global instances
db_manager = None
auth_service = None
task_queue = None
agent_manager = None
redis_client = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_manager, auth_service, task_queue, agent_manager, redis_client

    # Initialize services
    database_url = os.getenv("DATABASE_URL", "postgresql+asyncpg://user:pass@localhost/agentdb")
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
    jwt_secret = os.getenv("JWT_SECRET", "your-secret-key-change-in-production")

    # Setup database
    db_manager = DatabaseManager(database_url)
    await db_manager.create_tables()

    # Setup Redis
    redis_client = await aioredis.from_url(redis_url)

    # Initialize services
    auth_service = AuthService(jwt_secret)
    task_queue = TaskQueue(redis_client)
    agent_manager = AgentManager(db_manager.async_session, task_queue)

    # Start background task processor
    asyncio.create_task(process_tasks())

    logger.info("Agent Management System started")
    yield

    # Cleanup
    await redis_client.close()
    await db_manager.engine.dispose()


app = FastAPI(
    title="Agent Management System",
    description="Production-ready enterprise agent management platform",
    version="1.0.0",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    payload = await auth_service.verify_token(credentials.credentials)
    user_id = payload.get("sub")

    async with db_manager.async_session() as session:
        result = await session.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()

        if not user:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

        return user


# =============================================================================
# API ROUTES
# =============================================================================


@app.post("/auth/register", response_model=dict, status_code=201)
async def register(user_data: UserCreate):
    async with db_manager.async_session() as session:
        # Check if user exists
        result = await session.execute(
            select(User).where(
                (User.username == user_data.username) | (User.email == user_data.email)
            )
        )
        if result.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Username or email already registered")

        # Create user
        hashed_password = auth_service.hash_password(user_data.password)
        user = User(
            username=user_data.username, email=user_data.email, password_hash=hashed_password
        )

        session.add(user)
        await session.commit()
        await session.refresh(user)

        # Create access token
        access_token = auth_service.create_access_token(data={"sub": user.id})

        return {"access_token": access_token, "token_type": "bearer", "user_id": user.id}


@app.post("/auth/login")
async def login(username: str, password: str):
    async with db_manager.async_session() as session:
        result = await session.execute(select(User).where(User.username == username))
        user = result.scalar_one_or_none()

        if not user or not auth_service.verify_password(password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
            )

        access_token = auth_service.create_access_token(data={"sub": user.id})

        return {"access_token": access_token, "token_type": "bearer", "user_id": user.id}


@app.get("/users/me", response_model=UserResponse)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    return current_user


@app.post("/agents", response_model=dict, status_code=201)
async def create_agent(agent_data: AgentCreate, current_user: User = Depends(get_current_user)):
    async with db_manager.async_session() as session:
        agent = Agent(
            name=agent_data.name,
            description=agent_data.description,
            capabilities=agent_data.capabilities,
            config=agent_data.config,
            owner_id=current_user.id,
        )

        session.add(agent)
        await session.commit()
        await session.refresh(agent)

        return {"agent_id": agent.id, "status": "created"}


@app.get("/agents", response_model=List[AgentResponse])
async def list_agents(current_user: User = Depends(get_current_user)):
    async with db_manager.async_session() as session:
        result = await session.execute(select(Agent).where(Agent.owner_id == current_user.id))
        agents = result.scalars().all()
        return agents


@app.get("/agents/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: str, current_user: User = Depends(get_current_user)):
    async with db_manager.async_session() as session:
        agent = await session.get(Agent, agent_id)

        if not agent or agent.owner_id != current_user.id:
            raise HTTPException(status_code=404, detail="Agent not found")

        return agent


@app.post("/agents/{agent_id}/heartbeat")
async def agent_heartbeat(
    agent_id: str, status_data: dict, current_user: User = Depends(get_current_user)
):
    async with db_manager.async_session() as session:
        agent = await session.get(Agent, agent_id)

        if not agent or agent.owner_id != current_user.id:
            raise HTTPException(status_code=404, detail="Agent not found")

        agent.last_heartbeat = datetime.utcnow()
        agent.status = status_data.get("status", AgentStatus.ACTIVE)

        await session.commit()

        return {"status": "heartbeat_received"}


@app.post("/tasks", response_model=dict, status_code=201)
async def create_task(
    task_data: TaskCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
):
    async with db_manager.async_session() as session:
        task = Task(
            name=task_data.name,
            description=task_data.description,
            task_type=task_data.task_type,
            parameters=task_data.parameters,
            priority=task_data.priority,
            user_id=current_user.id,
            agent_id=task_data.agent_id,
        )

        session.add(task)
        await session.commit()
        await session.refresh(task)

        # Assign to agent and queue for processing
        background_tasks.add_task(agent_manager.assign_task_to_agent, task.id, task_data.agent_id)

        TASK_COUNT.labels(status="created", type=task.task_type).inc()

        return {"task_id": task.id, "status": "created"}


@app.get("/tasks", response_model=List[TaskResponse])
async def list_tasks(current_user: User = Depends(get_current_user)):
    async with db_manager.async_session() as session:
        result = await session.execute(
            select(Task).where(Task.user_id == current_user.id).order_by(Task.created_at.desc())
        )
        tasks = result.scalars().all()
        return tasks


@app.get("/tasks/{task_id}", response_model=TaskResponse)
async def get_task(task_id: str, current_user: User = Depends(get_current_user)):
    async with db_manager.async_session() as session:
        task = await session.get(Task, task_id)

        if not task or task.user_id != current_user.id:
            raise HTTPException(status_code=404, detail="Task not found")

        return task


@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat(), "version": "1.0.0"}


@app.get("/metrics")
async def get_metrics():
    from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


# =============================================================================
# BACKGROUND TASK PROCESSOR
# =============================================================================


async def process_tasks():
    """Background task processor"""
    logger.info("Task processor started")

    while True:
        try:
            task_data = await task_queue.dequeue_task()

            if task_data:
                logger.info(f"Processing task: {task_data['task_id']}")

                # Process the task (implement your task processing logic here)
                await process_single_task(task_data)
            else:
                # No tasks, wait a bit
                await asyncio.sleep(1)

        except Exception as e:
            logger.error(f"Task processing error: {e}")
            await asyncio.sleep(5)


async def process_single_task(task_data: dict):
    """Process a single task"""
    task_id = task_data["task_id"]

    async with db_manager.async_session() as session:
        task = await session.get(Task, task_id)

        if not task:
            logger.error(f"Task {task_id} not found")
            return

        try:
            # Simulate task processing
            logger.info(f"Processing task {task_id} of type {task.task_type}")

            # Here you would implement actual task processing logic
            # For demo purposes, we'll simulate some work
            await asyncio.sleep(2)

            # Mark task as completed
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            task.result = {"status": "success", "message": "Task completed successfully"}

            TASK_COUNT.labels(status="completed", type=task.task_type).inc()

        except Exception as e:
            logger.error(f"Task {task_id} failed: {e}")
            task.status = TaskStatus.FAILED
            task.error_message = str(e)
            task.completed_at = datetime.utcnow()

            TASK_COUNT.labels(status="failed", type=task.task_type).inc()

        await session.commit()


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    # Use environment variable for host, default to localhost for security
    # Only bind to 0.0.0.0 in production with proper firewall rules
    host = os.getenv("API_HOST", "127.0.0.1")  # Default to localhost
    port = int(os.getenv("API_PORT", "8000"))

    uvicorn.run("main:app", host=host, port=port, reload=True, log_level="info")
