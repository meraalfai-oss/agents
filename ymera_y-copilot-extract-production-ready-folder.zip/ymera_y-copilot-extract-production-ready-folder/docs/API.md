# YMERA Platform API Documentation

## Overview

The YMERA Platform provides a comprehensive REST API for managing agents, tasks, users, and system operations. This document provides complete API documentation including endpoints, request/response formats, authentication, and examples.

## Base URL

```
Production: https://api.ymera.com/v1
Development: http://localhost:8000/api/v1
```

## Authentication

All API requests require authentication using JWT (JSON Web Tokens) in the Authorization header.

### Authentication Flow

1. **Login**: POST `/auth/login` with credentials
2. **Receive Token**: Get JWT access token in response
3. **Use Token**: Include token in subsequent requests

### Headers

```http
Authorization: Bearer <your_jwt_token>
Content-Type: application/json
```

### Example

```bash
curl -X POST https://api.ymera.com/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "user@example.com", "password": "your_password"}'
```

Response:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

---

## Endpoints

### Authentication

#### POST /auth/login
Authenticate user and receive access token.

**Request Body:**
```json
{
  "username": "user@example.com",
  "password": "your_password"
}
```

**Response (200 OK):**
```json
{
  "access_token": "eyJhbGc...",
  "token_type": "bearer",
  "expires_in": 3600,
  "user": {
    "id": "user_123",
    "username": "user@example.com",
    "email": "user@example.com"
  }
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid credentials
- `422 Validation Error`: Invalid request format

---

#### POST /auth/register
Register a new user account.

**Request Body:**
```json
{
  "username": "newuser",
  "email": "newuser@example.com",
  "password": "SecurePass123!",
  "first_name": "John",
  "last_name": "Doe"
}
```

**Response (201 Created):**
```json
{
  "id": "user_456",
  "username": "newuser",
  "email": "newuser@example.com",
  "created_at": "2024-01-01T00:00:00Z"
}
```

---

#### POST /auth/refresh
Refresh an expired access token.

**Request Body:**
```json
{
  "refresh_token": "your_refresh_token"
}
```

**Response (200 OK):**
```json
{
  "access_token": "new_access_token",
  "token_type": "bearer",
  "expires_in": 3600
}
```

---

### Agents

#### GET /agents
List all agents in the system.

**Query Parameters:**
- `status` (optional): Filter by status (active, idle, busy, error)
- `type` (optional): Filter by agent type
- `page` (optional): Page number (default: 1)
- `per_page` (optional): Items per page (default: 20, max: 100)

**Response (200 OK):**
```json
{
  "agents": [
    {
      "id": "agent_123",
      "name": "Data Processor Agent",
      "type": "processor",
      "status": "active",
      "version": "1.0.0",
      "capabilities": ["data_processing", "validation"],
      "created_at": "2024-01-01T00:00:00Z",
      "last_active": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "per_page": 20,
    "total": 50,
    "pages": 3
  }
}
```

---

#### GET /agents/{agent_id}
Get details of a specific agent.

**Path Parameters:**
- `agent_id`: Unique agent identifier

**Response (200 OK):**
```json
{
  "id": "agent_123",
  "name": "Data Processor Agent",
  "type": "processor",
  "status": "active",
  "version": "1.0.0",
  "capabilities": ["data_processing", "validation"],
  "configuration": {
    "max_concurrent_tasks": 5,
    "timeout": 30
  },
  "metrics": {
    "tasks_completed": 1250,
    "tasks_failed": 15,
    "average_processing_time": 2.5,
    "success_rate": 98.8
  },
  "created_at": "2024-01-01T00:00:00Z",
  "last_active": "2024-01-15T10:30:00Z"
}
```

**Error Responses:**
- `404 Not Found`: Agent not found

---

#### POST /agents
Create a new agent.

**Request Body:**
```json
{
  "name": "New Agent",
  "type": "processor",
  "description": "Agent description",
  "capabilities": ["capability1", "capability2"],
  "configuration": {
    "max_concurrent_tasks": 5,
    "timeout": 30
  }
}
```

**Response (201 Created):**
```json
{
  "id": "agent_456",
  "name": "New Agent",
  "type": "processor",
  "status": "idle",
  "created_at": "2024-01-15T10:30:00Z"
}
```

---

#### PUT /agents/{agent_id}
Update an existing agent.

**Request Body:**
```json
{
  "name": "Updated Agent Name",
  "configuration": {
    "max_concurrent_tasks": 10
  }
}
```

**Response (200 OK):**
```json
{
  "id": "agent_123",
  "name": "Updated Agent Name",
  "status": "active",
  "updated_at": "2024-01-15T10:35:00Z"
}
```

---

#### DELETE /agents/{agent_id}
Delete an agent.

**Response (204 No Content)**

---

#### POST /agents/{agent_id}/start
Start an agent.

**Response (200 OK):**
```json
{
  "id": "agent_123",
  "status": "active",
  "message": "Agent started successfully"
}
```

---

#### POST /agents/{agent_id}/stop
Stop an agent.

**Response (200 OK):**
```json
{
  "id": "agent_123",
  "status": "stopped",
  "message": "Agent stopped successfully"
}
```

---

### Tasks

#### GET /tasks
List all tasks.

**Query Parameters:**
- `status` (optional): Filter by status (pending, running, completed, failed)
- `agent_id` (optional): Filter by agent
- `priority` (optional): Filter by priority (low, medium, high, critical)
- `page` (optional): Page number
- `per_page` (optional): Items per page

**Response (200 OK):**
```json
{
  "tasks": [
    {
      "id": "task_123",
      "type": "data_processing",
      "status": "completed",
      "priority": "high",
      "agent_id": "agent_123",
      "created_at": "2024-01-15T10:00:00Z",
      "completed_at": "2024-01-15T10:05:00Z",
      "duration": 300
    }
  ],
  "pagination": {
    "page": 1,
    "per_page": 20,
    "total": 150,
    "pages": 8
  }
}
```

---

#### GET /tasks/{task_id}
Get details of a specific task.

**Response (200 OK):**
```json
{
  "id": "task_123",
  "type": "data_processing",
  "status": "completed",
  "priority": "high",
  "agent_id": "agent_123",
  "input": {
    "data": "input_data"
  },
  "output": {
    "result": "processed_data"
  },
  "created_at": "2024-01-15T10:00:00Z",
  "started_at": "2024-01-15T10:00:05Z",
  "completed_at": "2024-01-15T10:05:00Z",
  "duration": 295
}
```

---

#### POST /tasks
Create a new task.

**Request Body:**
```json
{
  "type": "data_processing",
  "priority": "high",
  "agent_id": "agent_123",
  "input": {
    "data": "input_data"
  },
  "timeout": 300
}
```

**Response (201 Created):**
```json
{
  "id": "task_456",
  "type": "data_processing",
  "status": "pending",
  "priority": "high",
  "created_at": "2024-01-15T10:30:00Z"
}
```

---

#### DELETE /tasks/{task_id}
Cancel a task.

**Response (200 OK):**
```json
{
  "id": "task_123",
  "status": "cancelled",
  "message": "Task cancelled successfully"
}
```

---

### System

#### GET /health
Health check endpoint.

**Response (200 OK):**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00Z",
  "services": {
    "database": "healthy",
    "cache": "healthy",
    "agents": "healthy"
  }
}
```

---

#### GET /metrics
Get system metrics.

**Response (200 OK):**
```json
{
  "agents": {
    "total": 50,
    "active": 45,
    "idle": 5
  },
  "tasks": {
    "total": 10000,
    "completed": 9500,
    "failed": 100,
    "pending": 400
  },
  "performance": {
    "average_response_time": 125.5,
    "requests_per_second": 450,
    "cpu_usage": 45.2,
    "memory_usage": 2048
  }
}
```

---

## Error Responses

All errors follow a consistent format:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable error message",
    "details": {
      "field": "additional error details"
    }
  }
}
```

### Common Error Codes

- `400 Bad Request`: Invalid request format
- `401 Unauthorized`: Missing or invalid authentication
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `422 Validation Error`: Request validation failed
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server error

---

## Rate Limiting

API requests are rate-limited to ensure system stability:

- **Default**: 1000 requests per hour per user
- **Burst**: Up to 100 requests per minute

Rate limit headers are included in all responses:

```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 950
X-RateLimit-Reset: 1609459200
```

---

## Pagination

List endpoints support pagination:

**Query Parameters:**
- `page`: Page number (starts at 1)
- `per_page`: Items per page (default: 20, max: 100)

**Response Format:**
```json
{
  "data": [...],
  "pagination": {
    "page": 1,
    "per_page": 20,
    "total": 100,
    "pages": 5
  }
}
```

---

## Webhooks

Configure webhooks to receive real-time notifications:

### Events

- `agent.created`: New agent created
- `agent.started`: Agent started
- `agent.stopped`: Agent stopped
- `task.created`: New task created
- `task.completed`: Task completed
- `task.failed`: Task failed

### Webhook Payload

```json
{
  "event": "task.completed",
  "timestamp": "2024-01-15T10:30:00Z",
  "data": {
    "task_id": "task_123",
    "status": "completed",
    "duration": 300
  }
}
```

---

## SDKs and Client Libraries

Official SDKs available:

- **Python**: `pip install ymera-sdk`
- **JavaScript/Node.js**: `npm install @ymera/sdk`
- **Go**: `go get github.com/ymera/go-sdk`

### Python Example

```python
from ymera import YmeraClient

client = YmeraClient(api_key="your_api_key")

# List agents
agents = client.agents.list(status="active")

# Create task
task = client.tasks.create(
    type="data_processing",
    agent_id="agent_123",
    input={"data": "test"}
)
```

---

## Support

- **Documentation**: https://docs.ymera.com
- **API Status**: https://status.ymera.com
- **Support Email**: support@ymera.com
- **GitHub Issues**: https://github.com/ymera/ymera_y/issues

---

## Changelog

### Version 1.0.0 (2024-01-15)
- Initial API release
- Agent management endpoints
- Task management endpoints
- Authentication and authorization
- Rate limiting and pagination
