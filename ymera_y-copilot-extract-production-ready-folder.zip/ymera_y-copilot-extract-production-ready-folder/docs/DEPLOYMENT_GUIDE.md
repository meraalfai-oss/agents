# YMERA Platform Deployment Guide

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Configuration](#configuration)
4. [Deployment Methods](#deployment-methods)
5. [Database Setup](#database-setup)
6. [Monitoring](#monitoring)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### System Requirements

- **OS**: Linux (Ubuntu 20.04+, CentOS 8+) or Docker
- **Python**: 3.9 or higher
- **Memory**: Minimum 4GB RAM (8GB recommended)
- **CPU**: 2+ cores (4+ cores recommended)
- **Storage**: 20GB+ available space

### Required Software

- Python 3.9+
- PostgreSQL 13+ or SQLite
- Redis 6+
- Git
- Docker & Docker Compose (for containerized deployment)

---

## Environment Setup

### 1. Clone Repository

```bash
git clone https://github.com/ymera-mfm/ymera_y.git
cd ymera_y
```

### 2. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Environment Variables

Create `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# Application
APP_ENV=production
SECRET_KEY=your-secret-key-here-change-in-production
DEBUG=false

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/ymera
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=10

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_MAX_CONNECTIONS=50

# API
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4
CORS_ORIGINS=https://yourdomain.com

# Authentication
JWT_SECRET_KEY=your-jwt-secret-key-change-in-production
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Monitoring
ENABLE_METRICS=true
PROMETHEUS_PORT=9090

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
```

---

## Configuration

### Database Configuration

#### PostgreSQL (Recommended for Production)

```yaml
# config/database.yaml
database:
  type: postgresql
  host: localhost
  port: 5432
  database: ymera
  user: ymera_user
  password: ${DB_PASSWORD}
  pool_size: 20
  max_overflow: 10
  echo: false
```

#### SQLite (Development Only)

```yaml
database:
  type: sqlite
  path: ./ymera.db
```

### Redis Configuration

```yaml
# config/redis.yaml
redis:
  host: localhost
  port: 6379
  db: 0
  password: ${REDIS_PASSWORD}
  max_connections: 50
  socket_timeout: 5
```

### Application Configuration

```yaml
# config/app.yaml
application:
  name: YMERA Platform
  version: 1.0.0
  environment: production
  
  api:
    host: 0.0.0.0
    port: 8000
    workers: 4
    reload: false
    
  cors:
    origins:
      - https://yourdomain.com
    allow_credentials: true
    allow_methods: ["GET", "POST", "PUT", "DELETE"]
    
  rate_limiting:
    enabled: true
    requests_per_hour: 1000
    burst_limit: 100
```

---

## Deployment Methods

### Method 1: Docker Deployment (Recommended)

#### 1. Build Docker Image

```bash
docker build -t ymera:latest .
```

#### 2. Docker Compose Deployment

```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    image: ymera:latest
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/ymera
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - db
      - redis
    restart: unless-stopped

  db:
    image: postgres:14
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_DB=ymera
      - POSTGRES_USER=ymera
      - POSTGRES_PASSWORD=secure_password
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
```

#### 3. Start Services

```bash
docker-compose up -d
```

---

### Method 2: Manual Deployment

#### 1. Setup Database

```bash
# PostgreSQL
sudo -u postgres psql
CREATE DATABASE ymera;
CREATE USER ymera WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE ymera TO ymera;
\q
```

#### 2. Run Database Migrations

```bash
alembic upgrade head
```

#### 3. Start Application

Using Gunicorn (production):

```bash
gunicorn main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --access-logfile - \
  --error-logfile -
```

Using Uvicorn (development):

```bash
uvicorn main:app \
  --host 0.0.0.0 \
  --port 8000 \
  --workers 4
```

#### 4. Setup Systemd Service

Create `/etc/systemd/system/ymera.service`:

```ini
[Unit]
Description=YMERA Platform
After=network.target postgresql.service redis.service

[Service]
Type=notify
User=ymera
WorkingDirectory=/opt/ymera
Environment="PATH=/opt/ymera/venv/bin"
ExecStart=/opt/ymera/venv/bin/gunicorn main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable ymera
sudo systemctl start ymera
```

---

### Method 3: Kubernetes Deployment

#### 1. Create Namespace

```bash
kubectl create namespace ymera
```

#### 2. Deploy Application

```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ymera-app
  namespace: ymera
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ymera
  template:
    metadata:
      labels:
        app: ymera
    spec:
      containers:
      - name: ymera
        image: ymera:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: ymera-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: ymera-secrets
              key: redis-url
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
```

#### 3. Deploy Service

```yaml
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: ymera-service
  namespace: ymera
spec:
  selector:
    app: ymera
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: LoadBalancer
```

#### 4. Apply Configuration

```bash
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

---

## Database Setup

### Initialize Database

```bash
# Run migrations
alembic upgrade head

# Seed initial data
python scripts/seed_data.py
```

### Backup Strategy

#### Automated Backups

```bash
# Setup cron job for daily backups
0 2 * * * /opt/ymera/scripts/backup.sh
```

Backup script:

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/opt/ymera/backups"

# PostgreSQL backup
pg_dump -U ymera ymera > "$BACKUP_DIR/ymera_$DATE.sql"

# Compress
gzip "$BACKUP_DIR/ymera_$DATE.sql"

# Keep last 30 days
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +30 -delete
```

---

## Monitoring

### Prometheus Metrics

Access metrics at: `http://your-server:9090/metrics`

### Health Checks

```bash
# Basic health check
curl http://your-server:8000/health

# Detailed system status
curl http://your-server:8000/api/v1/system/status
```

### Logging

Logs are written to:
- Application logs: `/var/log/ymera/app.log`
- Access logs: `/var/log/ymera/access.log`
- Error logs: `/var/log/ymera/error.log`

View logs:

```bash
# Follow application logs
tail -f /var/log/ymera/app.log

# Using systemd
journalctl -u ymera -f
```

---

## Troubleshooting

### Common Issues

#### Database Connection Issues

```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test connection
psql -U ymera -d ymera -h localhost
```

#### Redis Connection Issues

```bash
# Check Redis status
sudo systemctl status redis

# Test connection
redis-cli ping
```

#### Application Won't Start

```bash
# Check logs
journalctl -u ymera -n 100

# Verify configuration
python -c "from core.config import Settings; print(Settings())"

# Check dependencies
pip list | grep -E "fastapi|sqlalchemy|redis"
```

### Performance Issues

#### High Memory Usage

```bash
# Check memory usage
free -h

# Monitor application memory
ps aux | grep python | grep ymera
```

#### High CPU Usage

```bash
# Check CPU usage
top -p $(pgrep -f "ymera")

# Adjust worker count in configuration
```

### Database Performance

```bash
# Check slow queries
psql -U ymera -d ymera -c "SELECT * FROM pg_stat_statements ORDER BY total_time DESC LIMIT 10;"

# Analyze database
psql -U ymera -d ymera -c "VACUUM ANALYZE;"
```

---

## Security Checklist

- [ ] Change all default passwords
- [ ] Use strong SECRET_KEY and JWT_SECRET_KEY
- [ ] Enable HTTPS with valid SSL certificates
- [ ] Configure firewall rules
- [ ] Set up fail2ban for SSH protection
- [ ] Enable database encryption at rest
- [ ] Configure Redis password authentication
- [ ] Set up regular backups
- [ ] Enable audit logging
- [ ] Implement rate limiting
- [ ] Keep dependencies updated
- [ ] Use least privilege principle for database users

---

## Maintenance

### Updates

```bash
# Pull latest code
git pull origin main

# Update dependencies
pip install -r requirements.txt --upgrade

# Run migrations
alembic upgrade head

# Restart service
sudo systemctl restart ymera
```

### Database Maintenance

```bash
# Vacuum database (weekly)
psql -U ymera -d ymera -c "VACUUM ANALYZE;"

# Reindex (monthly)
psql -U ymera -d ymera -c "REINDEX DATABASE ymera;"
```

---

## Support

For deployment assistance:

- **Documentation**: https://docs.ymera.com/deployment
- **Community**: https://community.ymera.com
- **Email**: support@ymera.com
- **GitHub Issues**: https://github.com/ymera-mfm/ymera_y/issues

---

## Next Steps

After successful deployment:

1. Configure monitoring and alerts
2. Set up automated backups
3. Configure log rotation
4. Set up CI/CD pipeline
5. Perform load testing
6. Create disaster recovery plan

---

*Last updated: January 2024*
