# YMERA Platform Developer Guide

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Development Setup](#development-setup)
3. [Project Structure](#project-structure)
4. [Development Workflow](#development-workflow)
5. [Testing Guide](#testing-guide)
6. [Contributing Guidelines](#contributing-guidelines)
7. [Best Practices](#best-practices)

---

## Architecture Overview

### High-Level Architecture

```
┌─────────────────────────────────────────────────┐
│              Client Applications                 │
│     (Web, Mobile, CLI, External Systems)        │
└────────────────┬────────────────────────────────┘
                 │
                 │ HTTPS/REST API
                 │
┌────────────────▼────────────────────────────────┐
│           API Gateway (FastAPI)                  │
│  ┌──────────┬─────────┬──────────┬───────────┐ │
│  │  Auth    │ Agents  │  Tasks   │  Metrics  │ │
│  │ Middleware│   API   │   API    │    API    │ │
│  └──────────┴─────────┴──────────┴───────────┘ │
└────────────────┬────────────────────────────────┘
                 │
      ┌──────────┼──────────┐
      │          │          │
┌─────▼─────┐  ┌─▼────────┐ ┌▼──────────┐
│   Agent   │  │   Task   │ │  Cache    │
│ Registry  │  │  Queue   │ │  (Redis)  │
└─────┬─────┘  └──────────┘ └───────────┘
      │
┌─────▼──────────────────────────────────────────┐
│           Agent System Layer                    │
│  ┌──────────┬──────────┬──────────┬─────────┐ │
│  │  Base    │ Processor│ Analytics│  Custom │ │
│  │  Agent   │  Agent   │  Agent   │  Agents │ │
│  └──────────┴──────────┴──────────┴─────────┘ │
└────────────────┬───────────────────────────────┘
                 │
┌────────────────▼────────────────────────────────┐
│         Data Layer (PostgreSQL)                  │
│    Tables: users, agents, tasks, metrics        │
└─────────────────────────────────────────────────┘
```

### Core Components

#### 1. API Gateway (`main.py`)
- FastAPI application
- Request routing and validation
- Authentication middleware
- CORS configuration
- Rate limiting

#### 2. Agent System
- **BaseAgent**: Core agent functionality
- **Agent Registry**: Agent registration and discovery
- **Agent Lifecycle**: Start, stop, health checks
- **Task Processing**: Async task execution

#### 3. Data Layer
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Cache**: Redis for session and data caching
- **Message Queue**: For async task processing

#### 4. Monitoring
- Prometheus metrics
- Structured logging
- Health checks
- Performance tracking

---

## Development Setup

### 1. Prerequisites

```bash
# Install Python 3.9+
python3 --version

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib

# Install Redis
sudo apt install redis-server

# Install Git
sudo apt install git
```

### 2. Clone and Setup

```bash
# Clone repository
git clone https://github.com/ymera-mfm/ymera_y.git
cd ymera_y

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install development dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt  # If available

# Setup pre-commit hooks
pip install pre-commit
pre-commit install
```

### 3. Database Setup

```bash
# Create database
createdb ymera_dev

# Run migrations
alembic upgrade head

# Seed test data (optional)
python scripts/seed_test_data.py
```

### 4. Configuration

```bash
# Copy environment template
cp .env.example .env.dev

# Edit configuration
nano .env.dev
```

Development configuration:

```env
APP_ENV=development
DEBUG=true
DATABASE_URL=postgresql://localhost/ymera_dev
REDIS_URL=redis://localhost:6379/0
LOG_LEVEL=DEBUG
```

### 5. Run Development Server

```bash
# With auto-reload
uvicorn main:app --reload --port 8000

# Or using the Makefile
make dev
```

---

## Project Structure

```
ymera_y/
├── api/                      # API endpoints
│   ├── __init__.py
│   └── gateway.py
├── agents/                   # Agent implementations
│   ├── __init__.py
│   ├── agent_base.py        # Base agent class
│   ├── calculator_agent.py  # Example agent
│   └── data_processor_agent.py
├── core/                     # Core functionality
│   ├── __init__.py
│   ├── auth.py              # Authentication
│   ├── config.py            # Configuration
│   ├── database.py          # Database connection
│   ├── metrics.py           # Metrics collection
│   └── resilience.py        # Error handling
├── tests/                    # Test suite
│   ├── unit/                # Unit tests
│   ├── integration/         # Integration tests
│   ├── security/            # Security tests
│   └── agents/              # Agent tests
├── docs/                     # Documentation
│   ├── API.md
│   ├── DEPLOYMENT_GUIDE.md
│   └── DEVELOPER_GUIDE.md
├── migrations/               # Database migrations
│   └── versions/
├── scripts/                  # Utility scripts
│   ├── seed_data.py
│   └── backup.sh
├── main.py                   # Application entry point
├── requirements.txt          # Dependencies
├── pytest.ini               # Test configuration
├── pyproject.toml           # Project metadata
├── .env.example             # Environment template
└── README.md                # Project readme
```

---

## Development Workflow

### 1. Creating a New Feature

```bash
# Create feature branch
git checkout -b feature/my-new-feature

# Make changes
# ... code changes ...

# Run tests
pytest tests/

# Run linters
black .
isort .
flake8 .

# Commit changes
git add .
git commit -m "Add: New feature description"

# Push to GitHub
git push origin feature/my-new-feature
```

### 2. Creating a New Agent

```python
# agents/my_agent.py

from base_agent import BaseAgent, AgentStatus, TaskStatus

class MyCustomAgent(BaseAgent):
    """
    Custom agent for specific tasks
    """
    
    def __init__(self, agent_id: str, name: str):
        super().__init__(agent_id, name)
        self.agent_type = "custom"
    
    async def process_task(self, task: dict) -> dict:
        """
        Process a task
        
        Args:
            task: Task data dictionary
            
        Returns:
            Result dictionary
        """
        try:
            # Your processing logic here
            result = self._process(task)
            
            return {
                "status": TaskStatus.COMPLETED,
                "result": result
            }
        except Exception as e:
            self.logger.error(f"Task processing failed: {e}")
            return {
                "status": TaskStatus.FAILED,
                "error": str(e)
            }
    
    def _process(self, task: dict) -> dict:
        """Internal processing logic"""
        # Implementation here
        pass
    
    async def health_check(self) -> dict:
        """Check agent health"""
        return {
            "status": "healthy",
            "agent_id": self.agent_id,
            "agent_type": self.agent_type
        }
```

### 3. Adding API Endpoints

```python
# In main.py or api/routes.py

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

router = APIRouter()

class MyRequest(BaseModel):
    data: str
    
class MyResponse(BaseModel):
    result: str

@router.post("/api/v1/my-endpoint", response_model=MyResponse)
async def my_endpoint(
    request: MyRequest,
    current_user = Depends(get_current_user)
):
    """
    My custom endpoint
    
    Args:
        request: Request data
        current_user: Authenticated user
        
    Returns:
        Response data
    """
    try:
        # Process request
        result = process_data(request.data)
        
        return MyResponse(result=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

---

## Testing Guide

### Running Tests

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/unit/test_auth.py

# Run with coverage
pytest --cov=. --cov-report=html

# Run tests in parallel
pytest -n auto

# Run only unit tests
pytest tests/unit/

# Run with verbose output
pytest -v
```

### Writing Tests

#### Unit Test Example

```python
# tests/unit/test_my_agent.py

import pytest
from agents.my_agent import MyCustomAgent

class TestMyCustomAgent:
    
    @pytest.fixture
    def agent(self):
        """Create agent instance"""
        return MyCustomAgent(
            agent_id="test_123",
            name="TestAgent"
        )
    
    @pytest.mark.asyncio
    async def test_process_task(self, agent):
        """Test task processing"""
        task = {"type": "test", "data": "test_data"}
        
        result = await agent.process_task(task)
        
        assert result["status"] == "completed"
        assert "result" in result
    
    @pytest.mark.asyncio
    async def test_health_check(self, agent):
        """Test health check"""
        health = await agent.health_check()
        
        assert health["status"] == "healthy"
        assert health["agent_id"] == "test_123"
```

#### Integration Test Example

```python
# tests/integration/test_api_integration.py

import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

class TestAPIIntegration:
    
    def test_create_and_get_agent(self):
        """Test creating and retrieving agent"""
        # Create agent
        response = client.post(
            "/api/v1/agents",
            json={"name": "TestAgent", "type": "processor"}
        )
        assert response.status_code == 201
        agent_id = response.json()["id"]
        
        # Get agent
        response = client.get(f"/api/v1/agents/{agent_id}")
        assert response.status_code == 200
        assert response.json()["name"] == "TestAgent"
```

---

## Contributing Guidelines

### Code Style

- Follow PEP 8 guidelines
- Use type hints for function parameters and returns
- Write docstrings for all public functions and classes
- Maximum line length: 100 characters

### Commit Messages

Format: `<type>: <description>`

Types:
- `Add`: New feature
- `Fix`: Bug fix
- `Docs`: Documentation changes
- `Test`: Test additions/changes
- `Refactor`: Code refactoring
- `Perf`: Performance improvements

Example:
```
Add: Support for custom agent types
Fix: Database connection pool leak
Docs: Update API documentation
```

### Pull Request Process

1. Create feature branch from `main`
2. Make changes and write tests
3. Ensure all tests pass
4. Update documentation
5. Create pull request
6. Address review feedback
7. Merge after approval

---

## Best Practices

### 1. Error Handling

```python
import logging
from core.resilience import with_retry, CircuitBreaker

logger = logging.getLogger(__name__)

@with_retry(max_attempts=3, backoff=2.0)
async def risky_operation():
    """Operation that might fail"""
    try:
        result = await external_api_call()
        return result
    except Exception as e:
        logger.error(f"Operation failed: {e}")
        raise
```

### 2. Async/Await

```python
import asyncio

async def fetch_data():
    """Always use async for I/O operations"""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()
```

### 3. Logging

```python
import logging
import structlog

# Use structured logging
logger = structlog.get_logger()

logger.info("agent_started", agent_id=agent.id, agent_type=agent.type)
logger.error("task_failed", task_id=task.id, error=str(e))
```

### 4. Configuration

```python
from core.config import Settings

# Use configuration objects
settings = Settings()

# Don't hardcode values
DATABASE_URL = settings.database.url  # Good
DATABASE_URL = "postgresql://..."     # Bad
```

### 5. Type Hints

```python
from typing import List, Dict, Optional

def process_items(
    items: List[str],
    config: Dict[str, any],
    timeout: Optional[int] = None
) -> List[Dict[str, any]]:
    """Always use type hints"""
    pass
```

---

## Tools and Utilities

### Code Formatting

```bash
# Format code with Black
black .

# Sort imports
isort .

# Check code style
flake8 .
```

### Database Migrations

```bash
# Create migration
alembic revision --autogenerate -m "Add new table"

# Apply migrations
alembic upgrade head

# Rollback migration
alembic downgrade -1
```

### Performance Profiling

```python
# Profile code execution
import cProfile
import pstats

profiler = cProfile.Profile()
profiler.enable()

# Your code here

profiler.disable()
stats = pstats.Stats(profiler)
stats.sort_stats('cumtime')
stats.print_stats(10)
```

---

## Resources

### Documentation
- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [SQLAlchemy Docs](https://docs.sqlalchemy.org/)
- [Pytest Docs](https://docs.pytest.org/)

### Community
- GitHub Discussions
- Slack Channel: #ymera-dev
- Email: dev@ymera.com

---

*Last updated: January 2024*
