# deployment-scripts.sh - Complete deployment automation

#!/bin/bash

# Production Deployment Script
set -e

echo "🚀 Starting YMERA Agent Management System Deployment"

# Environment setup
export DATABASE_URL="postgresql+asyncpg://agent_user:${DB_PASSWORD}@postgres:5432/agent_db"
export REDIS_URL="redis://redis:6379"
export JWT_SECRET="${JWT_SECRET:-$(openssl rand -base64 32)}"
export ENVIRONMENT="production"

# Create necessary directories
mkdir -p logs ssl grafana/provisioning/{dashboards,datasources}

# Generate SSL certificates (self-signed for development)
if [ ! -f ssl/server.crt ]; then
    echo "📋 Generating SSL certificates..."
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout ssl/server.key \
        -out ssl/server.crt \
        -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"
fi

# Create Grafana datasource configuration
cat > grafana/provisioning/datasources/prometheus.yml << EOF
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true
EOF

# Create Grafana dashboard configuration
cat > grafana/provisioning/dashboards/dashboard.yml << EOF
apiVersion: 1

providers:
  - name: 'default'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /etc/grafana/provisioning/dashboards
EOF

# Create comprehensive Grafana dashboard
cat > grafana/provisioning/dashboards/agent-system-dashboard.json << 'EOF'
{
  "dashboard": {
    "id": null,
    "title": "Agent Management System",
    "tags": ["agent-system"],
    "timezone": "browser",
    "panels": [
      {
        "title": "API Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ],
        "gridPos": {"h": 8, "w": 12, "x": 0, "y": 0}
      },
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th percentile"
          }
        ],
        "gridPos": {"h": 8, "w": 12, "x": 12, "y": 0}
      },
      {
        "title": "Active WebSocket Connections",
        "type": "singlestat",
        "targets": [
          {
            "expr": "websocket_connections_active",
            "legendFormat": "Connections"
          }
        ],
        "gridPos": {"h": 4, "w": 6, "x": 0, "y": 8}
      },
      {
        "title": "Task Processing Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(tasks_total[5m])",
            "legendFormat": "{{status}}"
          }
        ],
        "gridPos": {"h": 8, "w": 18, "x": 6, "y": 8}
      }
    ],
    "time": {
      "from": "now-1h",
      "to": "now"
    },
    "refresh": "5s"
  }
}
EOF

# Database migration script
cat > migrate.py << 'EOF'
#!/usr/bin/env python3
"""Database migration script"""

import asyncio
import asyncpg
import os
from sqlalchemy.ext.asyncio import create_async_engine
from main import Base

async def migrate():
    """Run database migrations"""
    database_url = os.getenv("DATABASE_URL")
    
    engine = create_async_engine(database_url)
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        print("✅ Database tables created successfully")
    
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(migrate())
EOF

chmod +x migrate.py

# Health check script
cat > health-check.py << 'EOF'
#!/usr/bin/env python3
"""Health check script for deployment validation"""

import asyncio
import aiohttp
import sys
import os

async def check_health():
    """Check system health"""
    base_url = os.getenv("BASE_URL", "http://localhost:8000")
    
    async with aiohttp.ClientSession() as session:
        try:
            # Check main health endpoint
            async with session.get(f"{base_url}/health") as resp:
                if resp.status != 200:
                    print(f"❌ Health check failed: {resp.status}")
                    return False
                
                data = await resp.json()
                print(f"✅ Health check passed: {data['status']}")
            
            # Check metrics endpoint
            async with session.get(f"{base_url}/metrics") as resp:
                if resp.status != 200:
                    print("⚠️  Metrics endpoint not accessible")
                else:
                    print("✅ Metrics endpoint accessible")
            
            # Check detailed health
            async with session.get(f"{base_url}/monitoring/health") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"✅ Detailed health: {data['status']}")
                    
                    for component, status in data.get('components', {}).items():
                        if 'unhealthy' in status:
                            print(f"❌ Component {component}: {status}")
                            return False
                        else:
                            print(f"✅ Component {component}: {status}")
                
            return True
            
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return False

if __name__ == "__main__":
    result = asyncio.run(check_health())
    sys.exit(0 if result else 1)
EOF

chmod +x health-check.py

# Load testing script
cat > load-test.py << 'EOF'
#!/usr/bin/env python3
"""Simple load testing script"""

import asyncio
import aiohttp
import time
import statistics

async def run_load_test():
    """Run basic load test"""
    base_url = "http://localhost:8000"
    concurrent_requests = 50
    total_requests = 1000
    
    async def make_request(session):
        start = time.time()
        try:
            async with session.get(f"{base_url}/health") as resp:
                await resp.json()
                return time.time() - start, resp.status
        except Exception as e:
            return time.time() - start, 0
    
    print(f"🔥 Starting load test: {total_requests} requests, {concurrent_requests} concurrent")
    
    async with aiohttp.ClientSession() as session:
        semaphore = asyncio.Semaphore(concurrent_requests)
        
        async def bounded_request():
            async with semaphore:
                return await make_request(session)
        
        start_time = time.time()
        results = await asyncio.gather(*[bounded_request() for _ in range(total_requests)])
        total_time = time.time() - start_time
        
        response_times = [r[0] for r in results]
        status_codes = [r[1] for r in results]
        
        success_count = sum(1 for code in status_codes if code == 200)
        
        print(f"📊 Load test results:")
        print(f"  Total time: {total_time:.2f}s")
        print(f"  Requests/sec: {total_requests/total_time:.2f}")
        print(f"  Success rate: {success_count/total_requests*100:.1f}%")
        print(f"  Avg response time: {statistics.mean(response_times)*1000:.1f}ms")
        print(f"  P95 response time: {sorted(response_times)[int(len(response_times)*0.95)]*1000:.1f}ms")

if __name__ == "__main__":
    asyncio.run(run_load_test())
EOF

chmod +x load-test.py

# Backup script
cat > backup.sh << 'EOF'
#!/bin/bash
"""Database backup script"""

set -e

BACKUP_DIR="backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_CONTAINER="agent-system_postgres_1"

mkdir -p $BACKUP_DIR

echo "📦 Creating database backup..."

docker exec $DB_CONTAINER pg_dump -U agent_user -d agent_db | gzip > "$BACKUP_DIR/backup_$DATE.sql.gz"

echo "✅ Backup created: $BACKUP_DIR/backup_$DATE.sql.gz"

# Keep only last 7 backups
ls -t $BACKUP_DIR/backup_*.sql.gz | tail -n +8 | xargs -r rm

echo "🧹 Old backups cleaned up"
EOF

chmod +x backup.sh

# Monitoring script
cat > monitor.py << 'EOF'
#!/usr/bin/env python3
"""Continuous monitoring script"""

import asyncio
import aiohttp
import time
import json
from datetime import datetime

class SystemMonitor:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
        self.alerts_sent = set()
    
    async def monitor_loop(self):
        """Main monitoring loop"""
        print("🔍 Starting system monitoring...")
        
        while True:
            try:
                await self.check_health()
                await self.check_metrics()
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                print(f"❌ Monitoring error: {e}")
                await asyncio.sleep(60)
    
    async def check_health(self):
        """Check system health"""
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(f"{self.base_url}/monitoring/health") as resp:
                    data = await resp.json()
                    
                    if data['status'] != 'healthy':
                        await self.send_alert("HEALTH", f"System unhealthy: {data}")
                        
                    # Check individual components
                    for component, status in data.get('components', {}).items():
                        if 'unhealthy' in status:
                            alert_key = f"COMPONENT_{component}"
                            if alert_key not in self.alerts_sent:
                                await self.send_alert(alert_key, f"Component {component} unhealthy: {status}")
                        else:
                            # Clear alert if component is healthy
                            alert_key = f"COMPONENT_{component}"
                            self.alerts_sent.discard(alert_key)
                            
            except Exception as e:
                await self.send_alert("HEALTH_CHECK", f"Health check failed: {e}")
    
    async def check_metrics(self):
        """Check system metrics for anomalies"""
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(f"{self.base_url}/monitoring/metrics/live") as resp:
                    data = await resp.json()
                    
                    # Check WebSocket connections
                    ws_connections = data['system']['active_websocket_connections']
                    if ws_connections > 1000:  # Alert if too many connections
                        await self.send_alert("HIGH_CONNECTIONS", f"High WebSocket connections: {ws_connections}")
                    
                    # Check queue size
                    queue_size = data['system']['task_queue_size']
                    if queue_size > 100:  # Alert if queue is backing up
                        await self.send_alert("QUEUE_BACKLOG", f"Task queue backlog: {queue_size}")
                        
            except Exception as e:
                print(f"⚠️  Metrics check failed: {e}")
    
    async def send_alert(self, alert_type, message):
        """Send alert (implement your alerting logic here)"""
        if alert_type not in self.alerts_sent:
            print(f"🚨 ALERT [{alert_type}]: {message}")
            self.alerts_sent.add(alert_type)
            
            # Here you would integrate with your alerting system:
            # - Send to Slack
            # - Send to PagerDuty
            # - Send email
            # - etc.

if __name__ == "__main__":
    monitor = SystemMonitor()
    asyncio.run(monitor.monitor_loop())
EOF

chmod +x monitor.py

# Makefile for easy operations
cat > Makefile << 'EOF'
.PHONY: build start stop restart logs health backup monitor load-test

# Build and start the system
build:
	docker-compose build

start:
	docker-compose up -d
	@echo "⏳ Waiting for services to start..."
	@sleep 10
	@python3 health-check.py

# Stop the system
stop:
	docker-compose down

# Restart the system
restart: stop start

# View logs
logs:
	docker-compose logs -f agent-system

# Check health
health:
	python3 health-check.py

# Create backup
backup:
	./backup.sh

# Start monitoring
monitor:
	python3 monitor.py

# Run load test
load-test:
	python3 load-test.py

# Full deployment
deploy: build start health
	@echo "✅ Deployment completed successfully"
	@echo "🌐 API available at: http://localhost:8000"
	@echo "📊 Grafana available at: http://localhost:3000 (admin/admin)"
	@echo "🔍 Prometheus available at: http://localhost:9090"

# Development setup
dev:
	pip install -r requirements.txt
	python3 migrate.py
	uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Run tests
test:
	python -m pytest tests/ -v

# Clean up everything
clean:
	docker-compose down -v
	docker system prune -f
EOF

# Production environment file
cat > .env.production << 'EOF'
# Production Environment Configuration
ENVIRONMENT=production
LOG_LEVEL=INFO

# Database Configuration
DATABASE_URL=postgresql+asyncpg://agent_user:CHANGE_THIS_PASSWORD@postgres:5432/agent_db
DB_PASSWORD=CHANGE_THIS_PASSWORD

# Redis Configuration
REDIS_URL=redis://redis:6379

# Security Configuration
JWT_SECRET=GENERATE_STRONG_JWT_SECRET_HERE
API_KEY_SECRET=GENERATE_STRONG_API_KEY_SECRET_HERE

# Monitoring Configuration
PROMETHEUS_RETENTION=15d
GRAFANA_PASSWORD=CHANGE_THIS_PASSWORD

# SSL Configuration (for production)
SSL_CERT_PATH=/etc/ssl/certs/server.crt
SSL_KEY_PATH=/etc/ssl/private/server.key

# Rate Limiting
RATE_LIMIT_PER_MINUTE=1000
RATE_LIMIT_BURST=50

# Performance Tuning
MAX_WORKERS=4
WORKER_CONNECTIONS=1000
KEEPALIVE_TIMEOUT=65

# Feature Flags
ENABLE_WEBSOCKETS=true
ENABLE_ANALYTICS=true
ENABLE_CACHING=true
EOF

echo "🎯 Deployment configuration created!"
echo "📝 Next steps:"
echo "1. Copy .env.production to .env and update passwords"
echo "2. Run 'make deploy' to start the system"
echo "3. Run 'make health' to verify everything is working"
echo "4. Run 'make monitor' to start continuous monitoring"
echo ""
echo "🔗 Key URLs:"
echo "- API: http://localhost:8000"
echo "- Health: http://localhost:8000/health"
echo "- Metrics: http://localhost:8000/metrics"
echo "- Docs: http://localhost:8000/docs"
echo "- Grafana: http://localhost:3000 (admin/admin)"
echo "- Prometheus: http://localhost:9090"
