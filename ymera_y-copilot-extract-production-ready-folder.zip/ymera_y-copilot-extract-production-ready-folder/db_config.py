"""
Production-Ready Database Configuration with Connection Pooling
"""

import logging
import os
from contextlib import contextmanager
from typing import Generator
from urllib.parse import quote_plus

from sqlalchemy import create_engine, event, pool
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, sessionmaker

logger = logging.getLogger(__name__)


# Database Configuration
class DatabaseConfig:
    """Production database configuration"""

    def __init__(self):
        # Azure SQL Server connection details
        self.server = os.getenv("AZURE_SQL_SERVER", "ymera-sql.database.windows.net")
        self.database = os.getenv("AZURE_SQL_DATABASE", "ymeradb")
        self.username = os.getenv("AZURE_SQL_USER", "ymeraadmin")
        self.password = os.getenv("AZURE_SQL_PASSWORD")
        self.driver = "ODBC Driver 18 for SQL Server"

        # Connection Pool Settings
        self.pool_size = int(os.getenv("DB_POOL_SIZE", "20"))
        self.max_overflow = int(os.getenv("DB_MAX_OVERFLOW", "40"))
        self.pool_timeout = int(os.getenv("DB_POOL_TIMEOUT", "30"))
        self.pool_recycle = int(os.getenv("DB_POOL_RECYCLE", "3600"))
        self.pool_pre_ping = True

        # Connection retry settings
        self.connect_args = {
            "connect_timeout": 30,
            "autocommit": False,
            "TrustServerCertificate": "no",
            "Encrypt": "yes",
            "Connection Timeout": 30,
        }

    def get_connection_string(self) -> str:
        """Build Azure SQL connection string"""
        password_encoded = quote_plus(self.password)
        return (
            f"mssql+pyodbc://{self.username}:{password_encoded}@"
            f"{self.server}:1433/{self.database}"
            f"?driver={quote_plus(self.driver)}"
            f"&Encrypt=yes&TrustServerCertificate=no&Connection Timeout=30"
        )


class DatabaseManager:
    """Database connection manager with health checks"""

    def __init__(self):
        self.config = DatabaseConfig()
        self._engine = None
        self._session_factory = None
        self.Base = declarative_base()

    def initialize(self):
        """Initialize database engine and session factory"""
        try:
            self._engine = create_engine(
                self.config.get_connection_string(),
                poolclass=pool.QueuePool,
                pool_size=self.config.pool_size,
                max_overflow=self.config.max_overflow,
                pool_timeout=self.config.pool_timeout,
                pool_recycle=self.config.pool_recycle,
                pool_pre_ping=self.config.pool_pre_ping,
                echo=os.getenv("SQL_ECHO", "false").lower() == "true",
                connect_args=self.config.connect_args,
            )

            # Register event listeners
            self._register_event_listeners()

            # Create session factory
            self._session_factory = sessionmaker(
                bind=self._engine, autocommit=False, autoflush=False, expire_on_commit=False
            )

            logger.info("Database initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise

    def _register_event_listeners(self):
        """Register SQLAlchemy event listeners for monitoring"""

        @event.listens_for(self._engine, "connect")
        def receive_connect(dbapi_conn, connection_record):
            logger.debug("Database connection established")

        @event.listens_for(self._engine, "checkout")
        def receive_checkout(dbapi_conn, connection_record, connection_proxy):
            logger.debug("Connection checked out from pool")

        @event.listens_for(self._engine, "checkin")
        def receive_checkin(dbapi_conn, connection_record):
            logger.debug("Connection returned to pool")

    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """Get database session with automatic cleanup"""
        if not self._session_factory:
            raise RuntimeError("Database not initialized")

        session = self._session_factory()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Session error: {e}")
            raise
        finally:
            session.close()

    def health_check(self) -> dict:
        """Perform database health check"""
        try:
            with self.get_session() as session:
                session.execute("SELECT 1")

            # Get pool status
            pool_status = self._engine.pool.status()

            return {
                "status": "healthy",
                "pool_size": self._engine.pool.size(),
                "checked_out": self._engine.pool.checkedout(),
                "overflow": self._engine.pool.overflow(),
                "pool_status": pool_status,
            }
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {"status": "unhealthy", "error": str(e)}

    def dispose(self):
        """Dispose database engine and cleanup connections"""
        if self._engine:
            self._engine.dispose()
            logger.info("Database connections disposed")


# Global database instance
db_manager = DatabaseManager()


def get_db() -> Generator[Session, None, None]:
    """Dependency for FastAPI to get database session"""
    with db_manager.get_session() as session:
        yield session


def init_db():
    """Initialize database on application startup"""
    db_manager.initialize()


def close_db():
    """Close database connections on application shutdown"""
    db_manager.dispose()
