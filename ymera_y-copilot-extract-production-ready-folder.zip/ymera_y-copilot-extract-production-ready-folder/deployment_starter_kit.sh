#!/bin/bash
#
# Production Deployment Starter Kit
# Complete setup for agent engines infrastructure
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
NAMESPACE="agents"
DOMAIN="agents.production.local"
POSTGRES_PASSWORD=$(openssl rand -base64 32)
REDIS_PASSWORD=$(openssl rand -base64 32)
NATS_CLUSTER_SIZE=3

# Helper functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker not found. Please install Docker."
        exit 1
    fi
    
    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        log_warn "kubectl not found. Using docker-compose for local deployment."
        USE_K8S=false
    else
        USE_K8S=true
    fi
    
    log_info "Prerequisites check passed"
}

# Create namespace
create_namespace() {
    if [ "$USE_K8S" = true ]; then
        log_info "Creating Kubernetes namespace: $NAMESPACE"
        kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -
    fi
}

# Create secrets
create_secrets() {
    log_info "Creating secrets..."
    
    if [ "$USE_K8S" = true ]; then
        # PostgreSQL credentials
        kubectl create secret generic db-credentials \
            --from-literal=username=agents \
            --from-literal=password="$POSTGRES_PASSWORD" \
            --from-literal=connection-string="postgresql://agents:${POSTGRES_PASSWORD}@postgres.${NAMESPACE}.svc:5432/agents_db" \
            --namespace="$NAMESPACE" \
            --dry-run=client -o yaml | kubectl apply -f -
        
        # Redis password
        kubectl create secret generic redis-credentials \
            --from-literal=password="$REDIS_PASSWORD" \
            --namespace="$NAMESPACE" \
            --dry-run=client -o yaml | kubectl apply -f -
    fi
    
    log_info "Secrets created"
}

# Deploy PostgreSQL
deploy_postgresql() {
    log_info "Deploying PostgreSQL..."
    
    if [ "$USE_K8S" = true ]; then
        cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: postgres-pvc
  namespace: $NAMESPACE
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 100Gi
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: postgres
  namespace: $NAMESPACE
spec:
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        env:
        - name: POSTGRES_DB
          value: agents_db
        - name: POSTGRES_USER
          value: agents
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: password
        ports:
        - containerPort: 5432
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
        livenessProbe:
          exec:
            command:
            - /bin/sh
            - -c
            - pg_isready -U agents
          initialDelaySeconds: 30
          periodSeconds: 10
      volumes:
      - name: postgres-storage
        persistentVolumeClaim:
          claimName: postgres-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: $NAMESPACE
spec:
  selector:
    app: postgres
  ports:
  - protocol: TCP
    port: 5432
    targetPort: 5432
EOF
    else
        log_warn "Skipping PostgreSQL K8s deployment. Use docker-compose for local setup."
    fi
}

# Deploy NATS
deploy_nats() {
    log_info "Deploying NATS cluster..."
    
    if [ "$USE_K8S" = true ]; then
        cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: nats
  namespace: $NAMESPACE
spec:
  serviceName: nats
  replicas: $NATS_CLUSTER_SIZE
  selector:
    matchLabels:
      app: nats
  template:
    metadata:
      labels:
        app: nats
    spec:
      containers:
      - name: nats
        image: nats:latest
        ports:
        - containerPort: 4222
          name: client
        - containerPort: 7422
          name: cluster
        args:
        - -c
        - /etc/nats/nats.conf
        volumeMounts:
        - name: config
          mountPath: /etc/nats
      volumes:
      - name: config
        configMap:
          name: nats-config
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: nats-config
  namespace: $NAMESPACE
data:
  nats.conf: |
    port: 4222
    cluster {
      port: 7422
      routes = [
        nats://nats-0.nats.agents.svc.cluster.local:7422
        nats://nats-1.nats.agents.svc.cluster.local:7422
        nats://nats-2.nats.agents.svc.cluster.local:7422
      ]
    }
    jetstream {
      store_dir: /data
      max_memory_store: 1GB
      max_file_store: 10GB
    }
---
apiVersion: v1
kind: Service
metadata:
  name: nats
  namespace: $NAMESPACE
spec:
  clusterIP: None
  selector:
    app: nats
  ports:
  - name: client
    port: 4222
  - name: cluster
    port: 7422
EOF
    fi
}

# Deploy Redis
deploy_redis() {
    log_info "Deploying Redis..."
    
    if [ "$USE_K8S" = true ]; then
        cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: $NAMESPACE
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        ports:
        - containerPort: 6379
        args:
        - redis-server
        - --requirepass
        - "$(REDIS_PASSWORD)"
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis-credentials
              key: password
        volumeMounts:
        - name: redis-storage
          mountPath: /data
      volumes:
      - name: redis-storage
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: $NAMESPACE
spec:
  selector:
    app: redis
  ports:
  - protocol: TCP
    port: 6379
    targetPort: 6379
EOF
    fi
}

# Initialize database schema
init_database() {
    log_info "Initializing database schema..."
    
    if [ "$USE_K8S" = true ]; then
        # Wait for PostgreSQL to be ready
        kubectl wait --for=condition=ready pod -l app=postgres -n "$NAMESPACE" --timeout=300s
        
        # Port forward and initialize
        kubectl port-forward -n "$NAMESPACE" svc/postgres 5432:5432 &
        sleep 5
        
        PGPASSWORD="$POSTGRES_PASSWORD" psql -h localhost -U agents -d agents_db <<EOF
-- Agents table
CREATE TABLE IF NOT EXISTS agents (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    agent_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'healthy',
    capabilities JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP
);

-- Task results table
CREATE TABLE IF NOT EXISTS task_results (
    task_id VARCHAR(255) PRIMARY KEY,
    agent_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    result JSONB,
    error TEXT,
    execution_time_ms FLOAT,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    FOREIGN KEY (agent_id) REFERENCES agents(name) ON DELETE CASCADE
);

-- Decision history table
CREATE TABLE IF NOT EXISTS decision_history (
    id SERIAL PRIMARY KEY,
    request_id VARCHAR(255) UNIQUE,
    task_type VARCHAR(100),
    selected_agent VARCHAR(255),
    confidence FLOAT,
    reasoning TEXT,
    context_data JSONB,
    system_state JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_task_results_agent_time 
    ON task_results(agent_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_decision_history_task_type 
    ON decision_history(task_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agents_status 
    ON agents(status);

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO agents;
EOF
        
        kill %1
    fi
    
    log_info "Database schema initialized"
}

# Deploy agents
deploy_agents() {
    log_info "Deploying agent engines..."
    
    if [ "$USE_K8S" = true ]; then
        cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: intelligence-engine
  namespace: $NAMESPACE
spec:
  replicas: 3
  selector:
    matchLabels:
      app: intelligence-engine
  template:
    metadata:
      labels:
        app: intelligence-engine
    spec:
      containers:
      - name: intelligence-engine
        image: your-registry/intelligence-engine:latest
        env:
        - name: NATS_URL
          value: "nats://nats:4222"
        - name: POSTGRES_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: connection-string
        - name: REDIS_URL
          value: "redis://:$(REDIS_PASSWORD)@redis:6379"
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis-credentials
              key: password
        - name: LOG_LEVEL
          value: "INFO"
        resources:
          requests:
            memory: "1Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: performance-engine
  namespace: $NAMESPACE
spec:
  replicas: 2
  selector:
    matchLabels:
      app: performance-engine
  template:
    metadata:
      labels:
        app: performance-engine
    spec:
      containers:
      - name: performance-engine
        image: your-registry/performance-engine:latest
        env:
        - name: NATS_URL
          value: "nats://nats:4222"
        - name: POSTGRES_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: connection-string
        - name: REDIS_URL
          value: "redis://:$(REDIS_PASSWORD)@redis:6379"
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis-credentials
              key: password
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: optimization-engine
  namespace: $NAMESPACE
spec:
  replicas: 1
  selector:
    matchLabels:
      app: optimization-engine
  template:
    metadata:
      labels:
        app: optimization-engine
    spec:
      containers:
      - name: optimization-engine
        image: your-registry/optimization-engine:latest
        env:
        - name: NATS_URL
          value: "nats://nats:4222"
        - name: POSTGRES_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: connection-string
        - name: REDIS_URL
          value: "redis://:$(REDIS_PASSWORD)@redis:6379"
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis-credentials
              key: password
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
EOF
    fi
    
    log_info "Agent engines deployed"
}

# Health check
health_check() {
    log_info "Performing health checks..."
    
    if [ "$USE_K8S" = true ]; then
        log_info "Waiting for deployments to be ready..."
        kubectl wait --for=condition=available --timeout=300s \
            deployment/intelligence-engine -n "$NAMESPACE" || true
        kubectl wait --for=condition=available --timeout=300s \
            deployment/performance-engine -n "$NAMESPACE" || true
        
        # Check pod status
        log_info "Pod status:"
        kubectl get pods -n "$NAMESPACE"
        
        # Check services
        log_info "Services:"
        kubectl get svc -n "$NAMESPACE"
    fi
}

# Main execution
main() {
    log_info "Starting Agent Engines Production Deployment"
    log_info "Namespace: $NAMESPACE"
    
    check_prerequisites
    create_namespace
    create_secrets
    deploy_postgresql
    deploy_nats
    deploy_redis
    init_database
    deploy_agents
    health_check
    
    log_info "Deployment completed successfully!"
    
    if [ "$USE_K8S" = true ]; then
        log_info "Access your services:"
        log_info "PostgreSQL: localhost:5432"
        log_info "NATS: localhost:4222"
        log_info "Redis: localhost:6379"
        log_info ""
        log_info "View logs: kubectl logs -f deployment/intelligence-engine -n $NAMESPACE"
        log_info "Port forward NATS: kubectl port-forward -n $NAMESPACE svc/nats 4222:4222"
    fi
}

# Run main
main "$@"
