#!/usr/bin/env python3
"""
System Cleanup and Organization Script
======================================

This script performs automated cleanup and organization:
- Removes duplicate and outdated files
- Organizes documentation into categorized directories
- Moves JSON reports to reports directory
- Creates clean directory structure
- Updates .gitignore
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
import json


class SystemOrganizer:
    """System cleanup and organization tool"""
    
    def __init__(self, dry_run=False):
        self.root_path = Path(__file__).parent
        self.dry_run = dry_run
        self.actions_log = []
        
        # Create organized directory structure
        self.doc_structure = {
            "documentation": {
                "agents": [],
                "testing": [],
                "deployment": [],
                "fixes": [],
                "phases": [],
                "integration": [],
                "general": []
            },
            "reports": {
                "test_reports": [],
                "analysis_reports": [],
                "archived_reports": []
            }
        }
    
    def log_action(self, action, details):
        """Log an action"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "details": details
        }
        self.actions_log.append(log_entry)
        status = "[DRY-RUN]" if self.dry_run else "[EXEC]"
        print(f"{status} {action}: {details}")
    
    def create_directory_structure(self):
        """Create organized directory structure"""
        print("\n" + "="*80)
        print("CREATING DIRECTORY STRUCTURE")
        print("="*80 + "\n")
        
        # Create main documentation directory
        doc_dir = self.root_path / "documentation"
        if not self.dry_run:
            doc_dir.mkdir(exist_ok=True)
        self.log_action("CREATE_DIR", str(doc_dir))
        
        # Create subdirectories
        for category in self.doc_structure["documentation"].keys():
            cat_dir = doc_dir / category
            if not self.dry_run:
                cat_dir.mkdir(exist_ok=True)
            self.log_action("CREATE_DIR", str(cat_dir))
        
        # Create reports directory structure
        reports_dir = self.root_path / "reports"
        if not self.dry_run:
            reports_dir.mkdir(exist_ok=True)
        self.log_action("CREATE_DIR", str(reports_dir))
        
        for report_type in self.doc_structure["reports"].keys():
            rep_dir = reports_dir / report_type
            if not self.dry_run:
                rep_dir.mkdir(exist_ok=True)
            self.log_action("CREATE_DIR", str(rep_dir))
    
    def categorize_documentation(self):
        """Categorize and move documentation files"""
        print("\n" + "="*80)
        print("CATEGORIZING DOCUMENTATION")
        print("="*80 + "\n")
        
        md_files = list(self.root_path.glob("*.md"))
        
        # Keep these files in root
        keep_in_root = [
            "README.md",
            "CHANGELOG.md",
            "CONTRIBUTING.md",
            "LICENSE.md",
            "CODE_OF_CONDUCT.md"
        ]
        
        for md_file in md_files:
            if md_file.name in keep_in_root:
                self.log_action("KEEP_ROOT", md_file.name)
                continue
            
            # Categorize based on filename
            name_upper = md_file.name.upper()
            target_category = None
            
            if 'AGENT' in name_upper:
                target_category = "agents"
            elif 'TEST' in name_upper or 'E2E' in name_upper:
                target_category = "testing"
            elif 'DEPLOY' in name_upper or 'PRODUCTION' in name_upper:
                target_category = "deployment"
            elif 'ERROR' in name_upper or 'FIX' in name_upper:
                target_category = "fixes"
            elif 'PHASE' in name_upper:
                target_category = "phases"
            elif 'INTEGRAT' in name_upper or 'EXPANSION' in name_upper:
                target_category = "integration"
            else:
                target_category = "general"
            
            # Move file
            target_dir = self.root_path / "documentation" / target_category
            target_path = target_dir / md_file.name
            
            if not self.dry_run:
                shutil.move(str(md_file), str(target_path))
            
            self.log_action("MOVE_DOC", f"{md_file.name} -> documentation/{target_category}/")
            self.doc_structure["documentation"][target_category].append(md_file.name)
    
    def organize_reports(self):
        """Organize JSON and test report files"""
        print("\n" + "="*80)
        print("ORGANIZING REPORTS")
        print("="*80 + "\n")
        
        # Move test report files
        test_reports = list(self.root_path.glob("*test_report*"))
        for report in test_reports:
            target_dir = self.root_path / "reports" / "test_reports"
            target_path = target_dir / report.name
            
            if not self.dry_run:
                shutil.move(str(report), str(target_path))
            
            self.log_action("MOVE_REPORT", f"{report.name} -> reports/test_reports/")
            self.doc_structure["reports"]["test_reports"].append(report.name)
        
        # Move JSON reports (but keep essential ones)
        essential_json = [
            "package.json",
            "tsconfig.json",
            "pyproject.toml"
        ]
        
        json_files = list(self.root_path.glob("*.json"))
        for json_file in json_files:
            if json_file.name in essential_json:
                continue
            
            # Keep recent analysis reports in root for now
            if "comprehensive_system_analysis" in json_file.name:
                self.log_action("KEEP_ROOT", json_file.name)
                continue
            
            # Determine if it's a test report or analysis report
            if "test" in json_file.name.lower():
                target_subdir = "test_reports"
            else:
                target_subdir = "analysis_reports"
            
            target_dir = self.root_path / "reports" / target_subdir
            target_path = target_dir / json_file.name
            
            if not self.dry_run:
                shutil.move(str(json_file), str(target_path))
            
            self.log_action("MOVE_REPORT", f"{json_file.name} -> reports/{target_subdir}/")
            self.doc_structure["reports"][target_subdir].append(json_file.name)
    
    def cleanup_old_files(self):
        """Remove old and duplicate files"""
        print("\n" + "="*80)
        print("CLEANING UP OLD FILES")
        print("="*80 + "\n")
        
        # Find .old files
        old_files = list(self.root_path.glob("*.old"))
        for old_file in old_files:
            if not self.dry_run:
                old_file.unlink()
            self.log_action("DELETE", f"Removed {old_file.name}")
        
        # Find duplicate test result files (small files)
        test_result_files = [
            "test_report.html",
            "test_report.json",
            "test_report.md"
        ]
        
        for test_file in test_result_files:
            file_path = self.root_path / test_file
            if file_path.exists():
                file_size = file_path.stat().st_size
                if file_size < 1000:  # Less than 1KB likely empty or minimal
                    if not self.dry_run:
                        # Move to archived instead of delete
                        archive_dir = self.root_path / "reports" / "archived_reports"
                        archive_dir.mkdir(exist_ok=True, parents=True)
                        shutil.move(str(file_path), str(archive_dir / test_file))
                    self.log_action("ARCHIVE", f"Archived small test file: {test_file}")
    
    def create_documentation_index(self):
        """Create a master documentation index"""
        print("\n" + "="*80)
        print("CREATING DOCUMENTATION INDEX")
        print("="*80 + "\n")
        
        index_content = """# YMERA System Documentation Index

This is the master index for all YMERA documentation.

## 📚 Documentation Categories

"""
        
        for category, files in self.doc_structure["documentation"].items():
            if files:
                index_content += f"\n### {category.title()}\n\n"
                index_content += f"Location: `documentation/{category}/`\n\n"
                index_content += f"Files: {len(files)}\n\n"
                
                # List up to 5 files as examples
                for i, file in enumerate(sorted(files)[:5]):
                    index_content += f"- [{file}](./documentation/{category}/{file})\n"
                
                if len(files) > 5:
                    index_content += f"\n... and {len(files) - 5} more files\n"
        
        index_content += """

## 📊 Reports

"""
        
        for report_type, files in self.doc_structure["reports"].items():
            if files:
                index_content += f"\n### {report_type.replace('_', ' ').title()}\n\n"
                index_content += f"Location: `reports/{report_type}/`\n\n"
                index_content += f"Files: {len(files)}\n\n"
        
        index_content += """

## 🚀 Quick Start

1. **New to YMERA?** Start with [README.md](./README.md)
2. **Deploying?** See [documentation/deployment/](./documentation/deployment/)
3. **Agent Development?** See [documentation/agents/](./documentation/agents/)
4. **Testing?** See [documentation/testing/](./documentation/testing/)
5. **Integration?** See [documentation/integration/](./documentation/integration/)

## 📈 System Status

For current system status and metrics, see:
- [comprehensive_system_analysis_report.json](./comprehensive_system_analysis_report.json)
- Production Readiness: See `documentation/deployment/`

## 🔧 Maintenance

Documentation organized on: """ + datetime.now().strftime("%Y-%m-%d") + """

"""
        
        index_path = self.root_path / "DOCUMENTATION_INDEX.md"
        if not self.dry_run:
            with open(index_path, 'w') as f:
                f.write(index_content)
        
        self.log_action("CREATE_INDEX", "Created DOCUMENTATION_INDEX.md")
    
    def update_gitignore(self):
        """Update .gitignore with patterns for generated files"""
        print("\n" + "="*80)
        print("UPDATING .GITIGNORE")
        print("="*80 + "\n")
        
        gitignore_additions = """

# Auto-generated reports (keep latest, ignore archived)
reports/archived_reports/
*_test_report.json
*_test_report.html

# Temporary analysis files
*.analysis.tmp
*.report.tmp

# Python cache
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
*.so
*.egg
*.egg-info/
dist/
build/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db
"""
        
        gitignore_path = self.root_path / ".gitignore"
        if gitignore_path.exists():
            with open(gitignore_path, 'r') as f:
                current_content = f.read()
            
            # Only add if not already present
            if "Auto-generated reports" not in current_content:
                if not self.dry_run:
                    with open(gitignore_path, 'a') as f:
                        f.write(gitignore_additions)
                self.log_action("UPDATE_GITIGNORE", "Added patterns for generated files")
            else:
                self.log_action("SKIP", ".gitignore already updated")
        else:
            if not self.dry_run:
                with open(gitignore_path, 'w') as f:
                    f.write(gitignore_additions)
            self.log_action("CREATE_GITIGNORE", "Created new .gitignore")
    
    def save_action_log(self):
        """Save action log to file"""
        log_file = self.root_path / f"cleanup_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        if not self.dry_run:
            with open(log_file, 'w') as f:
                json.dump(self.actions_log, f, indent=2)
        
        print(f"\n\nAction log saved to: {log_file}")
        return log_file
    
    def print_summary(self):
        """Print summary of actions"""
        print("\n" + "="*80)
        print("CLEANUP AND ORGANIZATION SUMMARY")
        print("="*80 + "\n")
        
        action_counts = {}
        for action in self.actions_log:
            action_type = action["action"]
            action_counts[action_type] = action_counts.get(action_type, 0) + 1
        
        print("Actions performed:")
        for action_type, count in sorted(action_counts.items()):
            print(f"  {action_type}: {count}")
        
        print(f"\nTotal actions: {len(self.actions_log)}")
        
        if self.dry_run:
            print("\n⚠️  DRY RUN MODE - No files were actually modified")
            print("Run without --dry-run to execute changes")
    
    def run_cleanup(self):
        """Run complete cleanup and organization"""
        print("\n" + "="*80)
        print("YMERA SYSTEM CLEANUP AND ORGANIZATION")
        print("="*80)
        if self.dry_run:
            print("\n⚠️  DRY RUN MODE - No changes will be made")
        print()
        
        # Execute all cleanup steps
        self.create_directory_structure()
        self.categorize_documentation()
        self.organize_reports()
        self.cleanup_old_files()
        self.create_documentation_index()
        self.update_gitignore()
        
        # Print summary and save log
        self.print_summary()
        log_file = self.save_action_log()
        
        print("\n" + "="*80)
        print("CLEANUP COMPLETE")
        print("="*80)
        
        if not self.dry_run:
            print("\n✅ All changes have been applied!")
            print("\nNext steps:")
            print("1. Review DOCUMENTATION_INDEX.md for navigation")
            print("2. Check documentation/ directory for organized docs")
            print("3. Check reports/ directory for organized reports")
            print("4. Review cleanup log for details")
        else:
            print("\n📋 Review the dry-run output above")
            print("Run with --execute to apply these changes")


def main():
    """Main entry point"""
    import sys
    
    dry_run = "--execute" not in sys.argv
    
    if dry_run:
        print("\n" + "="*80)
        print("⚠️  DRY RUN MODE")
        print("="*80)
        print("\nThis is a DRY RUN. No files will be modified.")
        print("To execute changes, run: python3 cleanup_and_organize.py --execute")
        print()
    
    organizer = SystemOrganizer(dry_run=dry_run)
    organizer.run_cleanup()


if __name__ == "__main__":
    main()
