#!/bin/bash
# deploy-production.sh - Complete Production Deployment Script

set -e  # Exit on error

echo "🚀 YMERA Production Deployment"
echo "================================"

# Configuration
RESOURCE_GROUP="ymera"
LOCATION="eastus"
SECONDARY_LOCATION="westus2"
PROJECT_NAME="ymera"
SQL_ADMIN_PASSWORD="${SQL_ADMIN_PASSWORD:-YourSecurePassword123!}"
ENABLE_GEO_REPLICATION=true

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Azure CLI
    if ! command -v az &> /dev/null; then
        log_error "Azure CLI is not installed. Please install it first."
        exit 1
    fi
    
    # Check if logged in
    if ! az account show &> /dev/null; then
        log_warn "Not logged in to Azure. Logging in..."
        az login
    fi
    
    log_info "Prerequisites check passed ✓"
}

# Create resource group
create_resource_group() {
    log_info "Creating resource group: $RESOURCE_GROUP"
    
    az group create \
        --name $RESOURCE_GROUP \
        --location $LOCATION \
        --tags Environment=Production Project=YMERA
    
    log_info "Resource group created ✓"
}

# Deploy infrastructure
deploy_infrastructure() {
    log_info "Deploying Azure infrastructure..."
    
    deployment_output=$(az deployment group create \
        --resource-group $RESOURCE_GROUP \
        --template-file azure-deploy-enhanced.json \
        --parameters \
            projectName=$PROJECT_NAME \
            location=$LOCATION \
            secondaryLocation=$SECONDARY_LOCATION \
            sqlAdminPassword=$SQL_ADMIN_PASSWORD \
            enableGeoReplication=$ENABLE_GEO_REPLICATION \
        --query 'properties.outputs' \
        --output json)
    
    log_info "Infrastructure deployed ✓"
    echo "$deployment_output" > deployment-output.json
}

# Configure database backup policies
configure_backups() {
    log_info "Configuring database backup policies..."
    
    SQL_SERVER="${PROJECT_NAME}-sql"
    DATABASE_NAME="ymeradb"
    
    # Configure short-term retention (35 days)
    az sql db str-policy set \
        --resource-group $RESOURCE_GROUP \
        --server $SQL_SERVER \
        --name $DATABASE_NAME \
        --retention-days 35 \
        --diffbackup-hours 24
    
    # Configure long-term retention
    az sql db ltr-policy set \
        --resource-group $RESOURCE_GROUP \
        --server $SQL_SERVER \
        --name $DATABASE_NAME \
        --weekly-retention "P4W" \
        --monthly-retention "P12M" \
        --yearly-retention "P5Y" \
        --week-of-year 1
    
    log_info "Backup policies configured ✓"
}

# Setup monitoring and alerts
setup_monitoring() {
    log_info "Setting up monitoring and alerts..."
    
    SQL_SERVER="${PROJECT_NAME}-sql"
    DATABASE_NAME="ymeradb"
    LOG_ANALYTICS="${PROJECT_NAME}-logs"
    
    # Enable diagnostic settings
    az monitor diagnostic-settings create \
        --name "SQLDatabaseDiagnostics" \
        --resource "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Sql/servers/$SQL_SERVER/databases/$DATABASE_NAME" \
        --workspace "$LOG_ANALYTICS" \
        --logs '[
            {"category": "SQLInsights", "enabled": true},
            {"category": "QueryStoreRuntimeStatistics", "enabled": true},
            {"category": "QueryStoreWaitStatistics", "enabled": true},
            {"category": "Errors", "enabled": true}
        ]' \
        --metrics '[{"category": "Basic", "enabled": true}]'
    
    log_info "Monitoring configured ✓"
}

# Run database migrations
run_migrations() {
    log_info "Running database migrations..."
    
    # Export connection string for migrations
    export AZURE_SQL_SERVER="${PROJECT_NAME}-sql.database.windows.net"
    export AZURE_SQL_DATABASE="ymeradb"
    export AZURE_SQL_USER="ymeraadmin"
    export AZURE_SQL_PASSWORD="$SQL_ADMIN_PASSWORD"
    
    # Run Alembic migrations
    if [ -f "alembic.ini" ]; then
        python -m alembic upgrade head
        log_info "Migrations completed ✓"
    else
        log_warn "No alembic.ini found. Skipping migrations."
    fi
}

# Deploy application
deploy_application() {
    log_info "Deploying application to Azure App Service..."
    
    WEBAPP_NAME="${PROJECT_NAME}-app"
    
    # Build application (if needed)
    if [ -f "requirements.txt" ]; then
        log_info "Installing Python dependencies..."
        pip install -r requirements.txt
    fi
    
    # Deploy to Azure
    az webapp up \
        --resource-group $RESOURCE_GROUP \
        --name $WEBAPP_NAME \
        --runtime "PYTHON:3.11" \
        --sku P1V3
    
    log_info "Application deployed ✓"
}

# Health check
health_check() {
    log_info "Performing health checks..."
    
    SQL_SERVER="${PROJECT_NAME}-sql"
    DATABASE_NAME="ymeradb"
    
    # Check database connectivity
    if az sql db show \
        --resource-group $RESOURCE_GROUP \
        --server $SQL_SERVER \
        --name $DATABASE_NAME \
        --query "status" -o tsv | grep -q "Online"; then
        log_info "Database health check passed ✓"
    else
        log_error "Database health check failed ✗"
        exit 1
    fi
    
    # Check web app
    WEBAPP_URL=$(az webapp show \
        --resource-group $RESOURCE_GROUP \
        --name "${PROJECT_NAME}-app" \
        --query "defaultHostName" -o tsv)
    
    if curl -sf "https://$WEBAPP_URL/health" > /dev/null; then
        log_info "Application health check passed ✓"
    else
        log_warn "Application health check failed. App may still be starting..."
    fi
}

# Display deployment information
display_info() {
    log_info "Deployment Summary"
    echo "================================"
    
    if [ -f "deployment-output.json" ]; then
        cat deployment-output.json | jq -r '
            "SQL Server: \(.sqlServerFQDN.value)",
            "Secondary Server: \(.secondarySqlServerName.value)",
            "Web App URL: \(.webAppUrl.value)",
            "Storage Account: \(.storageAccountName.value)"
        '
    fi
    
    echo ""
    log_info "Next Steps:"
    echo "1. Update your .env file with the connection strings"
    echo "2. Configure application settings in Azure Portal"
    echo "3. Set up CI/CD pipeline"
    echo "4. Configure custom domain and SSL"
    echo "5. Review and adjust scaling settings"
}

# Cleanup on failure
cleanup_on_failure() {
    log_error "Deployment failed. Cleaning up..."
    # Optionally remove partially created resources
    # az group delete --name $RESOURCE_GROUP --yes --no-wait
}

# Main deployment flow
main() {
    trap cleanup_on_failure ERR
    
    check_prerequisites
    create_resource_group
    deploy_infrastructure
    configure_backups
    setup_monitoring
    run_migrations
    deploy_application
    health_check
    display_info
    
    log_info "✅ Deployment completed successfully!"
}

# Run main function
main "$@"