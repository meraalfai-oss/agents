#!/usr/bin/env python3
"""
Repository Analysis Script for YMERA Agent System
This script analyzes the repository structure, identifies key components,
and helps create a clean, organized production-ready structure.
"""

import ast
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict


class RepositoryAnalyzer:
    """Analyzes the YMERA repository and generates a comprehensive report."""

    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path).absolute()
        self.analysis_results = {
            "timestamp": datetime.now().isoformat(),
            "repo_path": str(self.repo_path),
            "stats": {},
            "components": {},
            "agents": {},
            "modules": {},
            "duplicates": {},
            "recommendations": [],
        }

        # File categories
        self.agent_files = []
        self.utility_files = []
        self.test_files = []
        self.doc_files = []
        self.config_files = []
        self.api_files = []
        self.database_files = []
        self.monitoring_files = []
        self.security_files = []
        self.other_files = []

        # File syntax status
        self.valid_python_files = []
        self.invalid_python_files = []

        # Import tracking
        self.file_dependencies = {}

        # Excluded paths for analysis
        self.excluded_paths = {
            ".git",
            ".github",
            "__pycache__",
            ".pytest_cache",
            ".mypy_cache",
            "venv",
            ".venv",
            "env",
            "node_modules",
            "dist",
            "build",
        }

    def run_analysis(self):
        """Run the full repository analysis."""
        print("=" * 70)
        print("YMERA REPOSITORY ANALYSIS")
        print("=" * 70)
        print(f"\nAnalyzing repository: {self.repo_path}")

        # Step 1: Find all files
        print("\nStep 1: Finding all files...")
        self._find_all_files()

        # Step 2: Analyze Python files
        print("\nStep 2: Analyzing Python files...")
        self._analyze_python_files()

        # Step 3: Detect duplicate files
        print("\nStep 3: Detecting duplicate files...")
        self._detect_duplicates()

        # Step 4: Analyze imports and dependencies
        print("\nStep 4: Analyzing imports and dependencies...")
        self._analyze_dependencies()

        # Step 5: Identify core components
        print("\nStep 5: Identifying core components...")
        self._identify_core_components()

        # Step 6: Generate recommendations
        print("\nStep 6: Generating recommendations...")
        self._generate_recommendations()

        # Step 7: Generate summary
        print("\nStep 7: Generating summary...")
        self._generate_summary()

        return self.analysis_results

    def _find_all_files(self):
        """Find all files in the repository."""
        file_count = 0
        python_count = 0
        md_count = 0

        for root, dirs, files in os.walk(self.repo_path):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if d not in self.excluded_paths]

            for file in files:
                file_path = Path(root) / file
                rel_path = file_path.relative_to(self.repo_path)
                file_count += 1

                if file.endswith(".py"):
                    python_count += 1
                    self._categorize_python_file(file_path, rel_path)

                elif file.endswith(".md"):
                    md_count += 1
                    self.doc_files.append(str(rel_path))

                elif file.endswith((".json", ".yaml", ".yml", ".toml", ".ini")):
                    self.config_files.append(str(rel_path))

        print(f"Found {file_count} total files")
        print(f"  - {python_count} Python files")
        print(f"  - {md_count} Markdown files")
        print(f"  - {len(self.config_files)} Config files")

        self.analysis_results["stats"]["total_files"] = file_count
        self.analysis_results["stats"]["python_files"] = python_count
        self.analysis_results["stats"]["markdown_files"] = md_count
        self.analysis_results["stats"]["config_files"] = len(self.config_files)

    def _categorize_python_file(self, file_path: Path, rel_path: Path):
        """Categorize a Python file based on its name and content."""
        file_str = str(rel_path)

        # Categorize by name pattern
        if (
            re.search(r"(^|[_/])agent[s_]", file_str)
            or file_str.endswith("_agent.py")
            or file_str.endswith("Agent.py")
        ):
            self.agent_files.append(file_str)
        elif re.search(r"(^|[_/])test[s_]", file_str) or file_str.startswith("test_"):
            self.test_files.append(file_str)
        elif (
            re.search(r"(^|[_/])api[s_]", file_str)
            or "route" in file_str.lower()
            or "endpoint" in file_str.lower()
        ):
            self.api_files.append(file_str)
        elif (
            re.search(r"(^|[_/])db[_]", file_str)
            or "database" in file_str.lower()
            or "model" in file_str.lower()
        ):
            self.database_files.append(file_str)
        elif "monitor" in file_str.lower() or "metric" in file_str.lower():
            self.monitoring_files.append(file_str)
        elif "security" in file_str.lower() or "auth" in file_str.lower():
            self.security_files.append(file_str)
        elif "util" in file_str.lower() or "helper" in file_str.lower():
            self.utility_files.append(file_str)
        else:
            # Try to categorize based on content
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()

                if "agent" in content.lower() and ("class" in content and "def" in content):
                    self.agent_files.append(file_str)
                elif (
                    "fastapi" in content.lower()
                    or "flask" in content.lower()
                    or "route" in content.lower()
                ):
                    self.api_files.append(file_str)
                elif "sqlalchemy" in content.lower() or "database" in content.lower():
                    self.database_files.append(file_str)
                elif "prometheus" in content.lower() or "monitor" in content.lower():
                    self.monitoring_files.append(file_str)
                else:
                    self.other_files.append(file_str)
            except:
                self.other_files.append(file_str)

    def _analyze_python_files(self):
        """Analyze Python files for syntax validity and metadata."""
        for category, files in [
            ("agents", self.agent_files),
            ("api", self.api_files),
            ("database", self.database_files),
            ("monitoring", self.monitoring_files),
            ("security", self.security_files),
            ("utility", self.utility_files),
            ("tests", self.test_files),
            ("other", self.other_files),
        ]:
            valid_count = 0
            invalid_count = 0

            for file_path in files:
                full_path = self.repo_path / file_path
                try:
                    with open(full_path, "r", encoding="utf-8") as f:
                        content = f.read()

                    # Check syntax
                    ast.parse(content)
                    self.valid_python_files.append(file_path)
                    valid_count += 1

                    # Extract metadata
                    self._extract_file_metadata(file_path, content, category)

                except SyntaxError as e:
                    self.invalid_python_files.append(
                        {"path": file_path, "error": str(e), "line": e.lineno}
                    )
                    invalid_count += 1

                except Exception as e:
                    self.invalid_python_files.append(
                        {"path": file_path, "error": str(e), "line": 0}
                    )
                    invalid_count += 1

            print(
                f"{category.capitalize()}: {len(files)} files - {valid_count} valid, {invalid_count} invalid"
            )

            self.analysis_results["stats"][f"{category}_files"] = len(files)
            self.analysis_results["stats"][f"{category}_valid"] = valid_count
            self.analysis_results["stats"][f"{category}_invalid"] = invalid_count

        self.analysis_results["stats"]["total_valid"] = len(self.valid_python_files)
        self.analysis_results["stats"]["total_invalid"] = len(self.invalid_python_files)
        self.analysis_results["invalid_files"] = self.invalid_python_files

    def _extract_file_metadata(self, file_path: str, content: str, category: str):
        """Extract metadata from file content."""
        metadata = {
            "path": file_path,
            "category": category,
            "size": len(content),
            "classes": [],
            "functions": [],
            "imports": [],
            "docstring": None,
        }

        try:
            tree = ast.parse(content)

            # Extract module docstring
            if (
                isinstance(tree.body[0], ast.Expr)
                and isinstance(tree.body[0].value, ast.Constant)
                and isinstance(tree.body[0].value.value, str)
            ):
                metadata["docstring"] = tree.body[0].value.value.strip()

            # Extract imports
            imports = []
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for name in node.names:
                        imports.append(name.name)
                elif isinstance(node, ast.ImportFrom):
                    module = node.module if node.module else ""
                    for name in node.names:
                        imports.append(f"{module}.{name.name}" if module else name.name)

            metadata["imports"] = imports

            # Extract classes and methods
            for node in tree.body:
                if isinstance(node, ast.ClassDef):
                    class_info = {
                        "name": node.name,
                        "methods": [m.name for m in node.body if isinstance(m, ast.FunctionDef)],
                    }
                    metadata["classes"].append(class_info)
                elif isinstance(node, ast.FunctionDef):
                    metadata["functions"].append(node.name)

            # Special handling for agents
            if category == "agents":
                self.analysis_results["agents"][file_path] = self._extract_agent_info(
                    metadata, tree
                )

            # Store the metadata
            self.analysis_results["modules"][file_path] = metadata

        except Exception as e:
            print(f"Error extracting metadata from {file_path}: {e}")

    def _extract_agent_info(self, metadata: Dict, tree: ast.Module) -> Dict:
        """Extract specific information about an agent file."""
        agent_info = {
            "name": Path(metadata["path"]).stem,
            "classes": metadata["classes"],
            "base_classes": [],
            "capabilities": [],
        }

        # Extract base classes
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                bases = []
                for base in node.bases:
                    if isinstance(base, ast.Name):
                        bases.append(base.id)
                    elif isinstance(base, ast.Attribute):
                        bases.append(
                            f"{base.value.id}.{base.attr}"
                            if hasattr(base.value, "id")
                            else base.attr
                        )

                if bases:
                    agent_info["base_classes"].extend(bases)

        # Look for capabilities in docstrings and assignments
        capabilities = []
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Assign)
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in ("capabilities", "CAPABILITIES")
            ):
                if isinstance(node.value, ast.List):
                    for elt in node.value.elts:
                        if isinstance(elt, ast.Constant):
                            capabilities.append(str(elt.value))

        agent_info["capabilities"] = capabilities

        return agent_info

    def _detect_duplicates(self):
        """Detect potential duplicate files based on name and content."""
        # Group files by base name
        file_groups = {}
        for file_path in self.valid_python_files:
            base_name = Path(file_path).stem
            if base_name not in file_groups:
                file_groups[base_name] = []
            file_groups[base_name].append(file_path)

        # Find groups with more than one file
        duplicates = {k: v for k, v in file_groups.items() if len(v) > 1}

        # Check content similarity for potential duplicates
        confirmed_duplicates = {}
        for base_name, files in duplicates.items():
            if len(files) <= 1:
                continue

            file_contents = {}
            for file_path in files:
                try:
                    with open(self.repo_path / file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    file_contents[file_path] = content
                except Exception as e:
                    print(f"Error reading {file_path}: {e}")

            # Group by content hash
            content_groups = {}
            for file_path, content in file_contents.items():
                content_hash = hash(content)
                if content_hash not in content_groups:
                    content_groups[content_hash] = []
                content_groups[content_hash].append(file_path)

            # Find content groups with more than one file
            for content_hash, content_files in content_groups.items():
                if len(content_files) > 1:
                    if base_name not in confirmed_duplicates:
                        confirmed_duplicates[base_name] = []
                    confirmed_duplicates[base_name].extend(content_files)

        self.analysis_results["duplicates"] = confirmed_duplicates
        print(f"Found {len(confirmed_duplicates)} potential duplicate file groups")

    def _analyze_dependencies(self):
        """Analyze imports and dependencies between files."""
        for file_path, metadata in self.analysis_results["modules"].items():
            self.file_dependencies[file_path] = {"imports": metadata["imports"], "imported_by": []}

        # Build imported_by relationships
        for file_path, data in self.file_dependencies.items():
            for imported in data["imports"]:
                # Find files that match the import
                imported_path = imported.replace(".", "/")
                for other_file, other_data in self.file_dependencies.items():
                    if file_path != other_file:
                        other_stem = Path(other_file).stem
                        if (
                            other_stem == imported
                            or other_file.endswith(f"/{imported}.py")
                            or other_file.endswith(f"/{imported_path}.py")
                        ):
                            other_data["imported_by"].append(file_path)

        # Calculate dependency counts
        for file_path, data in self.file_dependencies.items():
            data["dependency_count"] = len(data["imports"])
            data["dependents_count"] = len(data["imported_by"])

        # Sort by dependencies
        sorted_deps = sorted(
            self.file_dependencies.items(),
            key=lambda x: (x[1]["dependents_count"], x[1]["dependency_count"]),
            reverse=True,
        )

        # Store top dependencies
        self.analysis_results["top_dependencies"] = [
            {
                "file": path,
                "imports": data["imports"],
                "imported_by_count": data["dependents_count"],
                "imports_count": data["dependency_count"],
            }
            for path, data in sorted_deps[:20]  # Top 20
        ]

        print(f"Analyzed dependencies for {len(self.file_dependencies)} files")

    def _identify_core_components(self):
        """Identify core components of the system."""
        # Find base agent implementation
        base_agent_candidates = []
        for path, metadata in self.analysis_results["modules"].items():
            if "base_agent" in path.lower():
                base_classes = []
                for class_info in metadata["classes"]:
                    if "agent" in class_info["name"].lower():
                        base_classes.append(class_info["name"])

                if base_classes:
                    base_agent_candidates.append(
                        {
                            "path": path,
                            "classes": base_classes,
                            "imported_by": len(
                                self.file_dependencies.get(path, {}).get("imported_by", [])
                            ),
                        }
                    )

        # Sort by number of files importing it
        base_agent_candidates.sort(key=lambda x: x["imported_by"], reverse=True)

        # Store core components
        self.analysis_results["components"]["base_agent"] = base_agent_candidates[:3]  # Top 3

        # Find other core components
        for component_type, search_term in [
            ("config", ["config", "settings"]),
            ("database", ["database", "db", "models"]),
            ("api", ["api", "routes", "endpoints"]),
            ("security", ["security", "auth"]),
            ("monitoring", ["monitoring", "metrics"]),
        ]:
            candidates = []
            for path, metadata in self.analysis_results["modules"].items():
                if any(term in path.lower() for term in search_term):
                    imported_by = len(self.file_dependencies.get(path, {}).get("imported_by", []))
                    if imported_by > 0:
                        candidates.append(
                            {
                                "path": path,
                                "imported_by": imported_by,
                                "classes": [c["name"] for c in metadata["classes"]],
                            }
                        )

            # Sort by number of files importing it
            candidates.sort(key=lambda x: x["imported_by"], reverse=True)
            self.analysis_results["components"][component_type] = candidates[:5]  # Top 5

        print(
            f"Identified core components in {len(self.analysis_results['components'])} categories"
        )

    def _generate_recommendations(self):
        """Generate recommendations for organizing the repository."""
        recommendations = []

        # Add general recommendations
        recommendations.append(
            {
                "type": "general",
                "title": "Create Organized Directory Structure",
                "description": "Create a clean directory structure with separate folders for agents, api, database, etc.",
                "action": "mkdir -p ymera/{agents,api,database,config,monitoring,security,utils,tests}",
            }
        )

        # Add base agent recommendation
        if self.analysis_results["components"].get("base_agent"):
            base_agent = self.analysis_results["components"]["base_agent"][0]
            recommendations.append(
                {
                    "type": "core",
                    "title": "Use Primary Base Agent Implementation",
                    "description": f"Use {base_agent['path']} as the core agent implementation",
                    "action": f"cp {base_agent['path']} ymera/agents/base_agent.py",
                }
            )

        # Add duplicate file recommendations
        if self.analysis_results["duplicates"]:
            duplicate_count = sum(
                len(files) for files in self.analysis_results["duplicates"].values()
            )
            recommendations.append(
                {
                    "type": "cleanup",
                    "title": "Resolve Duplicate Files",
                    "description": f"Found {duplicate_count} duplicate files across {len(self.analysis_results['duplicates'])} groups",
                    "action": "Review duplicates and keep only the most complete version",
                }
            )

        # Add invalid file recommendations
        if self.analysis_results["invalid_files"]:
            recommendations.append(
                {
                    "type": "fix",
                    "title": "Fix Invalid Python Files",
                    "description": f"Found {len(self.analysis_results['invalid_files'])} files with syntax errors",
                    "action": "Fix syntax errors in invalid files or exclude them from production",
                }
            )

        # Add agent organization recommendations
        agent_count = len(self.analysis_results["agents"])
        if agent_count > 0:
            recommendations.append(
                {
                    "type": "agents",
                    "title": "Organize Agent Files",
                    "description": f"Found {agent_count} agent implementations",
                    "action": "Organize agents by category and ensure they use the common base_agent pattern",
                }
            )

        self.analysis_results["recommendations"] = recommendations
        print(f"Generated {len(recommendations)} recommendations")

    def _generate_summary(self):
        """Generate a summary of the analysis results."""
        valid_rate = 0
        if self.analysis_results["stats"]["python_files"] > 0:
            valid_rate = (
                self.analysis_results["stats"]["total_valid"]
                / self.analysis_results["stats"]["python_files"]
                * 100
            )

        self.analysis_results["summary"] = {
            "total_files": self.analysis_results["stats"]["total_files"],
            "python_files": self.analysis_results["stats"]["python_files"],
            "valid_rate": round(valid_rate, 1),
            "agent_count": len(self.analysis_results["agents"]),
            "duplicate_groups": len(self.analysis_results["duplicates"]),
            "invalid_files": len(self.analysis_results["invalid_files"]),
            "top_component": self.analysis_results["components"]
            .get("base_agent", [{}])[0]
            .get("path", "Unknown"),
        }

        print("\n" + "=" * 70)
        print("ANALYSIS SUMMARY")
        print("=" * 70)
        print(f"Total Files: {self.analysis_results['summary']['total_files']}")
        print(f"Python Files: {self.analysis_results['summary']['python_files']}")
        print(f"Python Syntax Valid Rate: {self.analysis_results['summary']['valid_rate']}%")
        print(f"Agent Count: {self.analysis_results['summary']['agent_count']}")
        print(f"Duplicate File Groups: {self.analysis_results['summary']['duplicate_groups']}")
        print(f"Files with Syntax Errors: {self.analysis_results['summary']['invalid_files']}")
        print(f"Primary Component: {self.analysis_results['summary']['top_component']}")

    def save_results(self, output_path: str = "repository_analysis.json"):
        """Save analysis results to a JSON file."""
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(self.analysis_results, f, indent=2)

        print(f"\nAnalysis results saved to {output_path}")

        # Also create a summary markdown file
        summary_path = output_path.replace(".json", "_summary.md")
        with open(summary_path, "w", encoding="utf-8") as f:
            f.write("# YMERA Repository Analysis Summary\n\n")
            f.write(f"**Generated:** {datetime.now().isoformat()}\n\n")

            f.write("## Overview\n\n")
            f.write(f"- Total Files: {self.analysis_results['summary']['total_files']}\n")
            f.write(f"- Python Files: {self.analysis_results['summary']['python_files']}\n")
            f.write(
                f"- Valid Python Files: {self.analysis_results['stats']['total_valid']} ({self.analysis_results['summary']['valid_rate']}%)\n"
            )
            f.write(f"- Agent Implementations: {self.analysis_results['summary']['agent_count']}\n")

            f.write("\n## Key Components\n\n")
            for component_type, components in self.analysis_results["components"].items():
                if components:
                    f.write(f"### {component_type.capitalize()}\n\n")
                    for i, component in enumerate(components[:3]):  # Top 3
                        f.write(f"{i + 1}. **{component['path']}**")
                        if "classes" in component and component["classes"]:
                            f.write(f" - Classes: {', '.join(component['classes'])}")
                        if "imported_by" in component:
                            f.write(f" - Referenced by {component['imported_by']} files")
                        f.write("\n")
                    f.write("\n")

            f.write("\n## Issues\n\n")
            f.write(
                f"- Files with Syntax Errors: {self.analysis_results['summary']['invalid_files']}\n"
            )
            f.write(
                f"- Duplicate File Groups: {self.analysis_results['summary']['duplicate_groups']}\n"
            )

            f.write("\n## Recommendations\n\n")
            for rec in self.analysis_results["recommendations"]:
                f.write(f"### {rec['title']}\n\n")
                f.write(f"{rec['description']}\n\n")
                if "action" in rec:
                    f.write(f"**Action:** {rec['action']}\n\n")

        print(f"Analysis summary saved to {summary_path}")
        return output_path, summary_path


def main():
    """Main entry point."""
    repo_path = "."
    if len(sys.argv) > 1:
        repo_path = sys.argv[1]

    analyzer = RepositoryAnalyzer(repo_path)
    analyzer.run_analysis()
    analyzer.save_results("repository_analysis.json")

    return 0


if __name__ == "__main__":
    sys.exit(main())
