-- Schema for the Multi-Agent Platform

-- Drop existing tables if they exist to ensure a clean slate
DROP TABLE IF EXISTS chat_messages CASCADE;
DROP TABLE IF EXISTS chat_sessions CASCADE;
DROP TABLE IF EXISTS agent_capabilities CASCADE;
DROP TABLE IF EXISTS agent_heartbeats CASCADE;
DROP TABLE IF EXISTS tasks CASCADE;
DROP TABLE IF EXISTS workflow_instances CASCADE;
DROP TABLE IF EXISTS workflows CASCADE;
DROP TABLE IF EXISTS agents CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS api_keys CASCADE;
DROP TYPE IF EXISTS agent_status_enum;
DROP TYPE IF EXISTS task_status_enum;
DROP TYPE IF EXISTS priority_enum;
DROP TYPE IF EXISTS workflow_status_enum;
DROP TYPE IF EXISTS chat_session_status_enum;
DROP TYPE IF EXISTS message_type_enum;
DROP TYPE IF EXISTS session_type_enum;

-- Enums for standardized statuses and priorities
CREATE TYPE agent_status_enum AS ENUM (
    'initializing',
    'active',
    'degraded',
    'maintenance',
    'error',
    'shutting_down'
);

CREATE TYPE task_status_enum AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'cancelled',
    'timeout'
);

CREATE TYPE priority_enum AS ENUM (
    'low',
    'normal',
    'high',
    'critical'
);

CREATE TYPE workflow_status_enum AS ENUM (
    'running',
    'completed',
    'failed',
    'paused',
    'cancelled',
    'timeout'
);

CREATE TYPE chat_session_status_enum AS ENUM (
    'active',
    'idle',
    'ended',
    'paused'
);

CREATE TYPE message_type_enum AS ENUM (
    'user',
    'assistant',
    'system',
    'notification',
    'typing',
    'error'
);

CREATE TYPE session_type_enum AS ENUM (
    'individual',
    'group',
    'support',
    'consultation'
);

-- Users table
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- API Keys table for external access and authentication
CREATE TABLE api_keys (
    api_key_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    api_key_hash VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(100),
    permissions JSONB DEFAULT '{}'::jsonb, -- e.g., {"can_create_task": true, "can_view_status": true}
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE,
    last_used_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT unique_api_key_per_user UNIQUE (user_id, api_key_hash)
);

-- Agents table to register all active agents in the system
CREATE TABLE agents (
    agent_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    agent_type VARCHAR(50) NOT NULL,
    version VARCHAR(20) NOT NULL,
    description TEXT,
    status agent_status_enum DEFAULT 'initializing',
    max_concurrent_tasks INTEGER DEFAULT 10,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Agent Capabilities table to store what each agent can do
CREATE TABLE agent_capabilities (
    agent_capability_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    capability VARCHAR(100) NOT NULL, -- e.g., 'drafting', 'editing', 'llm_inference'
    metadata JSONB DEFAULT '{}'::jsonb, -- e.g., {"model": "gpt-4", "cost_per_token": 0.001}
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (agent_id, capability)
);

-- Agent Heartbeats table for health monitoring and load balancing
CREATE TABLE agent_heartbeats (
    heartbeat_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status agent_status_enum NOT NULL,
    active_tasks INTEGER DEFAULT 0,
    health_score NUMERIC(5, 2) DEFAULT 1.0,
    average_response_time NUMERIC(10, 3) DEFAULT 0.0,
    success_rate NUMERIC(5, 2) DEFAULT 1.0,
    last_error TEXT,
    resource_usage JSONB DEFAULT '{}'::jsonb,
    dependencies JSONB DEFAULT '{}'::jsonb
);

-- Workflows table to define complex multi-step processes
CREATE TABLE workflows (
    workflow_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    definition JSONB NOT NULL, -- JSON definition of workflow steps and logic
    created_by UUID REFERENCES users(user_id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status workflow_status_enum DEFAULT 'running' -- 'active', 'inactive', 'draft'
);

-- Workflow Instances table to track individual runs of a workflow
CREATE TABLE workflow_instances (
    instance_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES workflows(workflow_id) ON DELETE CASCADE,
    started_by UUID REFERENCES users(user_id) ON DELETE SET NULL,
    start_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP WITH TIME ZONE,
    status workflow_status_enum DEFAULT 'running',
    current_step_index INTEGER DEFAULT 0,
    context JSONB DEFAULT '{}'::jsonb, -- Stores intermediate results and state
    input_data JSONB DEFAULT '{}'::jsonb,
    output_data JSONB DEFAULT '{}'::jsonb,
    last_error TEXT
);

-- Tasks table to track individual tasks processed by agents
CREATE TABLE tasks (
    task_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_instance_id UUID REFERENCES workflow_instances(instance_id) ON DELETE SET NULL,
    agent_id UUID REFERENCES agents(agent_id) ON DELETE SET NULL,
    task_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    status task_status_enum DEFAULT 'pending',
    priority priority_enum DEFAULT 'normal',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    timeout_at TIMESTAMP WITH TIME ZONE,
    result JSONB,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    correlation_id UUID -- For linking related tasks across different agents/workflows
);

-- Chat Sessions table for LiveChattingManager
CREATE TABLE chat_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_type session_type_enum NOT NULL,
    status chat_session_status_enum DEFAULT 'active',
    participants TEXT[] DEFAULT ARRAY[]::TEXT[], -- Array of user_ids/agent_ids
    title VARCHAR(255) NOT NULL,
    context JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP WITH TIME ZONE,
    settings JSONB DEFAULT '{}'::jsonb,
    conversation_summary TEXT
);

-- Chat Messages table for LiveChattingManager
CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    user_id VARCHAR(255) NOT NULL, -- Can be user_id or agent_id
    message_type message_type_enum NOT NULL,
    content TEXT NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb,
    replied_to UUID REFERENCES chat_messages(id) ON DELETE SET NULL,
    edited_at TIMESTAMP WITH TIME ZONE,
    attachments TEXT[] DEFAULT ARRAY[]::TEXT[] -- Array of attachment URLs/paths
);

-- Indexes for performance
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_workflow_instance_id ON tasks(workflow_instance_id);
CREATE INDEX idx_tasks_agent_id ON tasks(agent_id);
CREATE INDEX idx_agent_heartbeats_agent_id ON agent_heartbeats(agent_id);
CREATE INDEX idx_agent_capabilities_agent_id ON agent_capabilities(agent_id);
CREATE INDEX idx_api_keys_user_id ON api_keys(user_id);
CREATE INDEX idx_chat_messages_session_id ON chat_messages(session_id);
CREATE INDEX idx_chat_sessions_last_activity ON chat_sessions(last_activity);
CREATE INDEX idx_workflow_instances_workflow_id ON workflow_instances(workflow_id);

-- Triggers for updated_at columns
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_timestamp
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_agents_timestamp
BEFORE UPDATE ON agents
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_workflows_timestamp
BEFORE UPDATE ON workflows
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER update_chat_sessions_timestamp
BEFORE UPDATE ON chat_sessions
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

