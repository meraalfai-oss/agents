#!/usr/bin/env python3
"""
Comprehensive End-to-End Test with Real Data
Tests the complete error classification and fix workflow with actual agents
"""

import json
import subprocess
import sys
import time
from pathlib import Path


class ComprehensiveE2ETest:
    """Run comprehensive E2E tests with real data"""

    def __init__(self):
        self.results = {
            "test_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "tests_passed": 0,
            "tests_failed": 0,
            "test_details": [],
        }

    def log_test(self, test_name: str, passed: bool, details: str = ""):
        """Log test result"""
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} - {test_name}")
        if details:
            print(f"   {details}")

        self.results["test_details"].append(
            {"test": test_name, "passed": passed, "details": details}
        )

        if passed:
            self.results["tests_passed"] += 1
        else:
            self.results["tests_failed"] += 1

    def test_1_analyzer_discovers_real_agents(self) -> bool:
        """Test: Analyzer discovers actual agent files"""
        print("\n1️⃣  Testing: Agent Discovery with Real Files")

        try:
            # Run the analyzer
            result = subprocess.run(
                [sys.executable, "error_classification_analyzer.py"],
                capture_output=True,
                text=True,
                timeout=120,
            )

            # Check if report was generated
            if not Path("error_classification_report.json").exists():
                self.log_test("Agent Discovery", False, "Report file not generated")
                return False

            # Load and validate report
            with open("error_classification_report.json", "r") as f:
                report = json.load(f)

            total_agents = report.get("total_agents", 0)
            successful = report.get("successful", 0)
            failed = report.get("failed", 0)

            # Verify real data
            if total_agents == 0:
                self.log_test("Agent Discovery", False, "No agents discovered")
                return False

            self.log_test(
                "Agent Discovery",
                True,
                f"Discovered {total_agents} agents ({successful} working, {failed} failing)",
            )
            return True

        except Exception as e:
            self.log_test("Agent Discovery", False, f"Error: {str(e)}")
            return False

    def test_2_real_error_classification(self) -> bool:
        """Test: Real errors are classified correctly"""
        print("\n2️⃣  Testing: Real Error Classification")

        try:
            with open("error_classification_report.json", "r") as f:
                report = json.load(f)

            error_dist = report.get("error_distribution", {})

            if not error_dist:
                self.log_test("Error Classification", True, "No errors found (all agents working)")
                return True

            # Check for real error types
            total_errors = sum(error_dist.values())
            details = ", ".join([f"{k}: {v}" for k, v in error_dist.items()])

            self.log_test(
                "Error Classification", True, f"{total_errors} errors classified: {details}"
            )
            return True

        except Exception as e:
            self.log_test("Error Classification", False, f"Error: {str(e)}")
            return False

    def test_3_priority_assignment_real_data(self) -> bool:
        """Test: Priorities assigned to real errors"""
        print("\n3️⃣  Testing: Priority Assignment on Real Data")

        try:
            with open("error_classification_report.json", "r") as f:
                report = json.load(f)

            priorities = report.get("errors_by_priority", {})

            if not priorities:
                self.log_test("Priority Assignment", True, "No errors to prioritize")
                return True

            # Count agents by priority
            priority_counts = {p: len(errors) for p, errors in priorities.items()}
            details = ", ".join([f"P{p}: {c} agents" for p, c in sorted(priority_counts.items())])

            self.log_test("Priority Assignment", True, f"Priorities assigned: {details}")
            return True

        except Exception as e:
            self.log_test("Priority Assignment", False, f"Error: {str(e)}")
            return False

    def test_4_fix_strategies_for_real_errors(self) -> bool:
        """Test: Fix strategies generated for actual errors"""
        print("\n4️⃣  Testing: Fix Strategy Generation")

        try:
            with open("error_classification_report.json", "r") as f:
                report = json.load(f)

            all_errors = report.get("all_errors", [])

            if not all_errors:
                self.log_test("Fix Strategies", True, "No errors require fixes")
                return True

            # Check that each error has a fix strategy
            errors_with_fixes = sum(1 for e in all_errors if e.get("fix_strategy"))

            if errors_with_fixes != len(all_errors):
                self.log_test(
                    "Fix Strategies",
                    False,
                    f"Only {errors_with_fixes}/{len(all_errors)} errors have fix strategies",
                )
                return False

            # Count unique fix strategies
            strategies = set(e.get("fix_strategy") for e in all_errors)
            pip_installs = sum(1 for s in strategies if s and "pip install" in s)

            self.log_test(
                "Fix Strategies",
                True,
                f"{len(strategies)} unique strategies ({pip_installs} automated)",
            )
            return True

        except Exception as e:
            self.log_test("Fix Strategies", False, f"Error: {str(e)}")
            return False

    def test_5_install_script_generation(self) -> bool:
        """Test: Installation script generation with real packages"""
        print("\n5️⃣  Testing: Install Script Generation")

        try:
            # Run fix tool to generate script
            result = subprocess.run(
                [sys.executable, "fix_agent_errors.py", "--generate-script"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if not Path("install_agent_dependencies.sh").exists():
                self.log_test("Install Script", False, "Script not generated")
                return False

            # Check script content
            with open("install_agent_dependencies.sh", "r") as f:
                script_content = f.read()

            if "pip install" not in script_content:
                self.log_test("Install Script", False, "No pip install commands")
                return False

            # Count install commands
            install_count = script_content.count("python3 -m pip install")

            self.log_test(
                "Install Script", True, f"Generated with {install_count} package installations"
            )
            return True

        except Exception as e:
            self.log_test("Install Script", False, f"Error: {str(e)}")
            return False

    def test_6_real_agent_import_test(self) -> bool:
        """Test: Actually import real agent files"""
        print("\n6️⃣  Testing: Real Agent Import Verification")

        try:
            agents_dir = Path("agents")
            if not agents_dir.exists():
                self.log_test("Agent Import", True, "No agents directory (root-level agents)")
                return True

            # Try to import a few agents
            agent_files = list(agents_dir.glob("*_agent.py"))[:3]

            if not agent_files:
                self.log_test("Agent Import", True, "No agent files to test")
                return True

            imported = 0
            failed = 0

            for agent_file in agent_files:
                try:
                    import importlib.util

                    spec = importlib.util.spec_from_file_location(agent_file.stem, agent_file)
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        imported += 1
                except Exception:
                    failed += 1

            self.log_test(
                "Agent Import", True, f"Sample test: {imported} imported, {failed} failed"
            )
            return True

        except Exception as e:
            self.log_test("Agent Import", False, f"Error: {str(e)}")
            return False

    def test_7_error_distribution_accuracy(self) -> bool:
        """Test: Error distribution matches actual errors"""
        print("\n7️⃣  Testing: Error Distribution Accuracy")

        try:
            with open("error_classification_report.json", "r") as f:
                report = json.load(f)

            total_agents = report.get("total_agents", 0)
            successful = report.get("successful", 0)
            failed = report.get("failed", 0)

            # Verify math
            if successful + failed != total_agents:
                self.log_test(
                    "Error Distribution",
                    False,
                    f"Math error: {successful} + {failed} != {total_agents}",
                )
                return False

            # Check error distribution sums to failed count
            error_dist = report.get("error_distribution", {})
            total_classified = sum(error_dist.values())

            if total_classified != failed:
                self.log_test(
                    "Error Distribution",
                    False,
                    f"Classification error: {total_classified} classified but {failed} failed",
                )
                return False

            success_rate = (successful / total_agents * 100) if total_agents > 0 else 0

            self.log_test(
                "Error Distribution",
                True,
                f"Accurate: {success_rate:.1f}% success rate ({successful}/{total_agents})",
            )
            return True

        except Exception as e:
            self.log_test("Error Distribution", False, f"Error: {str(e)}")
            return False

    def test_8_end_to_end_workflow(self) -> bool:
        """Test: Complete E2E workflow"""
        print("\n8️⃣  Testing: Complete E2E Workflow")

        try:
            # 1. Analyze
            subprocess.run(
                [sys.executable, "error_classification_analyzer.py"],
                capture_output=True,
                text=True,
                timeout=120,
            )

            # 2. Generate script
            subprocess.run(
                [sys.executable, "fix_agent_errors.py", "--generate-script"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            # 3. Validate with tests
            result = subprocess.run(
                [sys.executable, "test_error_classification.py"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            # Check if validation tests passed
            if "failed" in result.stdout.lower() and "0 failed" not in result.stdout.lower():
                self.log_test("E2E Workflow", False, "Validation tests failed")
                return False

            self.log_test("E2E Workflow", True, "Complete workflow: Analyze → Generate → Validate")
            return True

        except Exception as e:
            self.log_test("E2E Workflow", False, f"Error: {str(e)}")
            return False

    def test_9_real_package_identification(self) -> bool:
        """Test: Identify real packages from errors"""
        print("\n9️⃣  Testing: Real Package Identification")

        try:
            with open("error_classification_report.json", "r") as f:
                report = json.load(f)

            all_errors = report.get("all_errors", [])

            # Extract unique packages
            packages = set()
            for error in all_errors:
                missing = error.get("missing_module", "")
                if missing:
                    packages.add(missing)

            if not packages:
                self.log_test("Package Identification", True, "No missing packages")
                return True

            # List actual packages found
            package_list = ", ".join(sorted(packages)[:5])
            if len(packages) > 5:
                package_list += f", ... (+{len(packages)-5} more)"

            self.log_test(
                "Package Identification", True, f"{len(packages)} unique packages: {package_list}"
            )
            return True

        except Exception as e:
            self.log_test("Package Identification", False, f"Error: {str(e)}")
            return False

    def test_10_report_completeness(self) -> bool:
        """Test: Reports contain all required information"""
        print("\n🔟 Testing: Report Completeness")

        try:
            # Check JSON report
            with open("error_classification_report.json", "r") as f:
                json_report = json.load(f)

            required_keys = [
                "total_agents",
                "successful",
                "failed",
                "success_rate",
                "error_distribution",
                "errors_by_priority",
                "all_errors",
            ]

            missing_keys = [k for k in required_keys if k not in json_report]

            if missing_keys:
                self.log_test(
                    "Report Completeness", False, f"Missing keys: {', '.join(missing_keys)}"
                )
                return False

            # Check text report exists
            if not Path("error_classification_report.txt").exists():
                self.log_test("Report Completeness", False, "Text report missing")
                return False

            self.log_test(
                "Report Completeness", True, "All required fields present in both reports"
            )
            return True

        except Exception as e:
            self.log_test("Report Completeness", False, f"Error: {str(e)}")
            return False

    def run_all_tests(self):
        """Run all E2E tests"""
        print("=" * 80)
        print("COMPREHENSIVE END-TO-END TEST WITH REAL DATA")
        print("=" * 80)

        tests = [
            self.test_1_analyzer_discovers_real_agents,
            self.test_2_real_error_classification,
            self.test_3_priority_assignment_real_data,
            self.test_4_fix_strategies_for_real_errors,
            self.test_5_install_script_generation,
            self.test_6_real_agent_import_test,
            self.test_7_error_distribution_accuracy,
            self.test_8_end_to_end_workflow,
            self.test_9_real_package_identification,
            self.test_10_report_completeness,
        ]

        for test in tests:
            test()

        # Print summary
        print("\n" + "=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        print(f"Tests Passed:  {self.results['tests_passed']}")
        print(f"Tests Failed:  {self.results['tests_failed']}")
        print(f"Total Tests:   {self.results['tests_passed'] + self.results['tests_failed']}")
        print(
            f"Success Rate:  {(self.results['tests_passed']/(self.results['tests_passed']+self.results['tests_failed'])*100):.1f}%"
        )
        print("=" * 80)

        # Save results
        with open("e2e_test_results_real.json", "w") as f:
            json.dump(self.results, f, indent=2)

        print(f"\nDetailed results saved to: e2e_test_results_real.json")

        return self.results["tests_failed"] == 0


if __name__ == "__main__":
    tester = ComprehensiveE2ETest()
    success = tester.run_all_tests()
    sys.exit(0 if success else 1)
