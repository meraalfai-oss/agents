"""
Shared Agent Utilities
Common utility functions for all agents
"""

import json
import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def load_config(config_path: str) -> Dict[str, Any]:
    """Load configuration from JSON file."""
    try:
        with open(config_path, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load config from {config_path}: {e}")
        return {}


def save_config(config: Dict[str, Any], config_path: str):
    """Save configuration to JSON file."""
    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save config to {config_path}: {e}")


def get_env_var(key: str, default: Any = None) -> Any:
    """Get environment variable with default."""
    return os.getenv(key, default)


def validate_payload(payload: Dict[str, Any], required_keys: list) -> tuple[bool, Optional[str]]:
    """Validate payload has required keys."""
    missing = [key for key in required_keys if key not in payload]
    if missing:
        return False, f"Missing required keys: {missing}"
    return True, None


class DataCache:
    """Simple in-memory cache for agents."""

    def __init__(self):
        self._cache: Dict[str, Any] = {}

    def get(self, key: str, default: Any = None) -> Any:
        return self._cache.get(key, default)

    def set(self, key: str, value: Any):
        self._cache[key] = value

    def delete(self, key: str):
        if key in self._cache:
            del self._cache[key]

    def clear(self):
        self._cache.clear()

    def keys(self) -> list:
        return list(self._cache.keys())


__all__ = ["load_config", "save_config", "get_env_var", "validate_payload", "DataCache"]
