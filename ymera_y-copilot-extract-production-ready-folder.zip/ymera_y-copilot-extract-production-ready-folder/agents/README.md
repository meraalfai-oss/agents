# YMERA Agents Framework

**Version**: 1.0.0  
**Status**: Production Ready  
**Created**: 2025-10-20

---

## Overview

The YMERA Agents Framework provides a standardized, robust foundation for building autonomous agents with consistent behavior, error handling, and observability.

---

## Quick Start

### Installation

The framework is part of the YMERA platform. No separate installation required.

### Basic Usage

```python
from agents.agent_base import (
    BaseAgent,
    AgentConfig,
    AgentCapability,
    TaskRequest,
    TaskResponse,
    Priority
)

# Define your agent
class MyAgent(BaseAgent):
    def __init__(self):
        capabilities = [
            AgentCapability(
                name="my_capability",
                description="Does something useful",
                task_types=["my_task"],
                required_params=["input"]
            )
        ]
        
        config = AgentConfig(
            name="MyAgent",
            description="My custom agent",
            capabilities=capabilities
        )
        
        super().__init__(config)
    
    def _execute_task(self, task: TaskRequest):
        # Your task logic here
        return {"result": "success"}

# Use your agent
agent = MyAgent()
task = TaskRequest(
    task_type="my_task",
    priority=Priority.MEDIUM,
    payload={"input": "data"}
)
response = agent.process_task(task)
```

---

## Architecture

### Core Components

1. **BaseAgent** - Foundation class for all agents
   - Task processing pipeline
   - Error handling
   - Logging and statistics
   - Health checks

2. **AgentConfig** - Configuration management
   - Agent metadata
   - Operational parameters
   - Capability definitions

3. **TaskRequest** - Standardized request format
   - Unique task ID
   - Task type and priority
   - Payload and metadata
   - Timeout configuration

4. **TaskResponse** - Standardized response format
   - Task status
   - Result or error
   - Execution metrics
   - Completion timestamp

5. **AgentCapability** - Capability descriptor
   - Capability name and description
   - Supported task types
   - Required parameters

---

## Features

### ✅ Standardized Interface
- Consistent API across all agents
- Predictable behavior
- Easy integration

### ✅ Robust Error Handling
- Try-catch on all operations
- Detailed error messages
- Graceful degradation

### ✅ Built-in Observability
- Automatic logging
- Task statistics
- Health checks
- Performance metrics

### ✅ Type Safety
- Full type hints
- Dataclass validation
- Enum constraints

### ✅ Extensibility
- Simple inheritance model
- Override only what you need
- Plugin-ready architecture

---

## Example Agents

### 1. Calculator Agent
Mathematical operations with error handling.

**File**: `agents/calculator_agent.py`

**Capabilities**:
- Basic arithmetic (add, subtract, multiply, divide)
- Advanced math (power, sqrt, modulo)

**Task Types**: 7

### 2. Data Processor Agent
Data transformation and analysis.

**File**: `agents/data_processor_agent.py`

**Capabilities**:
- Data transformation
- Data filtering
- Data aggregation

**Task Types**: 4

### 3. Example Agent
Demonstrates the fix pattern.

**File**: `agents/example_agent_fixed.py`

**Capabilities**:
- Example processing
- Echo service

**Task Types**: 2

---

## API Reference

### BaseAgent

#### Methods

**`__init__(config: AgentConfig)`**
Initialize agent with configuration.

**`process_task(task: TaskRequest) -> TaskResponse`**
Process a task request. Main entry point.

**`health_check() -> Dict[str, Any]`**
Get agent health and status.

**`get_info() -> Dict[str, Any]`**
Get agent metadata and capabilities.

**`get_supported_task_types() -> List[str]`**
Get list of supported task types.

**`reset_stats()`**
Reset task statistics.

#### Abstract Methods

**`_execute_task(task: TaskRequest) -> Any`**
Execute task logic. Must be overridden by subclasses.

---

### AgentConfig

#### Fields

- `agent_id`: Unique agent identifier (auto-generated)
- `name`: Agent name
- `description`: Agent description
- `capabilities`: List of AgentCapability objects
- `max_concurrent_tasks`: Max parallel tasks (default: 10)
- `task_timeout`: Task timeout in seconds (default: 300)
- `retry_attempts`: Number of retry attempts (default: 3)
- `log_level`: Logging level (default: "INFO")

---

### TaskRequest

#### Fields

- `task_id`: Unique task identifier (auto-generated)
- `task_type`: Type of task to execute
- `priority`: Task priority (LOW, MEDIUM, HIGH, CRITICAL)
- `payload`: Task data dictionary
- `timeout`: Task timeout in seconds (default: 300)
- `created_at`: Creation timestamp (auto-generated)
- `metadata`: Additional metadata dictionary

#### Methods

**`to_dict() -> Dict[str, Any]`**
Convert to dictionary for serialization.

---

### TaskResponse

#### Fields

- `task_id`: Task identifier (from request)
- `status`: Task status (SUCCESS, ERROR, TIMEOUT, etc.)
- `result`: Task result (if successful)
- `error`: Error message (if failed)
- `execution_time`: Execution time in seconds
- `completed_at`: Completion timestamp (auto-generated)
- `metadata`: Additional metadata dictionary

#### Methods

**`to_dict() -> Dict[str, Any]`**
Convert to dictionary for serialization.

---

## Development Guide

### Creating a New Agent

1. **Create agent file** in `agents/` directory
2. **Import base classes** from `agents.agent_base`
3. **Define capabilities** as AgentCapability objects
4. **Create config** with AgentConfig
5. **Implement _execute_task()** method
6. **Add standalone tests** in `__main__`
7. **Test thoroughly** before deployment

See `AGENT_FIX_GUIDE.md` for detailed instructions and template.

---

## Testing

### Unit Testing

Each agent should include standalone tests in the `__main__` block:

```python
if __name__ == "__main__":
    agent = MyAgent()
    
    # Test 1: Health check
    health = agent.health_check()
    assert health["status"] == "healthy"
    
    # Test 2: Task processing
    task = TaskRequest(...)
    response = agent.process_task(task)
    assert response.status == TaskStatus.SUCCESS
```

### Running Tests

```bash
# Test a specific agent
python3 agents/calculator_agent.py

# Test all agents
for agent in agents/*_agent.py; do
    python3 "$agent" && echo "✅ $agent" || echo "❌ $agent"
done
```

---

## Statistics

### Agent Framework Stats

- **Total Example Agents**: 3
- **Test Pass Rate**: 100%
- **Task Types Covered**: 13
- **Lines of Code**: ~500 (base framework)

### Fixed Agents Performance

| Agent | Task Types | Tests | Pass Rate |
|-------|-----------|-------|-----------|
| Example | 2 | 6 | 100% ✅ |
| Calculator | 7 | 7 | 100% ✅ |
| DataProcessor | 4 | 5 | 100% ✅ |

---

## Troubleshooting

### Import Error: No module named 'agents'

**Solution**: Add parent directory to Python path:
```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
```

### ValidationError: Missing required parameters

**Solution**: Check AgentConfig has all required fields:
```python
config = AgentConfig(
    name="MyAgent",  # Required
    description="Description",  # Required
    capabilities=[]  # Required
)
```

### Task fails with "Unsupported task type"

**Solution**: Ensure task_type matches capability definition:
```python
capabilities = [
    AgentCapability(
        task_types=["my_task"]  # Must match request
    )
]
```

---

## Contributing

### Guidelines

1. Follow the standard agent pattern
2. Include comprehensive tests
3. Document all capabilities
4. Use type hints
5. Handle errors gracefully
6. Log important operations
7. Update this README

### Code Style

- PEP 8 compliant
- Type hints required
- Docstrings for all public methods
- Clear variable names
- Comments for complex logic

---

## Resources

- **Fix Guide**: `AGENT_FIX_GUIDE.md`
- **Fix Log**: `fix_log.md`
- **Dependency Analysis**: `agent_dependency_analysis_new.json`
- **Base Module**: `agents/agent_base.py`
- **Utilities**: `agents/shared_utils.py`

---

## License

Part of the YMERA platform. See main repository LICENSE.

---

## Changelog

### Version 1.0.0 (2025-10-20)

- Initial release
- BaseAgent framework
- Example agents
- Documentation
- Testing infrastructure

---

## Support

For issues or questions:
1. Check `AGENT_FIX_GUIDE.md`
2. Review example agents
3. Check `fix_log.md`
4. Run standalone tests

---

**Last Updated**: 2025-10-20  
**Maintained By**: YMERA Platform Team
