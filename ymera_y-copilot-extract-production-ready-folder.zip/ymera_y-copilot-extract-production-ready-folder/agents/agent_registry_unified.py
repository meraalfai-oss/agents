"""
Agent Registry
Manages all agent instances
"""

import logging
from typing import Dict, List

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Registry to track and manage agent instances."""

    def __init__(self):
        self._agents: Dict[str, Any] = {}

    def register(self, agent):
        """Register an agent."""
        if agent.agent_id in self._agents:
            logger.warning(f"Agent {agent.agent_id} already registered, overwriting")

        self._agents[agent.agent_id] = agent
        logger.info(f"Registered agent: {agent.name} ({agent.agent_id})")

    def unregister(self, agent_id: str) -> bool:
        """Unregister an agent."""
        if agent_id in self._agents:
            agent = self._agents.pop(agent_id)
            logger.info(f"Unregistered agent: {agent.name} ({agent_id})")
            return True
        return False

    def get(self, agent_id: str):
        """Get agent by ID."""
        return self._agents.get(agent_id)

    def get_by_name(self, name: str):
        """Get agent by name."""
        for agent in self._agents.values():
            if agent.name == name:
                return agent
        return None

    def list_all(self) -> List:
        """List all registered agents."""
        return list(self._agents.values())

    def list_by_capability(self, capability_name: str) -> List:
        """List agents with specific capability."""
        result = []
        for agent in self._agents.values():
            for cap in agent.capabilities:
                if cap.name == capability_name:
                    result.append(agent)
                    break
        return result

    def health_check_all(self) -> Dict[str, Dict]:
        """Run health check on all agents."""
        results = {}
        for agent_id, agent in self._agents.items():
            try:
                results[agent_id] = agent.health_check()
            except Exception as e:
                results[agent_id] = {"status": "unhealthy", "error": str(e)}
        return results

    def clear(self):
        """Clear all agents from registry."""
        self._agents.clear()
        logger.info("Agent registry cleared")


# Global registry instance
_global_registry = AgentRegistry()


def get_registry() -> AgentRegistry:
    """Get global registry instance."""
    return _global_registry


__all__ = ["AgentRegistry", "get_registry"]
