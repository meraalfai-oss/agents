---
name: Feature Request
about: Request a new feature for Copilot to implement
---

## Feature Description
[Clear description of what you want]

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Tests pass

## Files to Modify/Create
- path/to/file.py
- path/to/test_file.py

## Testing Requirements
- [ ] Unit tests with 80% coverage
- [ ] Integration test for API endpoint
- [ ] Manual verification steps

## Related Documentation
- Link to relevant docs or PRs
