# GitHub Copilot Instructions for YMERA Backend

## Project Context
This is a multi-agent Python backend platform with 163 agents. We're systematically fixing agents from least dependent to most dependent to achieve production readiness.

## Current Mission
Fix agents in dependency order:
- **Level 0:** Independent agents (no internal dependencies) - ✅ COMPLETE (6 agents fixed)
- **Level 1:** Agents depending only on base_agent - ✅ TEMPLATE READY (27 agents ready)
- **Level 2:** Agents with 3-5 dependencies - ⏭️ NEXT
- **Level 3:** Complex agents with 6+ dependencies - ⏭️ FUTURE

## Code Standards

### Import Pattern (CRITICAL)
```python
# ALWAYS use this import pattern for Level 1+ agents:
from base_agent import (
    BaseAgent,
    AgentStatus,
    Priority,
    TaskStatus
)

# With graceful fallback:
try:
    from base_agent import BaseAgent, AgentStatus, Priority, TaskStatus
    HAS_BASE_AGENT = True
except ImportError:
    BaseAgent = object
    HAS_BASE_AGENT = False

# NEVER use:
from agent_base import BaseAgent  # Wrong module name
import sys; sys.path.append(...)  # Avoid path manipulation
```

## Agent Structure (MANDATORY)

Every agent must include:
1. Comprehensive docstring with status, dependencies, capabilities
2. Proper inheritance (BaseAgentMinimal for Level 0, BaseAgent for Level 1+)
3. Required methods: __init__, process_task, health_check, get_capabilities
4. Error handling with try/except
5. Logging (self.logger)
6. Metrics tracking
7. Standalone test in __main__

## Quality Checklist

### Level 0 (10 criteria)
- No external imports, BaseAgentMinimal embedded, proper error handling, logging, health check, standalone test, docstrings, no syntax/import errors, task processing functional

### Level 1 (12 criteria)
- Imports from base_agent with try/except, HAS_BASE_AGENT flag, inherits BaseAgent, async processing, error handling, logging, health check, metrics, standalone test with asyncio, docstrings, no syntax errors, graceful degradation

## Current Status
- **Completed:** Error classification, E2E testing, dependency analysis, Level 0 & 1 templates
- **In Progress:** Level 1 batch fixing
- **Success Rate:** 57.8% → 64.4% (Level 0) → 93.3% (Level 1 projected)

See full documentation in ERROR_CLASSIFICATION_COMPLETE.md
