# Quick Migration Guide

## Push Repository to New Location: `https://github.com/meraalfai-oss/agents.git`

### ⚡ Fastest Method - Using the Script

```bash
# Make script executable (if not already)
chmod +x migrate_to_new_repo.sh

# Run the migration script
./migrate_to_new_repo.sh
```

The script will:
- ✅ Verify repository status
- ✅ Add the new remote
- ✅ Push all branches
- ✅ Push all tags
- ✅ Verify the migration
- ✅ Provide next steps

### 🔧 Manual Method - Step by Step

```bash
# 1. Add new remote
git remote add meraalfai https://github.com/meraalfai-oss/agents.git

# 2. Push all branches
git push meraalfai --all

# 3. Push all tags (if any)
git push meraalfai --tags

# 4. Verify
git ls-remote meraalfai
```

### 🔐 Authentication

You'll need GitHub credentials when pushing. Choose one:

**Option A: HTTPS with Token**
```bash
# GitHub will prompt for username and token
# Username: your-github-username
# Password: your-personal-access-token
```

**Option B: SSH**
```bash
# Use SSH URL instead
git remote add meraalfai git@github.com:meraalfai-oss/agents.git
```

**Create Personal Access Token:**
1. Go to: https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Select scopes: `repo` (full control)
4. Copy the token (you won't see it again!)

### ✅ Verification

After migration, check:

```bash
# View new remote
git remote -v

# List remote branches
git ls-remote meraalfai

# Compare commit count
git rev-list --all --count
```

### 📊 Repository Size

Current repository statistics:
- **Files:** 1,259 files
- **Size:** ~26 MB (excluding .git)
- **Branches:** 1 branch (copilot/vscode1761236490170)
- **Status:** Clean working tree ✓

### 🚨 Important Notes

1. **Security Check:**
   - Review `.env` file for secrets before pushing
   - Verify no API keys in code
   - Check `.gitignore` is comprehensive

2. **Large Files:**
   - `ymera_agents_standalone.tar.gz` (2.4MB) will be included
   - All other files are < 1MB

3. **Working Tree:**
   - Currently clean with no uncommitted changes ✓
   - Safe to proceed

### 📝 Post-Migration

1. Visit https://github.com/meraalfai-oss/agents to verify
2. Configure repository settings:
   - Description
   - Topics/tags
   - Branch protection
   - Collaborators
3. Update documentation with new URL
4. Configure GitHub Actions (if needed)

### 🔍 Troubleshooting

**Authentication Failed:**
```bash
# Clear credentials and try again
git credential reject
# Proceed with push
```

**Push Rejected:**
```bash
# Ensure repository exists and you have write access
# Check: https://github.com/meraalfai-oss/agents/settings
```

**Large Files Warning:**
```bash
# If you see warnings about large files, continue anyway
# All files in this repo are under GitHub's limits
```

### 📚 Full Documentation

For detailed documentation, see: [MIGRATION_TO_NEW_REPO.md](./MIGRATION_TO_NEW_REPO.md)

---

**Ready to migrate?** Run: `./migrate_to_new_repo.sh`
