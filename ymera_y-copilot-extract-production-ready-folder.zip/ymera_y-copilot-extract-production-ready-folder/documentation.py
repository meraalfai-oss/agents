# api/documentation.py
"""
API documentation with OpenAPI specifications
"""

from fastapi import FastAPI
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.openapi.utils import get_openapi


def setup_documentation(app: FastAPI) -> None:
    """Setup custom OpenAPI documentation"""

    @app.get("/api/docs", include_in_schema=False)
    async def custom_swagger_ui_html():
        """Custom Swagger UI with branding"""
        return get_swagger_ui_html(
            openapi_url="/api/openapi.json",
            title="YMERA Enterprise Agent Manager API",
            swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@4.15.5/swagger-ui-bundle.js",
            swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@4.15.5/swagger-ui.css",
            swagger_favicon_url="/static/favicon.ico",
        )

    @app.get("/api/redoc", include_in_schema=False)
    async def redoc_html():
        """ReDoc documentation"""
        return get_redoc_html(
            openapi_url="/api/openapi.json",
            title="YMERA Enterprise Agent Manager API",
            redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@2.0.0-rc.55/bundles/redoc.standalone.js",
            redoc_favicon_url="/static/favicon.ico",
        )

    @app.get("/api/openapi.json", include_in_schema=False)
    async def get_openapi_endpoint():
        """Custom OpenAPI schema generator"""
        return get_custom_openapi(app)


def get_custom_openapi(app: FastAPI):
    """Generate custom OpenAPI schema with enhanced documentation"""
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title="YMERA Enterprise Agent Manager API",
        version="2.0.0",
        description="""
        Enterprise-grade Agent Management Platform

        This API provides comprehensive management capabilities for agents including:
        * Mandatory reporting with escalating consequences
        * Zero-trust security architecture
        * Administrative approval workflows
        * Comprehensive monitoring and anomaly detection

        ## Authentication

        All API requests require authentication using one of these methods:
        * OAuth2 Bearer token (for users and applications)
        * API keys (for agents)
        * mTLS certificates (for service-to-service communication)

        ## Rate Limiting

        API endpoints are protected by rate limiting. Exceed limits will result in
        HTTP 429 (Too Many Requests) responses.
        """,
        routes=app.routes,
    )

    # Enhanced security schemes
    openapi_schema["components"]["securitySchemes"] = {
        "OAuth2": {
            "type": "oauth2",
            "flows": {
                "authorizationCode": {
                    "authorizationUrl": "/auth/authorize",
                    "tokenUrl": "/auth/token",
                    "scopes": {
                        "read:agents": "Read agent information",
                        "write:agents": "Create and update agents",
                        "read:tasks": "Read task information",
                        "write:tasks": "Create and manage tasks",
                        "admin": "Administrative access",
                    },
                }
            },
        },
        "ApiKey": {"type": "apiKey", "in": "header", "name": "X-API-Key"},
    }

    # Apply to all routes
    openapi_schema["security"] = [{"OAuth2": ["read:agents", "read:tasks"]}, {"ApiKey": []}]

    # Custom OpenAPI extensions
    openapi_schema["info"]["x-logo"] = {"url": "/static/logo.png"}

    # Add tags
    openapi_schema["tags"] = [
        {"name": "agents", "description": "Agent management operations"},
        {"name": "tasks", "description": "Task assignment and execution"},
        {"name": "admin", "description": "Administrative operations"},
        {"name": "monitoring", "description": "System monitoring and health checks"},
        {"name": "security", "description": "Security operations and audit logs"},
    ]

    # Version deprecated APIs
    for path in openapi_schema["paths"]:
        for method in openapi_schema["paths"][path]:
            # Skip non-operation keys like parameters
            if method not in ["get", "post", "put", "delete", "patch"]:
                continue

            # Add deprecation notices for v1 APIs
            if "/v1/" in path:
                openapi_schema["paths"][path][method]["deprecated"] = True
                openapi_schema["paths"][path][method]["description"] = (
                    openapi_schema["paths"][path][method].get("description", "")
                    + "\n\n**Deprecated**: Please use v2 API endpoints instead."
                )

    app.openapi_schema = openapi_schema
    return app.openapi_schema
