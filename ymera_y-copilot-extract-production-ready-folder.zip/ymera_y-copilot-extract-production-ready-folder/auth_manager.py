"""
Authentication and Authorization Manager
Phase 4: Production Readiness - Security Hardening
"""

import logging
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set
from enum import Enum

try:
    from jose import jwt, JWTError
    from passlib.context import CryptContext
    HAS_AUTH_LIBS = True
except ImportError:
    HAS_AUTH_LIBS = False
    logging.warning("Auth libraries not available - install python-jose and passlib")

logger = logging.getLogger(__name__)


class Role(str, Enum):
    """User roles for RBAC"""
    ADMIN = "admin"
    USER = "user"
    AGENT = "agent"
    READONLY = "readonly"


class Permission(str, Enum):
    """Permissions for fine-grained access control"""
    # Project permissions
    PROJECT_CREATE = "project:create"
    PROJECT_READ = "project:read"
    PROJECT_UPDATE = "project:update"
    PROJECT_DELETE = "project:delete"
    
    # Task permissions
    TASK_CREATE = "task:create"
    TASK_READ = "task:read"
    TASK_UPDATE = "task:update"
    TASK_DELETE = "task:delete"
    
    # Agent permissions
    AGENT_CREATE = "agent:create"
    AGENT_READ = "agent:read"
    AGENT_UPDATE = "agent:update"
    AGENT_DELETE = "agent:delete"
    AGENT_EXECUTE = "agent:execute"
    
    # Admin permissions
    USER_MANAGE = "user:manage"
    SYSTEM_CONFIGURE = "system:configure"
    AUDIT_VIEW = "audit:view"


# Role-Permission mapping
ROLE_PERMISSIONS: Dict[Role, Set[Permission]] = {
    Role.ADMIN: {
        # All permissions
        *[p for p in Permission],
    },
    Role.USER: {
        Permission.PROJECT_CREATE,
        Permission.PROJECT_READ,
        Permission.PROJECT_UPDATE,
        Permission.PROJECT_DELETE,
        Permission.TASK_CREATE,
        Permission.TASK_READ,
        Permission.TASK_UPDATE,
        Permission.TASK_DELETE,
        Permission.AGENT_READ,
        Permission.AGENT_EXECUTE,
    },
    Role.AGENT: {
        Permission.TASK_READ,
        Permission.TASK_UPDATE,
        Permission.AGENT_READ,
    },
    Role.READONLY: {
        Permission.PROJECT_READ,
        Permission.TASK_READ,
        Permission.AGENT_READ,
        Permission.AUDIT_VIEW,
    },
}


class AuthManager:
    """
    Authentication and Authorization Manager
    
    Features:
    - Password hashing with bcrypt
    - JWT token generation and validation
    - Refresh token flow
    - Role-Based Access Control (RBAC)
    - API key management
    - Session management
    """

    def __init__(
        self,
        secret_key: str,
        algorithm: str = "HS256",
        access_token_expire_minutes: int = 30,
        refresh_token_expire_days: int = 7,
    ):
        """
        Initialize auth manager
        
        Args:
            secret_key: Secret key for JWT signing
            algorithm: JWT algorithm (default: HS256)
            access_token_expire_minutes: Access token expiration
            refresh_token_expire_days: Refresh token expiration
        """
        if not HAS_AUTH_LIBS:
            raise ImportError("Auth libraries required: pip install python-jose[cryptography] passlib[bcrypt]")
        
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expire_minutes = access_token_expire_minutes
        self.refresh_token_expire_days = refresh_token_expire_days
        
        # Password hashing
        self.pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        
        # API keys storage (in production, use database)
        self.api_keys: Dict[str, Dict] = {}
        
        # Active sessions (in production, use Redis)
        self.active_sessions: Dict[str, Dict] = {}
        
        logger.info("AuthManager initialized with RBAC support")

    def hash_password(self, password: str) -> str:
        """Hash a password using bcrypt"""
        return self.pwd_context.hash(password)

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a password against hash"""
        return self.pwd_context.verify(plain_password, hashed_password)

    def create_access_token(
        self,
        user_id: str,
        username: str,
        role: Role,
        additional_claims: Optional[Dict] = None,
    ) -> str:
        """
        Create JWT access token
        
        Args:
            user_id: User ID
            username: Username
            role: User role
            additional_claims: Additional JWT claims
            
        Returns:
            JWT access token
        """
        expires = datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)
        
        claims = {
            "sub": user_id,
            "username": username,
            "role": role.value,
            "type": "access",
            "exp": expires,
            "iat": datetime.utcnow(),
        }
        
        if additional_claims:
            claims.update(additional_claims)
        
        token = jwt.encode(claims, self.secret_key, algorithm=self.algorithm)
        return token

    def create_refresh_token(self, user_id: str) -> str:
        """
        Create JWT refresh token
        
        Args:
            user_id: User ID
            
        Returns:
            JWT refresh token
        """
        expires = datetime.utcnow() + timedelta(days=self.refresh_token_expire_days)
        
        claims = {
            "sub": user_id,
            "type": "refresh",
            "exp": expires,
            "iat": datetime.utcnow(),
        }
        
        token = jwt.encode(claims, self.secret_key, algorithm=self.algorithm)
        return token

    def decode_token(self, token: str) -> Optional[Dict]:
        """
        Decode and validate JWT token
        
        Args:
            token: JWT token
            
        Returns:
            Decoded token claims or None if invalid
        """
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return payload
        except JWTError as e:
            logger.warning(f"Token validation failed: {e}")
            return None

    def refresh_access_token(
        self,
        refresh_token: str,
        username: str,
        role: Role,
    ) -> Optional[str]:
        """
        Create new access token from refresh token
        
        Args:
            refresh_token: Valid refresh token
            username: Username
            role: User role
            
        Returns:
            New access token or None if refresh token invalid
        """
        payload = self.decode_token(refresh_token)
        
        if not payload:
            return None
        
        if payload.get("type") != "refresh":
            logger.warning("Token is not a refresh token")
            return None
        
        user_id = payload.get("sub")
        if not user_id:
            return None
        
        # Create new access token
        return self.create_access_token(user_id, username, role)

    def generate_api_key(
        self,
        user_id: str,
        name: str,
        permissions: Optional[List[Permission]] = None,
        expires_days: Optional[int] = None,
    ) -> str:
        """
        Generate API key for programmatic access
        
        Args:
            user_id: User ID
            name: API key name/description
            permissions: Specific permissions (None = all user permissions)
            expires_days: Expiration in days (None = no expiration)
            
        Returns:
            API key
        """
        api_key = f"ymera_{secrets.token_urlsafe(32)}"
        
        key_data = {
            "user_id": user_id,
            "name": name,
            "permissions": [p.value for p in permissions] if permissions else None,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (
                (datetime.utcnow() + timedelta(days=expires_days)).isoformat()
                if expires_days
                else None
            ),
            "last_used": None,
        }
        
        self.api_keys[api_key] = key_data
        logger.info(f"API key generated for user {user_id}: {name}")
        
        return api_key

    def validate_api_key(self, api_key: str) -> Optional[Dict]:
        """
        Validate API key
        
        Args:
            api_key: API key to validate
            
        Returns:
            Key data if valid, None otherwise
        """
        if api_key not in self.api_keys:
            return None
        
        key_data = self.api_keys[api_key]
        
        # Check expiration
        if key_data["expires_at"]:
            expires_at = datetime.fromisoformat(key_data["expires_at"])
            if datetime.utcnow() > expires_at:
                logger.info(f"API key expired: {key_data['name']}")
                return None
        
        # Update last used
        key_data["last_used"] = datetime.utcnow().isoformat()
        
        return key_data

    def revoke_api_key(self, api_key: str) -> bool:
        """
        Revoke API key
        
        Args:
            api_key: API key to revoke
            
        Returns:
            Success status
        """
        if api_key in self.api_keys:
            del self.api_keys[api_key]
            logger.info(f"API key revoked")
            return True
        return False

    def check_permission(self, role: Role, permission: Permission) -> bool:
        """
        Check if role has permission
        
        Args:
            role: User role
            permission: Required permission
            
        Returns:
            True if authorized
        """
        return permission in ROLE_PERMISSIONS.get(role, set())

    def create_session(
        self,
        user_id: str,
        session_data: Optional[Dict] = None,
        expires_hours: int = 24,
    ) -> str:
        """
        Create user session
        
        Args:
            user_id: User ID
            session_data: Additional session data
            expires_hours: Session expiration in hours
            
        Returns:
            Session ID
        """
        session_id = secrets.token_urlsafe(32)
        
        session = {
            "user_id": user_id,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + timedelta(hours=expires_hours)).isoformat(),
            "data": session_data or {},
        }
        
        self.active_sessions[session_id] = session
        return session_id

    def validate_session(self, session_id: str) -> Optional[Dict]:
        """
        Validate session
        
        Args:
            session_id: Session ID
            
        Returns:
            Session data if valid, None otherwise
        """
        if session_id not in self.active_sessions:
            return None
        
        session = self.active_sessions[session_id]
        
        # Check expiration
        expires_at = datetime.fromisoformat(session["expires_at"])
        if datetime.utcnow() > expires_at:
            del self.active_sessions[session_id]
            return None
        
        return session

    def invalidate_session(self, session_id: str) -> bool:
        """
        Invalidate session (logout)
        
        Args:
            session_id: Session ID
            
        Returns:
            Success status
        """
        if session_id in self.active_sessions:
            del self.active_sessions[session_id]
            return True
        return False

    def get_user_permissions(self, role: Role) -> Set[Permission]:
        """
        Get all permissions for a role
        
        Args:
            role: User role
            
        Returns:
            Set of permissions
        """
        return ROLE_PERMISSIONS.get(role, set())


# Convenience functions
def create_auth_manager(secret_key: str) -> AuthManager:
    """Create auth manager with default settings"""
    return AuthManager(secret_key)
