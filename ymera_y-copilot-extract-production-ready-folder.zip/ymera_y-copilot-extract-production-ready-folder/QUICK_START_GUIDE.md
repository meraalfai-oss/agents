# 🚀 YMERA Quick Start Guide

Get up and running with YMERA in 15 minutes!

## Prerequisites

- Python 3.8+ installed
- pip package manager
- Docker (optional, for containerized deployment)
- PostgreSQL (or use Docker)
- Redis (or use Docker)

## Quick Setup (5 minutes)

### 1. Clone and Install

```bash
# Clone repository
git clone https://github.com/ymera-mfm/ymera_y.git
cd ymera_y

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your settings
# Minimum required:
# - DATABASE_URL
# - REDIS_URL
# - SECRET_KEY
```

### 3. Initialize Database

```bash
# Run migrations
alembic upgrade head

# Or use the setup script
python3 scripts/setup_database.py
```

### 4. Start Application

```bash
# Development mode
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Production mode
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

### 5. Verify Installation

```bash
# Check health endpoint
curl http://localhost:8000/health

# Run verification script
python3 verify_production_readiness.py
```

## Docker Setup (Alternative)

```bash
# Start all services
docker-compose up -d

# Check logs
docker-compose logs -f

# Stop services
docker-compose down
```

## First Steps

### 1. Access the API

```bash
# Open in browser
http://localhost:8000/docs  # Swagger UI
http://localhost:8000/redoc # ReDoc
```

### 2. Create Your First Agent

```python
import requests

response = requests.post('http://localhost:8000/api/agents', json={
    "name": "my_first_agent",
    "type": "calculator",
    "config": {}
})

print(response.json())
```

### 3. Submit a Task

```python
response = requests.post('http://localhost:8000/api/tasks', json={
    "agent_id": "agent_id_from_previous_step",
    "task_type": "calculate",
    "data": {"operation": "add", "values": [1, 2, 3]}
})

print(response.json())
```

### 4. Monitor Metrics

```bash
# View metrics
curl http://localhost:8000/api/metrics

# View specific agent
curl http://localhost:8000/api/agents/{agent_id}/metrics
```

## Running Tests

```bash
# Run all tests
pytest

# Run specific test category
pytest tests/unit/
pytest tests/integration/
pytest tests/e2e/

# Run with coverage
pytest --cov=. --cov-report=html
```

## Common Tasks

### Add a New Agent

1. Create agent file in `agents/` directory
2. Inherit from `BaseAgent`
3. Implement required methods
4. Register agent in agent registry
5. Add tests

### Deploy to Production

```bash
# Option 1: Docker
docker build -t ymera:latest .
docker run -d -p 8000:8000 ymera:latest

# Option 2: Kubernetes
kubectl apply -f k8s/

# Option 3: Use deployment script
./scripts/deploy_production.sh
```

### Update Dependencies

```bash
# Update specific package
pip install --upgrade package_name

# Update all packages
pip install --upgrade -r requirements.txt

# Freeze updated dependencies
pip freeze > requirements.txt
```

### Monitor System

```bash
# View logs
tail -f logs/application.log

# Check agent status
python3 scripts/check_agent_health.py

# Run system analysis
python3 comprehensive_system_analysis.py
```

## Troubleshooting

### Issue: Import Errors

**Solution:**
```bash
# Install missing dependencies
python3 fix_agent_errors.py --priority 1 --install
python3 fix_agent_errors.py --priority 2 --install
```

### Issue: Database Connection Failed

**Solution:**
```bash
# Check database is running
docker-compose ps

# Restart database
docker-compose restart postgres

# Check connection string in .env
```

### Issue: Agent Not Working

**Solution:**
```bash
# Check agent logs
tail -f logs/agents/{agent_name}.log

# Test agent individually
python3 agents/{agent_name}.py

# Run error classification
python3 error_classification_analyzer.py
```

## Next Steps

1. **Read Documentation**
   - [System Overview](./FINAL_SYSTEM_DOCUMENTATION.md)
   - [Architecture Guide](./documentation/general/ARCHITECTURE.md)
   - [API Documentation](./documentation/general/API_DOCS.md)

2. **Explore Examples**
   - Check `examples/` directory
   - Review `agents/` for agent examples
   - Study test files in `tests/`

3. **Join Development**
   - Read [CONTRIBUTING.md](./CONTRIBUTING.md)
   - Check [GitHub Issues](https://github.com/ymera-mfm/ymera_y/issues)
   - Review [Roadmap](./FINAL_SYSTEM_DOCUMENTATION.md#roadmap)

## Support

- **Documentation:** `documentation/` directory
- **Examples:** `examples/` directory
- **Tests:** `tests/` directory for usage examples
- **Analysis:** Run `python3 comprehensive_system_analysis.py`

## Useful Commands

```bash
# System analysis
python3 comprehensive_system_analysis.py

# Error classification
python3 error_classification_analyzer.py

# Dependency analysis
python3 analyze_agent_dependencies.py

# Cleanup and organize
python3 cleanup_and_organize.py --execute

# Production readiness check
python3 verify_production_readiness.py

# Run comprehensive E2E tests
python3 comprehensive_e2e_testing.py
```

---

**Estimated Setup Time:** 15 minutes  
**Difficulty:** Easy  
**Support:** See documentation/ directory

---

*Last Updated:* 2025-10-23
